﻿<%@ Page Title="" Language="C#" MasterPageFile="../Admin/AdminMaster.master" AutoEventWireup="true" CodeFile="Salereports.aspx.cs" Inherits="Admin_Salereports" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
    <style>
        .swal-footer {
            text-align: center !important;
        }

        .swal-text {
            font-size: 22px !important;
            text-align: center;
        }

        .swal-button {
            background-color: #184f34 !important;
        }

        .radio-gap {
            margin-top: 7px;
        }

            .radio-gap input[type="radio"] {
                margin-right: 8px;
            }

            .radio-gap label {
                margin-right: 20px;
                font-size: 16px;
                color: black;
            }

        td {
            font-size: 14px;
        }
    </style>
    <script type="text/javascript" src="sweetalertnew.js"></script>
    <script type="text/javascript">
        function savealert(message, type) {
            swal({
                text: message,
                icon: type === 'success' ? 'success' : type === 'info' ? 'info' : type === 'error' ? 'error' : 'warning',
            });
        }
    </script>
    <script>
        function printDiv(divId) {
            var divContents = document.getElementById(divId).innerHTML;
            var originalContents = document.body.innerHTML;
            document.body.innerHTML = divContents;
            window.print();
            document.body.innerHTML = originalContents;
            location.reload();
        }
    </script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="Server">
    <main>
        <div class="container" style="margin-top: 60px; margin-bottom: 30px;">
            <div class="row">
                <div class="col-md-12">
                    <div class="row" style="margin-top: 30px;">
                        <div class="col-md-3"></div>
                        <div class="col-md-6" style="border: 1px solid #ca9142; box-shadow: 0px 0px 8px -3px #ec9190;">
                            <div class="col-md-12" style="border-bottom: 1px solid #ccc; margin-bottom: 15px;">
                                <div class="form-group" style="margin-bottom: 0px;">
                                    <h3 style="text-align: center; color: #339eae; font-size: 20px; font-weight: 500; margin: 20px;">Sale Report</h3>
                                </div>
                            </div>
                            <div class="form-group mt-3">
                                <div class="row">
                                    <div class="col-md-1"></div>
                                    <div class="col-md-2" style="padding-right: 0px">
                                        <asp:Label ID="lb" Text="From Date" runat="server" ForeColor="Black"></asp:Label>
                                    </div>
                                    <div class="col-md-3" style="padding-right: 0px">
                                        <asp:TextBox runat="server" ID="txtfrom" class="form-control" TextMode="Date" ForeColor="Black"></asp:TextBox>
                                    </div>
                                    <div class="col-md-2">
                                        <asp:Label ID="Label3" Text="To Date" runat="server" ForeColor="Black"></asp:Label>
                                    </div>
                                    <div class="col-md-3" style="padding-right: 0px">
                                        <asp:TextBox runat="server" ID="txtto" class="form-control" TextMode="Date" ForeColor="Black"></asp:TextBox>
                                    </div>
                                    <div class="col-md-1"></div>
                                </div>
                            </div>
                            <div class="row mt-3" style="margin-bottom: 20px;">
                                <div class="col-md-1"></div>
                                <div class="col-md-2">
                                    <asp:Label ID="Label2" runat="server" Text="Category" ForeColor="Black"></asp:Label>
                                </div>
                                <div class="col-md-3" style="padding-right: 0px">
                                    <asp:DropDownList runat="server" ID="ddlcategory" Class="form-control" ForeColor="Black"></asp:DropDownList>
                                </div>
                                <div class="col-md-1"></div>
                            </div>
                            <div class="col-md-12" style="margin-bottom: 10px; border-top: 1px solid #ccc">
                                <div class="row">
                                    <div class="col-md-1"></div>
                                    <div class="col-md-10" style="margin-top: 15px; text-align: center">
                                        <asp:Button ID="btnpreview" runat="server" Text="Preview" CssClass="btn btn-primary" OnClick="btnpreview_Click" OnClientClick="return validatePreview();" />
                                        <input type="button" runat="server" id="btnsubmit2" value="Print" onclick="printDiv('print')" class="btn btn-info" style="background-color: deepskyblue; height: 40px; width: 70px; color: white; border: none; display:none;" />
                                        <asp:Button ID="btnExportExcel"
                                            runat="server"
                                            Text="Export to Excel"
                                            CssClass="btn btn-success"
                                            OnClick="btnExportExcel_Click" />
                                        <asp:Button ID="btnback" runat="server" Text="Back" class="btn btn-danger" Font-Bold="true" OnClick="btnback_Click" />
                                    </div>
                                    <div class="col-md-1"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2"></div>
                    </div>
                </div>
            </div>
            <div class="row" id="print">
                <div class="col-md-12 mt-5" style="color: black">
                    <div>
                        <div style="display:none;">
                            <div style="text-align: center;">
                                <i style="font-size: 25px; display: inline-block;">Charans Club & Resort Pvt. Ltd.</i>
                            </div>
                            <div style="text-align: center;">
                                <span style="font-size: 16px; display: inline-block;">Sale Report : Category wise</span>
                            </div>
                            <div style="font-size: 14px;">
                                <asp:Label runat="server" Text="Period : "></asp:Label>
                                <asp:Label runat="server" ID="from"></asp:Label>-
                                <asp:Label runat="server" ID="lbto"></asp:Label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <asp:Repeater ID="rptStock" runat="server">
                                    <HeaderTemplate>
                                        <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
                                            <thead style="height: 40px; border-bottom: 1px solid #999; border-top: 1px solid #999;">
                                                <tr>
                                                    <th style="padding: 4px;">Category</th>
                                                    <th style="padding: 4px; text-align: right;">No. Of Orders</th>
                                                    <th style="padding: 4px; text-align: right;">Total Items</th>
                                                    <th style="padding: 4px; text-align: right;">Net Amount</th>
                                                    <th style="padding: 4px; text-align: right;">Total Discount</th>
                                                    <th style="text-align: right; padding: 4px;">Total Tax</th>
                                                    <th style="text-align: right; padding: 4px;">Total Sales</th>
                                                    <th style="text-align: right; padding: 4px;">Net Sales</th>
                                                    <th style="text-align: right; padding: 4px;">No. Of Per%</th>
                                                </tr>
                                            </thead>
                                            <tbody style="border-bottom: 1px solid #999;">
                                    </HeaderTemplate>
                                    <ItemTemplate>
                                        <tr runat="server"
                                            visible='<%# string.IsNullOrEmpty(Eval("Category").ToString()) %>'>
                                            <td colspan="9"></td>
                                        </tr>

                                        <%-- Normal data row --%>
                                        <tr runat="server"
                                            visible='<%# !string.IsNullOrEmpty(Eval("Category").ToString()) %>'
                                            style='<%# Eval("Category").ToString() == "TOTAL" 
                || Eval("Category").ToString() == "MIN"
                || Eval("Category").ToString() == "MAX"
                || Eval("Category").ToString() == "AVG"
                ? "font-weight:bold;": "" %>'>

                                            <td><%# Eval("Category") %></td>
                                            <%-- <tr style='<%# Eval("Category").ToString() == "TOTAL" ? "font-weight:bold;": "" %>'>
                                            <td style="padding: 4px;"><%# Eval("Category") %></td>--%>
                                            <td style="padding: 0px; text-align: right;"><%# Eval("OrderCount") %></td>
                                            <td style="padding: 0px; text-align: right;"><%# Eval("totalitems") %></td>
                                            <td style="padding: 0px; text-align: right;"><%# Eval("netamount") %></td>
                                            <td style="padding: 0px; text-align: right;"><%# Eval("Totaldiscount") %></td>
                                            <td style="text-align: right; padding: 0px;"><%# Eval("Totaltax") %></td>
                                            <td style="text-align: right; padding: 0px;"><%# Eval("totalsales") %></td>
                                            <td style="text-align: right; padding: 0px;"><%# Eval("netsales") %></td>
                                            <td style="text-align: right; padding: 0px;"><%# Eval("salepercent") %></td>
                                        </tr>
                                    </ItemTemplate>
                                </asp:Repeater>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</asp:Content>

