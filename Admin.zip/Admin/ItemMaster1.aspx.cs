﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_ItemMaster1 : System.Web.UI.Page
{
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    HttpCookie lgdcookie;
    Class1 cl = new Class1();

    protected void Page_Load(object sender, EventArgs e)
    {
        lgdcookie = Request.Cookies["loggeduser"];
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        if (lgdcookie != null && !string.IsNullOrEmpty(lgdcookie["UserName"]))
        {
            if (!IsPostBack)
            {
                txtitemcode.Text = cl.Scalar("SELECT isnull(Max(Autoid+1),1)Autoid from Product where isactive='1'");
                txtitemcode.ReadOnly = true;
                bindgroup();
            }
        }
        else
        {
            Response.Redirect("Login.aspx");
        }
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        try
        {
            if (btnsave.Text == "Save")
            {
                try
                {
                    if (txtitemcode.Text.Trim() == "")
                    {
                        saveMsg("Please enter Item Code", "warning");
                        return;
                    }

                    if (txtitemname.Text.Trim() == "")
                    {
                        saveMsg("Please enter Item Name", "warning");
                        return;
                    }

                    if (ddlgroup.SelectedIndex == 0)
                    {
                        saveMsg("Please select Item Group", "warning");
                        return;
                    }

                    string imagePath = "";
                    if (filename.HasFile)
                    {
                        string ext = System.IO.Path.GetExtension(filename.FileName).ToLower();

                        if (ext != ".jpg" && ext != ".jpeg" && ext != ".png")
                        {
                            saveMsg("Only JPG / PNG images allowed", "warning");
                            return;
                        }

                        string imgName = DateTime.Now.Ticks + ext;
                        imagePath = "~/ItemImages/" + imgName;

                        string folderPath = Server.MapPath("~/ItemImages/");
                        if (!System.IO.Directory.Exists(folderPath))
                            System.IO.Directory.CreateDirectory(folderPath);

                        filename.SaveAs(Server.MapPath(imagePath));
                    }

                    cl.con.Open();
                    SqlCommand chk = new SqlCommand("select count(*) from Product where Autoid =@code",
                        cl.con);
                    chk.Parameters.AddWithValue("@code", txtitemcode.Text.Trim());

                    int exists = Convert.ToInt32(chk.ExecuteScalar());
                    if (exists > 0)
                    {
                        cl.con.Close();
                        saveMsg("Item Code already exists", "warning");
                        return;
                    }
                    int flag = 1;

                    string groupName = ddlgroup.SelectedItem.Text;                           

                    SqlCommand cmd = new SqlCommand("insert into Product (Autoid, Productname, categoryid, item_unit,Price,gst_per, indate, insuser,deactive, instime,flag,Rate_X1,Rate_X12,Rate_X25,Rate_X4) values (@code,@name,@group,@unit,@rate , @gst_per,@date,@user,0,@time,@flag)", cl.con);

                    cmd.Parameters.AddWithValue("@code", txtitemcode.Text.Trim());
                    cmd.Parameters.AddWithValue("@name", txtitemname.Text.Trim());
                    cmd.Parameters.AddWithValue("@group", ddlgroup.SelectedValue);
                    cmd.Parameters.AddWithValue("@unit", ddlunit.SelectedValue);
                    cmd.Parameters.AddWithValue("@Gst_per", txtgst.Text);
                    cmd.Parameters.AddWithValue("@rate", txtitemrate.Text);
                    cmd.Parameters.AddWithValue("@date", dateTime.ToString("yyyy-MM-dd"));
                    cmd.Parameters.AddWithValue("@user", lgdcookie["UserName"].ToString());
                    cmd.Parameters.AddWithValue("@time", dateTime.ToString("hh:mm:ss tt"));
                    cmd.Parameters.AddWithValue("@flag", flag);

                    cmd.ExecuteNonQuery();
                    cl.con.Close();
                    txtitemcode.Text = cl.Scalar("SELECT isnull(Max(sku+1),1)sku from Item_detail where deactive='0'");
                    saveMsg("Item saved successfully", "success");
                    clearForm();
                }
                catch (Exception ex)
                {
                    saveMsg("Something went wrong", "error");
                }
            }
            else
            {

            }

        }
        catch (Exception ex)
        {

        }
    }
    void saveMsg(string msg, string type)
    {
        ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "savealert('" + msg + "','" + type + "');",
            true);
    }
    void clearForm()
    {
        txtitemname.Text = "";
        ddlgroup.SelectedIndex = 0;
        ddlunit.SelectedIndex = 0;
        txtitemrate.Text = "";
        txtgst.Text = "";
    }

    protected void btnback_Click(object sender, EventArgs e)
    {
        Response.Redirect("Dashboard.aspx");
    }
    public void bindgroup()
    {
        try
        {
            string str = "select Autoid,Categoryname from Category where isactive ='1' order by Categoryname";
            SqlCommand cmd = new SqlCommand(str, cl.con);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt1 = new DataTable();
            adp.Fill(dt1);
            if (dt1.Rows.Count > 0)
            {
                ddlgroup.DataSource = dt1;
                ddlgroup.DataTextField = "Categoryname";
                ddlgroup.DataValueField = "Autoid";
                ddlgroup.DataBind();
                ddlgroup.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception)
        {

        }
    }
}