﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_EditPurchase : System.Web.UI.Page
{
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    HttpCookie lgdcookie;
    Class1 cl = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {
        lgdcookie = Request.Cookies["loggeduser"];
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);

        if (lgdcookie != null && !string.IsNullOrEmpty(lgdcookie["UserName"]))
        {
            if (!IsPostBack)
            {
                ViewState["Mode"] = "Direct";
                BindDirect();
            }
        }
        else
        {
            Response.Redirect("../Login.aspx");
        }
    }
    public void BindDirect()
    {
        try
        {
            string query = "select 'Purchase' as Source, ptype,p.pid,p.pno,convert(nvarchar,p.pdate,103)pdate,p.pinv,convert(nvarchar,p.pinvdt,103)pinvdt,p.itemcate,CAST(p.qty AS VARCHAR(20)) + ' ' + p.unit AS qty,p.rate,p.amount,sip.Item_G_Name,sd.Item_name,isdeleted,CONVERT(VARCHAR(10), p.upddate, 103) + ' ' + p.updtime AS date from purchaseentry p inner join StoreItem_group_Master sip on p.itemcate=sip.item_g_id inner join storeitem_detail sd on p.itemname=sd.sku WHERE ISNULL(p.isdeleted,0)=0 order by pdate desc";

            SqlDataAdapter sda = new SqlDataAdapter(query, cl.con);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            listview2.DataSource = dt;
            listview2.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('" + ex.Message + "');</script>");
        }
    }
    protected void btndelete_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton btn = (LinkButton)sender;
            string[] values = btn.CommandArgument.Split('|');

            string pid = values[0];
            string pno = values[1];
            string source = values[2];
            string ptype = values[3];

            cl.con.Open();

            if (source == "Purchase")
            {
                string query1 = "UPDATE purchaseentry SET qty = 0,amount = 0.00, upduser = @user, upddate = @date, updtime = @time WHERE pid = @pid";

                SqlCommand cmd1 = new SqlCommand(query1, cl.con);
                cmd1.Parameters.AddWithValue("@pid", pid);
                cmd1.Parameters.AddWithValue("@user", lgdcookie["UserName"]);
                cmd1.Parameters.AddWithValue("@date", DateTime.Now.ToString("yyyy-MM-dd"));
                cmd1.Parameters.AddWithValue("@time", DateTime.Now.ToString("HH:mm:ss"));
                cmd1.ExecuteNonQuery();

                if (ptype == "Kitchen")
                {
                    string query2 = "UPDATE IssuetoKitchen SET qty = 0,amount = 0.00, upduser = @user, upddate = @date, updtime = @time WHERE pno = @pno";
                    SqlCommand cmd2 = new SqlCommand(query2, cl.con);
                    cmd2.Parameters.AddWithValue("@pno", pno);
                    cmd2.Parameters.AddWithValue("@user", lgdcookie["UserName"]);
                    cmd2.Parameters.AddWithValue("@date", DateTime.Now.ToString("yyyy-MM-dd"));
                    cmd2.Parameters.AddWithValue("@time", DateTime.Now.ToString("HH:mm:ss"));
                    cmd2.ExecuteNonQuery();
                }

                BindDirect();
            }
            else
            {
                string query3 = "UPDATE IssuetoKitchen SET qty = 0,amount = 0.00, upduser = @user, upddate = @date, updtime = @time WHERE isid = @pid";
                SqlCommand cmd3 = new SqlCommand(query3, cl.con);
                cmd3.Parameters.AddWithValue("@pid", pid);
                cmd3.Parameters.AddWithValue("@user", lgdcookie["UserName"]);
                cmd3.Parameters.AddWithValue("@date", DateTime.Now.ToString("yyyy-MM-dd"));
                cmd3.Parameters.AddWithValue("@time", DateTime.Now.ToString("HH:mm:ss"));
                cmd3.ExecuteNonQuery();

                BindKitchenIssue();
            }

            cl.con.Close();
        }
        catch (Exception ex)
        {
            if (cl.con.State == ConnectionState.Open)
                cl.con.Close();

            Response.Write("<script>alert('Error: " + ex.Message.Replace("'", "") + "');</script>");
        }
    }
    public void BindKitchenIssue()
    {
        try
        {
            string query = @"SELECT 'Issue' as Source,
    p.ptype,
    p.isid as pid,
    p.ino as pno,
    convert(nvarchar,p.idate,103) pdate,
    p.inv as pinv,
    convert(nvarchar,p.invdt,103) pinvdt,
    p.itemcate,
    CAST(p.qty AS VARCHAR(20)) + ' ' + p.unit AS qty,
    p.rate,
    p.amount,
    sip.Item_G_Name,
    sd.Item_name,
    p.isdeleted,
CONVERT(VARCHAR(10), p.upddate, 103) + ' ' + p.updtime AS date
FROM IssuetoKitchen p
INNER JOIN StoreItem_group_Master sip ON p.itemcate=sip.item_g_id
INNER JOIN storeitem_detail sd ON p.itemname=sd.sku
WHERE ISNULL(p.isdeleted,0)=0
AND (p.pno IS NULL OR p.pno = '') order by idate desc";

            SqlDataAdapter sda = new SqlDataAdapter(query, cl.con);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            listview2.DataSource = dt;
            listview2.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('" + ex.Message + "');</script>");
        }
    }
    protected void btnDirect_Click(object sender, EventArgs e)
    {
        ViewState["Mode"] = "Direct";
        BindDirect();
    }

    protected void btnKitchen_Click(object sender, EventArgs e)
    {
        ViewState["Mode"] = "Kitchen";
        BindKitchenIssue();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            ViewState["Mode"] = "Search";
            string pno = txtSearchPno.Text.Trim();

            if (string.IsNullOrEmpty(pno))
            {
                BindDirect();
                return;
            }

            string query = @"select 'Purchase' as Source, ptype,p.pid,p.pno,convert(nvarchar,p.pdate,103) pdate,p.pinv,convert(nvarchar,p.pinvdt,103)pinvdt,CAST(p.qty AS VARCHAR(20)) + ' ' + p.unit AS qty,p.rate,p.amount,sip.Item_G_Name,sd.Item_name,isdeleted,CONVERT(VARCHAR(10), p.upddate, 103) + ' ' + p.updtime AS date from purchaseentry p inner join StoreItem_group_Master sip on p.itemcate=sip.item_g_id inner join storeitem_detail sd on p.itemname=sd.sku WHERE ISNULL(p.isdeleted,0)=0 AND pno LIKE @pno
 UNION ALL
 SELECT 'Issue' as Source,
    p.ptype,
    p.isid as pid,
    p.ino as pno,
    convert(nvarchar,p.idate,103) pdate,
    p.inv as pinv,
    convert(nvarchar,p.invdt,103) pinvdt,
    CAST(p.qty AS VARCHAR(20)) + ' ' + p.unit AS qty,
    p.rate,
    p.amount,
    sip.Item_G_Name,
    sd.Item_name,
    p.isdeleted,
CONVERT(VARCHAR(10), p.upddate, 103) + ' ' + p.updtime AS date
FROM IssuetoKitchen p
INNER JOIN StoreItem_group_Master sip ON p.itemcate=sip.item_g_id
INNER JOIN storeitem_detail sd ON p.itemname=sd.sku
WHERE ISNULL(p.isdeleted,0)=0
AND (p.pno IS NULL OR p.pno = '') AND ino LIKE @pno

order by pdate desc";

            SqlCommand cmd = new SqlCommand(query, cl.con);
            cmd.Parameters.AddWithValue("@pno", "%" + pno + "%");

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            listview2.DataSource = dt;
            listview2.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('" + ex.Message + "');</script>");
        }
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        txtSearchPno.Text = "";
        BindDirect();
    }

    protected void btnDateFilter_Click(object sender, EventArgs e)
    {
        try
        {
            ViewState["Mode"] = "Date";
            string pno = txtFilterDate.Text.Trim();

            if (string.IsNullOrEmpty(pno))
            {
                BindDirect();
                return;
            }

            string query = @"select 'Purchase' as Source, ptype,p.pid,p.pno,convert(nvarchar,p.pdate,103) pdate,p.pinv,convert(nvarchar,p.pinvdt,103)pinvdt,CAST(p.qty AS VARCHAR(20)) + ' ' + p.unit AS qty,p.rate,p.amount,sip.Item_G_Name,sd.Item_name,isdeleted,CONVERT(VARCHAR(10), p.upddate, 103) + ' ' + p.updtime AS date from purchaseentry p inner join StoreItem_group_Master sip on p.itemcate=sip.item_g_id inner join storeitem_detail sd on p.itemname=sd.sku WHERE ISNULL(p.isdeleted,0)=0 AND pdate LIKE @pno
 UNION ALL
 SELECT 'Issue' as Source,
    p.ptype,
    p.isid as pid,
    p.ino as pno,
    convert(nvarchar,p.idate,103) pdate,
    p.inv as pinv,
    convert(nvarchar,p.invdt,103) pinvdt,
    CAST(p.qty AS VARCHAR(20)) + ' ' + p.unit AS qty,
    p.rate,
    p.amount,
    sip.Item_G_Name,
    sd.Item_name,
    p.isdeleted,
CONVERT(VARCHAR(10), p.upddate, 103) + ' ' + p.updtime AS date
FROM IssuetoKitchen p
INNER JOIN StoreItem_group_Master sip ON p.itemcate=sip.item_g_id
INNER JOIN storeitem_detail sd ON p.itemname=sd.sku
WHERE ISNULL(p.isdeleted,0)=0
AND (p.pno IS NULL OR p.pno = '') AND idate LIKE @pno

order by pdate desc";

            SqlCommand cmd = new SqlCommand(query, cl.con);
            cmd.Parameters.AddWithValue("@pno", "%" + pno + "%");

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            listview2.DataSource = dt;
            listview2.DataBind();
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('" + ex.Message + "');</script>");
        }
    }
    protected void listview2_PagePropertiesChanging(object sender, PagePropertiesChangingEventArgs e)
    {
        DataPager1.SetPageProperties(e.StartRowIndex, e.MaximumRows, false);

        string mode = "";

        if (ViewState["Mode"] != null)
        {
            mode = ViewState["Mode"].ToString();
        }
        if (mode == "Search")
            btnSearch_Click(null, null);
        else if (mode == "Date")
            btnDateFilter_Click(null, null);
        else if (mode == "Kitchen")
            BindKitchenIssue();
        else
            BindDirect();
    }
}