﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Dashboard : System.Web.UI.Page
{
    Class1 cl = new Class1();
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    protected void Page_Load(object sender, EventArgs e)
    {
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        if (!IsPostBack)
        {
            txtFrom.Text = DateTime.Now.ToString("yyyy-MM-dd");
            txtTo.Text = DateTime.Now.ToString("yyyy-MM-dd");

            binddetails();
            LoadGroupChart();
            LoadPaymentModeChart();
        }
    }
    private void binddetails()
    {
        SqlCommand cmd = new SqlCommand("SELECT COUNT(*) AS KotCount,ISNULL(SUM(Grandtotal),0) AS KotAmount FROM kot_master WHERE KOT_Date >= CONVERT(date, GETUTCDATE()) AND KOT_Date < DATEADD(day, 1, CONVERT(date, GETUTCDATE())) and IsClosed = 0", cl.con);
        cl.con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            todaycountkot.InnerText = dr["KotCount"].ToString();
            todaytotalcountkot.InnerText = dr["KotAmount"].ToString();
        }
        cl.con.Close();
        SqlCommand cmd1 = new SqlCommand("SELECT COUNT(*) AS KotCount,ISNULL(SUM(Grandtotal),0) AS KotAmount FROM Bill_Master WHERE isdayClosed = 0 and Bill_Date >= CONVERT(date, GETUTCDATE()) AND Bill_Date < DATEADD(day, 1, CONVERT(date, GETUTCDATE()))", cl.con);
        cl.con.Open();
        SqlDataReader dr1 = cmd1.ExecuteReader();
        if (dr1.Read())
        {
            todaycountbill.InnerText = dr1["KotCount"].ToString();
            todaytotalcountbill.InnerText = dr1["KotAmount"].ToString();
        }
        cl.con.Close();
        SqlCommand cmd2 = new SqlCommand("SELECT COUNT(*) AS KotCount,ISNULL(SUM(Grandtotal),0) AS KotAmount FROM Bill_Master WHERE IsPaid = 1 and isdayClosed = 0 and Bill_Date >= CONVERT(date, GETUTCDATE()) AND Bill_Date < DATEADD(day, 1, CONVERT(date, GETUTCDATE()))", cl.con);
        cl.con.Open();
        SqlDataReader dr2 = cmd2.ExecuteReader();
        if (dr2.Read())
        {
            todaycountsett.InnerText = dr2["KotCount"].ToString();
            todaytotalcountsett.InnerText = dr2["KotAmount"].ToString();
        }
        cl.con.Close();
    }
    protected void btnFilter_Click(object sender, EventArgs e)
    {
        LoadGroupChart();
        LoadPaymentModeChart();
    }
    protected void LoadGroupChart()
    {
        if (txtFrom.Text == "" || txtTo.Text == "")
            return;

        DateTime fromDate = Convert.ToDateTime(txtFrom.Text);
        DateTime toDate = Convert.ToDateTime(txtTo.Text);

        DataTable dt = new DataTable();

        using (SqlCommand cmd = new SqlCommand("SELECT ig.subpgroupname, SUM(bd.Amount) AS TotalAmount FROM Bill_Detail bd   INNER JOIN Item_detail im ON im.SKU = bd.sku INNER JOIN bill_master bm ON bm.bill_id = bd.bill_id INNER JOIN Item_group_Master ig ON ig.Item_G_Id = im.Item_group_name WHERE ispaid = 1 and isdayclosed = 0 and bm.bill_date >= @fromdate AND bm.bill_date < DATEADD(DAY,1,@todate) AND bd.Amount > 0 GROUP BY ig.subpgroupname ORDER BY ig.subpgroupname", cl.con))
        {
            cmd.Parameters.AddWithValue("@fromdate", fromDate);
            cmd.Parameters.AddWithValue("@todate", toDate);

            cl.con.Open();
            dt.Load(cmd.ExecuteReader());
            cl.con.Close();

        }

        List<string> labelList = new List<string>();
        List<decimal> dataList = new List<decimal>();
        List<string> colorList = new List<string>();
        Random rnd = new Random();

        foreach (DataRow row in dt.Rows)
        {
            labelList.Add(row["subpgroupname"].ToString());
            dataList.Add(Convert.ToDecimal(row["TotalAmount"]));

            string color = "rgba("
                + rnd.Next(50, 255) + ","
                + rnd.Next(50, 255) + ","
                + rnd.Next(50, 255) + ",0.7)";
            colorList.Add(color);
        }

        JavaScriptSerializer js = new JavaScriptSerializer();
        hfLabels.Value = js.Serialize(labelList);
        hfData.Value = js.Serialize(dataList);
        hfColors.Value = js.Serialize(colorList);
    }
    decimal kotTotal = 0;
    protected void KOT_Click(object sender, EventArgs e)
    {

        DateTime todayStart = dateTime.Date;
        DateTime nowTime = dateTime;

        DataTable dt = new DataTable();

        using (SqlCommand cmd = new SqlCommand("SELECT Table_No, KOT_No, Grandtotal FROM kot_master WHERE KOT_Date >= @start AND KOT_Date <= @now and IsClosed = 0 ORDER BY KOT_No DESC", cl.con))
        {
            cmd.Parameters.AddWithValue("@start", todayStart);
            cmd.Parameters.AddWithValue("@now", nowTime);

            cl.con.Open();
            dt.Load(cmd.ExecuteReader());
            cl.con.Close();
        }

        gvKot.DataSource = dt;
        gvKot.DataBind();

        ScriptManager.RegisterStartupScript(this, GetType(), "showKot", "new bootstrap.Modal(document.getElementById('kotModal')).show();", true);
    }
    protected void gvKot_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            kotTotal += Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "Grandtotal"));
        }

        if (e.Row.RowType == DataControlRowType.Footer)
        {
            e.Row.Cells[1].Text = "TOTAL";
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Right;

            e.Row.Cells[2].Text = "₹ " + kotTotal.ToString("N2");
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Right;
        }
    }
    decimal billTotal = 0;
    protected void Bill_Click(object sender, EventArgs e)
    {
        DateTime todayStart = dateTime.Date;
        DateTime nowTime = dateTime;

        DataTable dt = new DataTable();

        using (SqlCommand cmd = new SqlCommand("SELECT Table_No, Bill_No, Grandtotal FROM Bill_Master WHERE isdayClosed = 0 AND Bill_Date >= @start AND Bill_Date <= @now ORDER BY Bill_No DESC", cl.con))
        {
            cmd.Parameters.AddWithValue("@start", todayStart);
            cmd.Parameters.AddWithValue("@now", nowTime);

            cl.con.Open();
            dt.Load(cmd.ExecuteReader());
            cl.con.Close();
        }

        gvBill.DataSource = dt;
        gvBill.DataBind();

        ScriptManager.RegisterStartupScript(this, GetType(), "showBill", "new bootstrap.Modal(document.getElementById('billModal')).show();", true);
    }

    protected void gvBill_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            billTotal += Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "Grandtotal"));
        }

        if (e.Row.RowType == DataControlRowType.Footer)
        {
            e.Row.Cells[1].Text = "TOTAL";
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Right;

            e.Row.Cells[2].Text = "₹ " + billTotal.ToString("N2");
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Right;
        }
    }
    decimal settlementTotal = 0;

    protected void Settlement_Click(object sender, EventArgs e)
    {
        DateTime todayStart = dateTime.Date;
        DateTime nowTime = dateTime;

        DataTable dt = new DataTable();

        using (SqlCommand cmd = new SqlCommand("SELECT Table_No, Bill_No, Grandtotal FROM Bill_Master WHERE IsPaid = 1 AND isdayClosed = 0 AND Bill_Date >= @start AND Bill_Date <= @now ORDER BY Bill_No DESC", cl.con))
        {
            cmd.Parameters.AddWithValue("@start", todayStart);
            cmd.Parameters.AddWithValue("@now", nowTime);

            cl.con.Open();
            dt.Load(cmd.ExecuteReader());
            cl.con.Close();
        }

        gvSettlement.DataSource = dt;
        gvSettlement.DataBind();

        ScriptManager.RegisterStartupScript(this, GetType(), "showSettle", "new bootstrap.Modal(document.getElementById('settModal')).show();", true);
    }

    protected void gvSettlement_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            settlementTotal += Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "Grandtotal"));
        }

        if (e.Row.RowType == DataControlRowType.Footer)
        {
            e.Row.Cells[1].Text = "TOTAL";
            e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Right;

            e.Row.Cells[2].Text = "₹ " + settlementTotal.ToString("N2");
            e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Right;
        }
    }
    private void LoadPaymentModeChart()
    {
        if (txtFrom.Text == "" || txtTo.Text == "")
            return;

        DateTime fromDate = Convert.ToDateTime(txtFrom.Text);
        DateTime toDate = Convert.ToDateTime(txtTo.Text);

        string query = "SELECT ISNULL(SUM(CAST(CashAmount AS DECIMAL(18,2))),0) AS CashTotal, ISNULL(SUM(CAST(UPIAmount AS DECIMAL(18,2))),0) AS UPITotal, ISNULL(SUM(CAST(Cardamount AS DECIMAL(18,2))),0) AS CardTotal, ISNULL(SUM(CAST(Creditamount AS DECIMAL(18,2))),0) AS CreditTotal FROM Bill_Master WHERE IsPaid = 1 AND isdayClosed = 0 AND Bill_Date >= @From         AND Bill_Date < DATEADD(DAY,1,@To)";

        List<string> labels = new List<string>();
        List<decimal> data = new List<decimal>();
        List<string> colors = new List<string>();

        using (SqlCommand cmd = new SqlCommand(query, cl.con))
        {
            cmd.Parameters.AddWithValue("@From", fromDate);
            cmd.Parameters.AddWithValue("@To", toDate);

            cl.con.Open();
            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                decimal cash = Convert.ToDecimal(dr["CashTotal"]);
                decimal upi = Convert.ToDecimal(dr["UPITotal"]);
                decimal card = Convert.ToDecimal(dr["CardTotal"]);
                decimal credit = Convert.ToDecimal(dr["CreditTotal"]);

                if (cash > 0)
                {
                    labels.Add("Cash");
                    data.Add(cash);
                    colors.Add("#28a745");
                }

                if (upi > 0)
                {
                    labels.Add("UPI");
                    data.Add(upi);
                    colors.Add("#007bff");
                }

                if (card > 0)
                {
                    labels.Add("Card");
                    data.Add(card);
                    colors.Add("#6f42c1");
                }

                if (credit > 0)
                {
                    labels.Add("Credit");
                    data.Add(credit);
                    colors.Add("#fd7e14");
                }
            }

            cl.con.Close();
        }

        JavaScriptSerializer js = new JavaScriptSerializer();
        hfPaymentLabels.Value = js.Serialize(labels);
        hfPaymentData.Value = js.Serialize(data);
        hfPaymentColors.Value = js.Serialize(colors);
    }
}