﻿<%@ Page Title="" Language="C#" MasterPageFile="../Admin/AdminMaster.master" AutoEventWireup="true" CodeFile="ItemMaster.aspx.cs" Inherits="Admin_ItemMaster" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
    <link href="Style.css" rel="stylesheet" />
    <style>
        .swal-footer {
            text-align: center !important;
        }

        .swal-text {
            font-size: 22px !important;
            text-align: center;
        }

        .swal-button {
            background-color: #184f34 !important;
        }
    </style>
    <script type="text/javascript" src="sweetalertnew.js"></script>
    <script type="text/javascript">
        function savealert(message, type) {
            swal({
                text: message,
                icon: type === 'success' ? 'success' : type === 'info' ? 'info' : type === 'error' ? 'error' : 'warning',
            });
        }
    </script>
    <script type="text/javascript">
        window.history.forward();
        function noBack() {
            window.history.forward();
        }
    </script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="Server">
    <div class="container" style="margin-top: 20px;">
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-8" style="border: 1px solid;">
                <div class="form-group">
                    <div class="row">
                        <div class="col-md-12">
                            <h5 style="text-align: center; margin-top: 10px; font-weight: 600;">Item Master</h5>
                        </div>
                    </div>
                </div>
                <hr />
                <div class="form-group">
                    <div class="row">
                        <div class="col-md-1"></div>
                        <div class="col-md-2">
                            <asp:Label runat="server" ID="lblasdf" Text="Item Code" ForeColor="Black"></asp:Label>
                        </div>
                        <div class="col-md-3">
                            <asp:TextBox runat="server" ID="txtitemcode" CssClass="form-control" ForeColor="Black"></asp:TextBox>
                        </div>
                        <div class="col-md-2">
                            <asp:Label runat="server" ID="Label1" Text="Group" ForeColor="Black"></asp:Label>
                        </div>
                        <div class="col-md-3">
                            <asp:DropDownList runat="server" ID="ddlgroup" CssClass="form-control" ForeColor="Black" onchange="toggleRateByGroup(this)"></asp:DropDownList>
                        </div>
                        <div class="col-md-1"></div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="row">
                        <div class="col-md-1"></div>
                        <div class="col-md-2">
                            <asp:Label runat="server" ID="Label2" Text="Item Name" ForeColor="Black"></asp:Label>
                        </div>
                        <div class="col-md-3">
                            <asp:TextBox runat="server" ID="txtitemname" CssClass="form-control" ForeColor="Black"></asp:TextBox>
                        </div>
                        <div class="col-md-2">
                            <asp:Label runat="server" Text="GST %" ForeColor="Black"></asp:Label>
                        </div>
                        <div class="col-md-3">
                            <asp:TextBox runat="server" ID="txtgst" CssClass="form-control" ForeColor="Black"></asp:TextBox>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="row">
                        <div class="col-md-1"></div>
                        <div class="col-md-2">
                            <asp:Label runat="server" Text="Rate" ForeColor="Black"></asp:Label>
                        </div>
                        <div class="col-md-3" id="divSingleRate" runat="server">
                            <asp:TextBox runat="server" ID="txtitemrate" CssClass="form-control" ForeColor="Black"></asp:TextBox>
                        </div>
                        <div class="col-md-3" id="divMultiRate" runat="server" style="display: none;">
                            <asp:TextBox ID="txtX1" runat="server" CssClass="form-control mb-1" Placeholder="X1 Rate"></asp:TextBox>
                            <asp:TextBox ID="txtX12" runat="server" CssClass="form-control mb-1" Placeholder="X12 Rate"></asp:TextBox>
                            <asp:TextBox ID="txtX25" runat="server" CssClass="form-control mb-1" Placeholder="X25 Rate"></asp:TextBox>
                            <asp:TextBox ID="txtX4" runat="server" CssClass="form-control" Placeholder="X4 Rate"></asp:TextBox>
                        </div>

                        <div class="col-md-2">
                            <asp:Label runat="server" ID="Label3" Text="Unit" ForeColor="Black"></asp:Label>
                        </div>
                        <div class="col-md-3">
                            <asp:DropDownList runat="server" ID="ddlunit" CssClass="form-control" ForeColor="Black">
                                <asp:ListItem Text="--Select--" Value="0"></asp:ListItem>
                                <asp:ListItem Text="ML" Value="ML"></asp:ListItem>
                                <asp:ListItem Text="Kg" Value="Kg"></asp:ListItem>
                                <asp:ListItem Text="ltr" Value="ltr"></asp:ListItem>
                                <asp:ListItem Text="pcs" Value="pcs"></asp:ListItem>
                                <asp:ListItem Text="tin" Value="tin"></asp:ListItem>
                            </asp:DropDownList>
                        </div>
                        <div class="col-md-1"></div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="row">
                        <div class="col-md-1"></div>
                        <div class="col-md-2">
                            <asp:Label runat="server" ID="Label4" Text="Item Image" ForeColor="Black"></asp:Label>
                        </div>
                        <div class="col-md-3">
                            <asp:FileUpload runat="server" ID="filename" ForeColor="Black"></asp:FileUpload>
                            <asp:Image ID="imgPreview" runat="server" 
    Width="120px" Height="120px" 
    Visible="false"
    Style="border:1px solid #ccc; margin-bottom:10px;" />
                        </div>
                        <div class="col-md-1"></div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="row">
                        <div class="col-md-5"></div>
                        <div class="col-md-3">
                            <asp:Button runat="server" ID="btnsave" Text="Save" CssClass="btn btn-success" OnClick="btnsave_Click"></asp:Button>
                            <asp:Button runat="server" ID="btnback" Text="Back" CssClass="btn btn-danger" OnClick="btnback_Click"></asp:Button>
                        </div>
                        <div class="col-md-4"></div>
                    </div>
                </div>
            </div>
            <div style="overflow: scroll; height: 500px; margin-top: 10px;">
                <div class="row">
                    <div class="col-md-12">
                        <asp:ListView ID="listview2" runat="server" Style="color: black !important; width: 100%">
                            <LayoutTemplate>
                                <table class="table table-bordered">
                                    <tr>
                                        <th>Item ID</th>
                                        <th>Item Name</th>
                                        <th>Group Name</th>
                                        <th>Rate</th>
                                        <th>GST</th>
                                        <th>Rate_X1</th>
                                        <th>Rate_X12</th>
                                        <th>Rate_X25</th>
                                        <th>Rate_X4</th>
                                        <th>Product Image</th>
                                        <th>Action</th>
                                    </tr>
                                    <tbody>
                                        <asp:PlaceHolder ID="itemPlaceHolder" runat="server" />
                                    </tbody>
                                </table>
                            </LayoutTemplate>
                            <ItemTemplate>
                                <tr>
                                    <td>
                                        <asp:Label ID="lblcode" runat="server" Text=' <%# Eval("SKU")%>'></asp:Label></td>
                                    <td>
                                        <asp:Label ID="Label5" runat="server" Text=' <%# Eval("item_name")%>'></asp:Label></td>
                                    <td>
                                        <asp:Label ID="Label6" runat="server" Text=' <%# Eval("Item_G_Name")%>'></asp:Label></td>
                                    <td>
                                        <asp:Label ID="Label7" runat="server" Text=' <%# Eval("item_sale_rate")%>'></asp:Label></td>
                                    <td>
                                        <asp:Label ID="lblitem" runat="server" Text=' <%# Eval("gst_per")%>'></asp:Label></td>
                                    <td>
                                        <asp:Label ID="lblitemna" runat="server" Text=' <%# Eval("Rate_X1")%>'></asp:Label></td>
                                    <td>
                                        <asp:Label ID="lblite" runat="server" Text=' <%# Eval("Rate_X12")%>'></asp:Label></td>
                                    <td>
                                        <asp:Label ID="lbli" runat="server" Text=' <%# Eval("Rate_X25")%>'></asp:Label></td>
                                    <td>
                                        <asp:Label ID="lblitemn" runat="server" Text=' <%# Eval("Rate_X4")%>'></asp:Label></td>
                                    <td>
                                        <asp:Image ID="imgCategory" runat="server"
      ImageUrl='<%# Eval("productImage") %>'
      Width="60px" Height="60px"
      Visible='<%# Eval("productImage") != DBNull.Value %>' />
                                    <td>
                                        <asp:Button runat="server" ID="btnedit" Text="Edit" CssClass="btn btn-warning" OnClick="btnedit_Click" Style="padding: 5px !important;" />
                                        <asp:Button runat="server" ID="btndelete" Text='<%# Eval("inactive")%>' CssClass="btn btn-danger" OnClick="btndelete_Click" OnClientClick="return showConfirm();" Style="padding: 5px !important;" />
                                    </td>
                                </tr>
                            </ItemTemplate>
                        </asp:ListView>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        function toggleRateByGroup(ddl) {

            var selectedText = ddl.options[ddl.selectedIndex].text.toUpperCase();

            var barGroups = [
                "MALTS",
                "SCOTCH AND WHISKY",
                "OTHER SPIRITS",
                "BLENDED WHISKY",
                "VODKA",
                "RUM",
                "STRONG BEER",
                "LAGER BEER"
            ];

            var isBar = barGroups.includes(selectedText);

            document.getElementById('<%= divSingleRate.ClientID %>').style.display = isBar ? 'none' : 'block';
            document.getElementById('<%= divMultiRate.ClientID %>').style.display = isBar ? 'block' : 'none';
        }
    </script>

</asp:Content>

