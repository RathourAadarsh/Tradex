﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_GSTReport : System.Web.UI.Page
{
    Class1 cl = new Class1();
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    protected void Page_Load(object sender, EventArgs e)
    {
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        if (!IsPostBack)
        {
            txtfrom.Text = dateTime.ToString("yyyy-MM-dd");
            txtto.Text = dateTime.ToString("yyyy-MM-dd");
        }
    }
    protected void btnpreview_Click(object sender, EventArgs e)
    {
        totalTaxable = totalCGST = totalSGST = totalDiscount = totalRound = totalGrand = 0;

        DateTime fromDate = DateTime.Parse(txtfrom.Text);
        DateTime toDate = DateTime.Parse(txtto.Text);

        rptGSTDetail.DataSource = GetGSTDetail(fromDate, toDate);
        rptGSTDetail.DataBind();

        rptGSTSummary.DataSource = GetGSTSummary(fromDate, toDate);
        rptGSTSummary.DataBind();
    }

    private DataTable GetGSTSummary(DateTime fromDate, DateTime toDate)
    {
        DataTable dt = new DataTable();

        string query = "SELECT ISNULL(id.gst_per,0) AS GSTPercent, SUM(bd.Amount) AS TaxableAmount, SUM(bd.Amount * ISNULL(id.gst_per,0) / 200.0) AS CGST, SUM(bd.Amount * ISNULL(id.gst_per,0) / 200.0) AS SGST, SUM(bd.Amount + (bd.Amount * ISNULL(id.gst_per,0) / 100.0)) AS TotalAmount FROM Bill_Detail bd JOIN Bill_Master bm ON bd.Bill_ID = bm.Bill_ID LEFT JOIN item_detail id ON bd.sku = id.SKU WHERE bm.IsPaid = 1 AND bm.Bill_Date >= @fromdate AND bm.Bill_Date < DATEADD(DAY,1,@todate) GROUP BY ISNULL(id.gst_per,0)ORDER BY GSTPercent";

        SqlCommand cmd = new SqlCommand(query, cl.con);
        cmd.Parameters.AddWithValue("@fromdate", fromDate);
        cmd.Parameters.AddWithValue("@todate", toDate);

        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);

        return dt;
    }
    decimal totalTaxable = 0;
    decimal totalCGST = 0;
    decimal totalSGST = 0;
    decimal totalDiscount = 0;
    decimal totalRound = 0;
    decimal totalGrand = 0;

    private DataTable GetGSTDetail(DateTime fromDate, DateTime toDate)
    {
        DataTable dt = new DataTable();

        string query = @"SELECT 
        Bill_No,
        Bill_Date,
        SubTotal AS TaxableAmount,
        Tax/2 AS CGST,
        Tax/2 AS SGST,
        Discount AS Discount,
        RoundOff,
        GrandTotal
    FROM Bill_Master
    WHERE IsPaid = 1
    AND Bill_Date >= @fromdate
    AND Bill_Date < DATEADD(DAY,1,@todate)
    ORDER BY Bill_Date, Bill_No";

        SqlCommand cmd = new SqlCommand(query, cl.con);
        cmd.Parameters.AddWithValue("@fromdate", fromDate);
        cmd.Parameters.AddWithValue("@todate", toDate);

        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);

        return dt;
    }

    protected void rptGSTDetail_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item ||
            e.Item.ItemType == ListItemType.AlternatingItem)
        {
            DataRowView drv = (DataRowView)e.Item.DataItem;

            totalTaxable += Convert.ToDecimal(drv["TaxableAmount"]);
            totalCGST += Convert.ToDecimal(drv["CGST"]);
            totalSGST += Convert.ToDecimal(drv["SGST"]);
            totalDiscount += Convert.ToDecimal(drv["Discount"]);
            totalRound += Convert.ToDecimal(drv["RoundOff"]);
            totalGrand += Convert.ToDecimal(drv["GrandTotal"]);
        }

        if (e.Item.ItemType == ListItemType.Footer)
        {
            ((Label)e.Item.FindControl("lblTaxableTotal")).Text = totalTaxable.ToString("0.00");
            ((Label)e.Item.FindControl("lblCGSTTotal")).Text = totalCGST.ToString("0.00");
            ((Label)e.Item.FindControl("lblSGSTTotal")).Text = totalSGST.ToString("0.00");
            ((Label)e.Item.FindControl("lblDiscountTotal")).Text = totalDiscount.ToString("0.00");
            ((Label)e.Item.FindControl("lblRoundTotal")).Text = totalRound.ToString("0.00");
            ((Label)e.Item.FindControl("lblGrandTotal")).Text = totalGrand.ToString("0.00");
        }
    }

    protected void btnExportExcel_Click(object sender, EventArgs e)
    {
        DateTime fromDate = DateTime.Parse(txtfrom.Text);
        DateTime toDate = DateTime.Parse(txtto.Text);

        DataTable dtDetail = GetGSTDetail(fromDate, toDate);
        DataTable dtSummary = GetGSTSummary(fromDate, toDate);

        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition",
            "attachment;filename=GSTReport_" + DateTime.Now.ToString("ddMMyyyy") + ".xls");
        Response.ContentType = "application/vnd.ms-excel";

        System.IO.StringWriter sw = new System.IO.StringWriter();

        sw.Write("<table border='1' style='font-family:Calibri;font-size:14px;width:100%'>");

        // 🔹 Report Title
        sw.Write("<tr><td colspan='8' style='font-size:18px;font-weight:bold;text-align:center'>Charans Club & Resort Pvt Ltd</td></tr>");        
        sw.Write("<tr><td colspan='8' style='font-size:18px;font-weight:bold;text-align:center'>GST REPORT</td></tr>");        
        sw.Write("<tr>");
        sw.Write("<td colspan='8'><b>Period :</b> " +
                 fromDate.ToString("dd-MM-yyyy") + " to " +
                 toDate.ToString("dd-MM-yyyy") + "</td>");
        sw.Write("</tr>");

        sw.Write("<tr><td colspan='8'></td></tr>");
        sw.Write("<tr style='font-weight:bold;background:#f2f2f2'>");
        sw.Write("<td>Bill No</td>");
        sw.Write("<td>Date</td>");
        sw.Write("<td>Taxable</td>");
        sw.Write("<td>CGST</td>");
        sw.Write("<td>SGST</td>");
        sw.Write("<td>Discount</td>");
        sw.Write("<td>RoundOff</td>");
        sw.Write("<td>Total</td>");
        sw.Write("</tr>");

        decimal totalTaxable = 0;
        decimal totalCGST = 0;
        decimal totalSGST = 0;
        decimal totalDiscount = 0;
        decimal totalRound = 0;
        decimal totalGrand = 0;

        foreach (DataRow row in dtDetail.Rows)
        {
            sw.Write("<tr>");
            sw.Write("<td>" + row["Bill_No"] + "</td>");
            sw.Write("<td>" + Convert.ToDateTime(row["Bill_Date"]).ToString("dd-MM-yyyy") + "</td>");
            sw.Write("<td>" + Convert.ToDecimal(row["TaxableAmount"]).ToString("0.00") + "</td>");
            sw.Write("<td>" + Convert.ToDecimal(row["CGST"]).ToString("0.00") + "</td>");
            sw.Write("<td>" + Convert.ToDecimal(row["SGST"]).ToString("0.00") + "</td>");
            sw.Write("<td>" + Convert.ToDecimal(row["Discount"]).ToString("0.00") + "</td>");
            sw.Write("<td>" + Convert.ToDecimal(row["RoundOff"]).ToString("0.00") + "</td>");
            sw.Write("<td>" + Convert.ToDecimal(row["GrandTotal"]).ToString("0.00") + "</td>");
            sw.Write("</tr>");

            totalTaxable += Convert.ToDecimal(row["TaxableAmount"]);
            totalCGST += Convert.ToDecimal(row["CGST"]);
            totalSGST += Convert.ToDecimal(row["SGST"]);
            totalDiscount += Convert.ToDecimal(row["Discount"]);
            totalRound += Convert.ToDecimal(row["RoundOff"]);
            totalGrand += Convert.ToDecimal(row["GrandTotal"]);
        }

        sw.Write("<tr style='font-weight:bold;background:#e6e6e6'>");
        sw.Write("<td colspan='2'>GRAND TOTAL</td>");
        sw.Write("<td>" + totalTaxable.ToString("0.00") + "</td>");
        sw.Write("<td>" + totalCGST.ToString("0.00") + "</td>");
        sw.Write("<td>" + totalSGST.ToString("0.00") + "</td>");
        sw.Write("<td>" + totalDiscount.ToString("0.00") + "</td>");
        sw.Write("<td>" + totalRound.ToString("0.00") + "</td>");
        sw.Write("<td>" + totalGrand.ToString("0.00") + "</td>");
        sw.Write("</tr>");

        sw.Write("<tr><td colspan='8'></td></tr>");
        sw.Write("<tr><td colspan='8'></td></tr>");

        sw.Write("<tr>");
        sw.Write("<td colspan='8' style='font-weight:bold;font-size:16px'>GST Summary</td>");
        sw.Write("</tr>");

        sw.Write("<tr style='font-weight:bold;background:#f9f9f9'>");
        sw.Write("<td>GST %</td>");
        sw.Write("<td>Taxable</td>");
        sw.Write("<td>CGST</td>");
        sw.Write("<td>SGST</td>");
        sw.Write("<td>Total</td>");
        sw.Write("</tr>");

        foreach (DataRow row in dtSummary.Rows)
        {
            sw.Write("<tr>");
            sw.Write("<td>" + row["GSTPercent"] + " %</td>");
            sw.Write("<td>" + Convert.ToDecimal(row["TaxableAmount"]).ToString("0.00") + "</td>");
            sw.Write("<td>" + Convert.ToDecimal(row["CGST"]).ToString("0.00") + "</td>");
            sw.Write("<td>" + Convert.ToDecimal(row["SGST"]).ToString("0.00") + "</td>");
            sw.Write("<td>" + Convert.ToDecimal(row["TotalAmount"]).ToString("0.00") + "</td>");
            sw.Write("</tr>");
        }

        sw.Write("</table>");

        Response.Write(sw.ToString());
        Response.End();
    }


    protected void btnback_Click(object sender, EventArgs e)
    {

    }
}