﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Admin/AdminMaster.master" AutoEventWireup="true" CodeFile="GSTReport.aspx.cs" Inherits="Admin_GSTReport" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
    <style>
        .swal-footer {
            text-align: center !important;
        }

        .swal-text {
            font-size: 22px !important;
            text-align: center;
        }

        .swal-button {
            background-color: #184f34 !important;
        }

        .radio-gap {
            margin-top: 7px;
        }

            .radio-gap input[type="radio"] {
                margin-right: 8px;
            }

            .radio-gap label {
                margin-right: 20px;
                font-size: 16px;
                color: black;
            }

        td {
            font-size: 14px;
        }
    </style>
    <script type="text/javascript" src="sweetalertnew.js"></script>
    <script type="text/javascript">
        function savealert(message, type) {
            swal({
                text: message,
                icon: type === 'success' ? 'success' : type === 'info' ? 'info' : type === 'error' ? 'error' : 'warning',
            });
        }
    </script>
    <script>
        function printDiv(divId) {
            var divContents = document.getElementById(divId).innerHTML;
            var originalContents = document.body.innerHTML;
            document.body.innerHTML = divContents;
            window.print();
            document.body.innerHTML = originalContents;
            location.reload();
        }
    </script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="Server">
    <main>
        <div class="container" style="margin-top: 60px; margin-bottom: 30px;">
            <div class="row">
                <div class="col-md-12">
                    <div class="row" style="margin-top: 30px;">
                        <div class="col-md-3"></div>
                        <div class="col-md-6" style="border: 1px solid #ca9142; box-shadow: 0px 0px 8px -3px #ec9190;">
                            <div class="col-md-12" style="border-bottom: 1px solid #ccc; margin-bottom: 15px;">
                                <div class="form-group" style="margin-bottom: 0px;">
                                    <h3 style="text-align: center; color: #339eae; font-size: 20px; font-weight: 500; margin: 20px;">GST Report</h3>
                                </div>
                            </div>
                            <div class="form-group mt-3 mb-3">
                                <div class="row">
                                    <div class="col-md-1"></div>
                                    <div class="col-md-2" style="padding-right: 0px">
                                        <asp:Label ID="lb" Text="From Date" runat="server" ForeColor="Black"></asp:Label>
                                    </div>
                                    <div class="col-md-3" style="padding-right: 0px">
                                        <asp:TextBox runat="server" ID="txtfrom" class="form-control" TextMode="Date" ForeColor="Black"></asp:TextBox>
                                    </div>
                                    <div class="col-md-2">
                                        <asp:Label ID="Label3" Text="To Date" runat="server" ForeColor="Black"></asp:Label>
                                    </div>
                                    <div class="col-md-3" style="padding-right: 0px">
                                        <asp:TextBox runat="server" ID="txtto" class="form-control" TextMode="Date" ForeColor="Black"></asp:TextBox>
                                    </div>
                                    <div class="col-md-1"></div>
                                </div>
                            </div>
                            <div class="col-md-12" style="margin-bottom: 10px; border-top: 1px solid #ccc">
                                <div class="row">
                                    <div class="col-md-2"></div>
                                    <div class="col-md-8" style="margin-top: 15px; text-align: center">
                                        <asp:Button ID="btnpreview" runat="server" Text="Preview" CssClass="btn btn-primary" OnClick="btnpreview_Click" />
                                        <asp:Button ID="btnExportExcel" runat="server" Text="Export to Excel" CssClass="btn btn-success" OnClick="btnExportExcel_Click" />
                                        <asp:Button ID="btnback" runat="server" Text="Back" class="btn btn-danger" Font-Bold="true" OnClick="btnback_Click" />
                                    </div>
                                    <div class="col-md-2"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2"></div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 mt-3">
                            <asp:Repeater ID="rptGSTDetail" runat="server" OnItemDataBound="rptGSTDetail_ItemDataBound">
                                <HeaderTemplate>
                                    <table class="table table-bordered" >
                                        <tr style="font-weight: bold; background: #f2f2f2">
                                            <th>Bill No</th>
                                            <th>Date</th>
                                            <th style="text-align: right">Taxable</th>
                                            <th style="text-align: right">CGST</th>
                                            <th style="text-align: right">SGST</th>
                                            <th style="text-align: right">Discount</th>
                                            <th style="text-align: right">RoundOff</th>
                                            <th style="text-align: right">Total</th>
                                        </tr>
                                </HeaderTemplate>

                                <ItemTemplate>
                                    <tr>
                                        <td><%# Eval("Bill_No") %></td>
                                        <td><%# Eval("Bill_Date","{0:dd-MM-yyyy}") %></td>
                                        <td style="text-align: right"><%# Eval("TaxableAmount","{0:0.00}") %></td>
                                        <td style="text-align: right"><%# Eval("CGST","{0:0.00}") %></td>
                                        <td style="text-align: right"><%# Eval("SGST","{0:0.00}") %></td>
                                        <td style="text-align: right"><%# Eval("Discount","{0:0.00}") %></td>
                                        <td style="text-align: right"><%# Eval("RoundOff","{0:0.00}") %></td>
                                        <td style="text-align: right"><%# Eval("GrandTotal","{0:0.00}") %></td>
                                    </tr>
                                </ItemTemplate>

                                <FooterTemplate>
                                    <tr style="font-weight: bold; background: #e6e6e6">
                                        <td colspan="2">GRAND TOTAL</td>
                                        <td style="text-align: right">
                                            <asp:Label ID="lblTaxableTotal" runat="server" />
                                        </td>
                                        <td style="text-align: right">
                                            <asp:Label ID="lblCGSTTotal" runat="server" />
                                        </td>
                                        <td style="text-align: right">
                                            <asp:Label ID="lblSGSTTotal" runat="server" />
                                        </td>
                                        <td style="text-align: right">
                                            <asp:Label ID="lblDiscountTotal" runat="server" />
                                        </td>
                                        <td style="text-align: right">
                                            <asp:Label ID="lblRoundTotal" runat="server" />
                                        </td>
                                        <td style="text-align: right">
                                            <asp:Label ID="lblGrandTotal" runat="server" />
                                        </td>
                                    </tr>
                                    </table>
                                </FooterTemplate>

                            </asp:Repeater>

                            <h4>GST Summary</h4>
                            <asp:Repeater ID="rptGSTSummary" runat="server">
                                <HeaderTemplate>
                                    <table class="table table-bordered">
                                        <tr style="font-weight: bold; background: #f9f9f9">
                                            <th>GST %</th>
                                            <th style="text-align: right">Taxable</th>
                                            <th style="text-align: right">CGST</th>
                                            <th style="text-align: right">SGST</th>
                                            <th style="text-align: right">Total</th>
                                        </tr>
                                </HeaderTemplate>

                                <ItemTemplate>
                                    <tr>
                                        <td><%# Eval("GSTPercent") %> %</td>
                                        <td style="text-align: right"><%# Eval("TaxableAmount","{0:0.00}") %></td>
                                        <td style="text-align: right"><%# Eval("CGST","{0:0.00}") %></td>
                                        <td style="text-align: right"><%# Eval("SGST","{0:0.00}") %></td>
                                        <td style="text-align: right"><%# Eval("TotalAmount","{0:0.00}") %></td>
                                    </tr>
                                </ItemTemplate>

                                <FooterTemplate>
                                    </table>
                                </FooterTemplate>
                            </asp:Repeater>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</asp:Content>
