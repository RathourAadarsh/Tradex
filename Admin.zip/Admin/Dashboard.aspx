﻿<%@ Page Title="" Language="C#" MasterPageFile="../Admin/AdminMaster.master" AutoEventWireup="true" CodeFile="Dashboard.aspx.cs" Inherits="Admin_Dashboard" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            padding-right: 0px !important;
        }

        .dashboard-bg {
            background: linear-gradient(135deg, #f0f4ff 0%, #ffffff 60%);
            padding-top: 15px;
        }

        .dashboard-card {
            border-radius: 20px;
            padding: 25px 10px;
            background: #ffffff;
            box-shadow: 0 10px 30px #6c757d;
            transition: all 0.3s ease-in-out;
            height: 100%;
            position: relative;
            overflow: hidden;
        }

            .dashboard-card:hover {
                transform: translateY(-8px);
                box-shadow: 0 18px 45px rgba(0,0,0,0.15);
            }

        .card-title {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 3px;
            color: #444;
            letter-spacing: 0.5px;
        }

        .card-number {
            font-size: 30px;
            font-weight: bold;
            color: #222;
        }

        .card-amount {
            font-size: 18px;
            font-weight: 600;
            color: #4e73df;
        }

        .icon-circle {
            width: 65px;
            height: 65px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            position: absolute;
            opacity: 0.4;
            font-size: 65px;
        }

        .card-kot {
            border-left: 6px solid #4e73df;
            color: blue;
        }

        .card-bill {
            border-left: 6px solid #1cc88a;
            color: #1cc88a;
        }

        .card-settle {
            border-left: 6px solid #f6c23e;
            color: #f6c23e;
        }

        .card-kot .card-amount {
            color: #4e73df;
        }

        .card-bill .card-amount {
            color: #1cc88a;
        }

        .card-settle .card-amount {
            color: #f6c23e;
        }

        @media (max-width:768px) {
            .card-number {
                font-size: 28px;
            }
        }

        @media (max-width: 768px) {

            .modal-dialog {
                margin: 10px;
            }

            .modal-content {
                border-radius: 12px;
            }

            .modal-body {
                padding: 10px;
                overflow-x: auto;
            }

            .table {
                font-size: 13px;
            }
        }

        @media (max-width: 767px) {
            #kotModal {
                padding-right: 0px !important;
            }

            #billModal {
                padding-right: 0px !important;
            }

            #settModal {
                padding-right: 0px !important;
            }
        }

        .chart-container {
            position: relative;
            height: 260px;
        }

        @media (max-width:768px) {
            .chart-container {
                height: 220px;
            }
        }
    </style>

    <script type="text/javascript" src="sweetalertnew.js"></script>
    <script type="text/javascript">
        function savealert(message, type) {
            swal({
                text: message,
                icon: type === 'success' ? 'success' : type === 'info' ? 'info' : type === 'error' ? 'error' : 'warning',
            });
        }
    </script>
    <script type="text/javascript">
        window.history.forward();
        function noBack() {
            window.history.forward();
        }
    </script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="Server">
    <asp:ScriptManager runat="server"></asp:ScriptManager>
    <div class="dashboard-bg">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-3">
                    <div class="dashboard-card card-kot" runat="server" onserverclick="KOT_Click" style="cursor: pointer;">
                        <div class="icon-circle">
                            <i class="fa fa-cutlery"></i>
                        </div>
                        <asp:LinkButton ID="btnKot" runat="server"
                            OnClick="KOT_Click"
                            Style="position: absolute; width: 100%; height: 100%; top: 0; left: 0; opacity: 0;">
                        </asp:LinkButton>
                        <h3 class="card-title text-center">Today Total KOT</h3>

                        <div class="text-center">
                            <span class="card-number" id="todaycountkot" runat="server">0</span>
                        </div>

                        <div class="text-center mt-2">
                            ₹ <span class="card-amount" id="todaytotalcountkot" runat="server">0.00</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="dashboard-card card-bill" runat="server" onserverclick="Bill_Click" style="cursor: pointer;">
                        <div class="icon-circle">
                            <i class="fa fa-file-text"></i>
                        </div>
                        <asp:LinkButton ID="LinkButton1" runat="server"
                            OnClick="Bill_Click"
                            Style="position: absolute; width: 100%; height: 100%; top: 0; left: 0; opacity: 0;"></asp:LinkButton>
                        <h3 class="card-title text-center">Today Total Bill</h3>

                        <div class="text-center">
                            <span class="card-number" id="todaycountbill" runat="server">0</span>
                        </div>

                        <div class="text-center mt-2">
                            ₹ <span class="card-amount" id="todaytotalcountbill" runat="server">0.00</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="dashboard-card card-settle" runat="server" onserverclick="Settlement_Click" style="cursor: pointer;">
                        <div class="icon-circle">
                            <i class="fa fa-credit-card"></i>
                        </div>
                        <asp:LinkButton ID="LinkButton2" runat="server"
                            OnClick="Settlement_Click"
                            Style="position: absolute; width: 100%; height: 100%; top: 0; left: 0; opacity: 0;">
                        </asp:LinkButton>
                        <h3 class="card-title text-center">Total Settlement</h3>

                        <div class="text-center">
                            <span class="card-number" id="todaycountsett" runat="server">0</span>
                        </div>

                        <div class="text-center mt-2">
                            ₹ <span class="card-amount" id="todaytotalcountsett" runat="server">0.00</span>
                        </div>
                    </div>
                </div>
            </div>
            <div>
                <div>
                    <div class="container mt-4">
                        <div class="row mb-3">
                            <div class="col-md-2"></div>
                            <div class="col-md-3">
                                <asp:TextBox ID="txtFrom" runat="server" CssClass="form-control" TextMode="Date"></asp:TextBox>
                            </div>
                            <div class="col-md-3">
                                <asp:TextBox ID="txtTo" runat="server" CssClass="form-control" TextMode="Date"></asp:TextBox>
                            </div>
                            <div class="col-md-2">
                                <asp:Button ID="btnFilter" runat="server" Text="Filter"
                                    CssClass="btn btn-primary w-100"
                                    OnClick="btnFilter_Click" />
                            </div>
                        </div>
                        <div class="row mt-4">

                            <!-- Group Wise Chart -->
                            <div class="col-lg-8 mb-3">
                                <div class="card shadow">
                                    <div class="card-header bg-primary text-white">
                                        Group Wise Sale Chart
                                    </div>
                                    <asp:HiddenField ID="hfLabels" runat="server" />
                                    <asp:HiddenField ID="hfData" runat="server" />
                                    <asp:HiddenField ID="hfColors" runat="server" />
                                    <div class="card-body">
                                        <canvas id="groupChart" style="height: 260px !important;"></canvas>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <div class="card shadow">
                                    <asp:HiddenField ID="hfPaymentLabels" runat="server" />
                                    <asp:HiddenField ID="hfPaymentData" runat="server" />
                                    <asp:HiddenField ID="hfPaymentColors" runat="server" />
                                    <div class="card-header bg-success text-white">
                                        Payment Mode Distribution
           
                                    </div>
                                    <div class="card-body">
                                        <div class="chart-container">
                                            <canvas id="paymentChart"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="kotModal" tabindex="-1">
                <div class="modal-dialog modal-lg modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header bg-primary text-white">
                            <h5 class="modal-title">Today KOT Details</h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="table-responsive">
                                <asp:GridView ID="gvKot" runat="server"
                                    CssClass="table table-bordered table-striped"
                                    AutoGenerateColumns="false" ShowFooter="true" OnRowDataBound="gvKot_RowDataBound">
                                    <Columns>
                                        <asp:BoundField DataField="Table_No" HeaderText="Table No" />
                                        <asp:BoundField DataField="KOT_No" HeaderText="KOT No" />
                                        <asp:BoundField DataField="Grandtotal"
                                            HeaderText="Total Amount"
                                            DataFormatString="₹ {0:N2}"
                                            HtmlEncode="false" HeaderStyle-CssClass="text-end" ItemStyle-CssClass="text-end" FooterStyle-CssClass="text-end fw-bold"></asp:BoundField>
                                    </Columns>
                                </asp:GridView>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="billModal" tabindex="-1">
                <div class="modal-dialog modal-lg modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header bg-success text-white">
                            <h5 class="modal-title">Today Bill Details</h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="table-responsive">
                                <asp:GridView ID="gvBill" runat="server"
                                    CssClass="table table-bordered table-striped"
                                    AutoGenerateColumns="false" ShowFooter="true" OnRowDataBound="gvBill_RowDataBound">
                                    <Columns>
                                        <asp:BoundField DataField="Table_No" HeaderText="Table No" />
                                        <asp:BoundField DataField="Bill_No" HeaderText="Bill No" />
                                        <asp:BoundField DataField="Grandtotal" HeaderText="Total Amount" DataFormatString="₹ {0:N2}" HeaderStyle-CssClass="text-end" ItemStyle-CssClass="text-end" FooterStyle-CssClass="text-end fw-bold" />
                                    </Columns>
                                </asp:GridView>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="settModal" tabindex="-1">
                <div class="modal-dialog modal-lg modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header bg-warning text-dark">
                            <h5 class="modal-title">Today Settlement Details</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="table-responsive">
                                <asp:GridView ID="gvSettlement" runat="server"
                                    CssClass="table table-bordered table-striped"
                                    AutoGenerateColumns="false" ShowFooter="true" OnRowDataBound="gvSettlement_RowDataBound">
                                    <Columns>
                                        <asp:BoundField DataField="Table_No" HeaderText="Table No" />
                                        <asp:BoundField DataField="Bill_No" HeaderText="Bill No" />
                                        <asp:BoundField DataField="Grandtotal" HeaderText="Total Amount" DataFormatString="₹ {0:N2}" HeaderStyle-CssClass="text-end" ItemStyle-CssClass="text-end" FooterStyle-CssClass="text-end fw-bold" />
                                    </Columns>
                                </asp:GridView>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function openModal(type) {

            let title = "";
            let count = "";
            let amount = "";

            if (type === "KOT") {
                title = "Today Total KOT";
                count = document.getElementById("<%=todaycountkot.ClientID%>").innerText;
                amount = document.getElementById("<%=todaytotalcountkot.ClientID%>").innerText;
            }
            else if (type === "BILL") {
                title = "Today Total Bill";
                count = document.getElementById("<%=todaycountbill.ClientID%>").innerText;
                amount = document.getElementById("<%=todaytotalcountbill.ClientID%>").innerText;
            }
            else if (type === "SETTLEMENT") {
                title = "Total Settlement";
                count = document.getElementById("<%=todaycountsett.ClientID%>").innerText;
                amount = document.getElementById("<%=todaytotalcountsett.ClientID%>").innerText;
            }

            document.getElementById("modalTitle").innerText = title;
            document.getElementById("modalCount").innerText = "Total Count : " + count;
            document.getElementById("modalAmount").innerText = amount;

            var myModal = new bootstrap.Modal(document.getElementById('detailModal'));
            myModal.show();
        }
    </script>
    <script>
        function loadChart() {

            var lblValue = document.getElementById("<%=hfLabels.ClientID%>").value;
            var dataValue = document.getElementById("<%=hfData.ClientID%>").value;
            var colorValue = document.getElementById("<%=hfColors.ClientID%>").value;

            if (!lblValue || !dataValue) return;

            var labels = JSON.parse(lblValue);
            var data = JSON.parse(dataValue);
            var colors = JSON.parse(colorValue);

            var canvas = document.getElementById('groupChart');
            if (!canvas) return;

            var ctx = canvas.getContext('2d');

            if (window.myChart) {
                window.myChart.destroy();
            }

            window.myChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        data: data,
                        backgroundColor: colors
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }
        window.addEventListener("load", loadChart);
    </script>
    <script>
        function loadPaymentChart() {

            var lbl = document.getElementById("<%=hfPaymentLabels.ClientID%>").value;
            var dataVal = document.getElementById("<%=hfPaymentData.ClientID%>").value;
            var colorVal = document.getElementById("<%=hfPaymentColors.ClientID%>").value;

            if (!lbl) return;

            var labels = JSON.parse(lbl);
            var data = JSON.parse(dataVal);
            var colors = JSON.parse(colorVal);

            var ctx = document.getElementById("paymentChart").getContext("2d");

            if (window.paymentChartObj) {
                window.paymentChartObj.destroy();
            }

            window.paymentChartObj = new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: labels,
                    datasets: [{
                        data: data,
                        backgroundColor: colors
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });
        }

        window.addEventListener("load", function () {
            loadPaymentChart();
        });
    </script>
</asp:Content>

