﻿<%@ Page Title="" Language="C#" MasterPageFile="../Admin/AdminMaster.master" AutoEventWireup="true" CodeFile="Offer.aspx.cs" Inherits="Offer" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
    <style>
        .offer-card {
            background: #fff;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            /*max-width: 900px;*/
        }

        .form-label {
            font-weight: 600;
            margin-bottom: 4px;
        }

        .note {
            font-size: 12px;
        }

        .items-box {
            border: 1px solid #ddd;
            border-radius: 6px;
            height: 220px;
            overflow-y: auto;
            padding: 10px;
        }

        .group-row {
            display: flex;
            align-items: center;
            margin: 6px 0;
            font-weight: 500;
        }

        .toggle-icon {
            width: 18px;
            height: 18px;
            border: 1px solid #999;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            margin-right: 6px;
            font-size: 14px;
            user-select: none;
        }

        .items-container {
            padding-left: 10px;
        }

        .treeview-bootstrap {
            font-size: 14px;
        }

            .treeview-bootstrap input[type=checkbox] {
                margin-right: 6px;
            }

            .treeview-bootstrap a {
                text-decoration: none !important;
                color: #000;
                pointer-events: none;
            }

            .treeview-bootstrap img {
                pointer-events: auto;
            }

        .treeview-bootstrap {
            font-size: 14px;
        }

            .treeview-bootstrap input[type=checkbox] {
                margin-right: 6px;
            }

            .treeview-bootstrap a {
                text-decoration: none !important;
                color: #000;
                pointer-events: none;
            }

            .treeview-bootstrap img {
                pointer-events: auto;
            }

            .treeview-bootstrap ul.items {
                display: none;
            }

            .treeview-bootstrap .toggle {
                cursor: pointer;
                font-weight: bold;
                margin-right: 6px;
            }

            .treeview-bootstrap ul.groups {
                display: block;
            }

            .treeview-bootstrap ul.items {
                display: none;
            }

            .treeview-bootstrap .toggle {
                cursor: pointer;
                font-weight: bold;
                margin-right: 6px;
            }

            .treeview-bootstrap ul {
                padding-left: 1rem;
            }

            .treeview-bootstrap ul,
            .treeview-bootstrap li {
                list-style: none !important;
            }

            .treeview-bootstrap .toggle {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                width: 18px;
                height: 18px;
                border: 1px solid #555;
                border-radius: 3px;
                font-size: 14px;
                font-weight: bold;
                line-height: 1;
                margin-right: 6px;
                cursor: pointer;
                user-select: none;
                background: #fff;
                color: #000;
            }

                .treeview-bootstrap .toggle:hover {
                    background: #e9ecef;
                }

                .treeview-bootstrap .toggle.open {
                    background: #f1f1f1;
                }

        .text-muted {
            font-size: 12px;
        }

        .form-control {
            height: 31px;
        }

        .offer-card {
            background: #ffffff;
            border-radius: 10px;
            padding: 22px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        }

        .section-title {
            font-size: 15px;
            font-weight: 600;
            color: #0d6efd;
            border-bottom: 1px solid #e5e5e5;
            padding-bottom: 6px;
            margin: 18px 0 12px;
        }

        .section-title1 {
            border-bottom: 1px solid #e5e5e5;
            padding: 6px;
            text-align: center;
        }

        .form-label {
            font-size: 13px;
            font-weight: 600;
            color: #333;
        }

        .form-control,
        .form-select {
            height: 34px;
            font-size: 13px;
        }

        .form-check {
            margin-right: 12px;
        }

        .note,
        .text-muted {
            font-size: 11px;
        }

        .tree-card {
            border: 1px solid #ddd;
            border-radius: 6px;
            padding: 10px;
            background: #fafafa;
        }

        .treeview-bootstrap {
            font-size: 13px;
        }

            .treeview-bootstrap li {
                margin: 3px 0;
            }

            .treeview-bootstrap .toggle {
                width: 16px;
                height: 16px;
                border: 1px solid #666;
                border-radius: 3px;
                font-size: 12px;
            }

                .treeview-bootstrap .toggle.open {
                    background: #e9ecef;
                }

        .bogo-box {
            background: #f8f9fa;
            border: 1px dashed #0d6efd;
            border-radius: 6px;
            padding: 12px;
        }

        .footer-actions {
            border-top: 1px solid #eee;
            padding-top: 12px;
            margin-top: 20px;
            text-align: right;
        }

        .swal-footer {
            text-align: center !important;
        }

        .swal-text {
            font-size: 22px !important;
            text-align: center;
        }

        .swal-button {
            background-color: #184f34 !important;
        }

        .chk-gap input {
            margin-right: 6px;
        }
    </style>
    <script type="text/javascript" src="sweetalertnew.js"></script>
    <script type="text/javascript">
        function savealert(message, type) {
            swal({
                text: message,
                icon: type === 'success' ? 'success' : type === 'info' ? 'info' : type === 'error' ? 'error' : 'warning',
            });
        }
    </script>
    <script type="text/javascript">
        window.history.forward();
        function noBack() {
            window.history.forward();
        }
    </script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="Server">
    <main>
        <div class="container" style="margin-top: 4.5rem !important;">
            <div class="offer-card">
                <div class="section-title1">
                    <h2>Special Offer</h2>
                </div>
                <div class="row">
                    <div class="section-title">Offer Basic Details</div>
                    <div class="col-md-2">
                        <div class="mb-2">
                            <label class="form-label">Offer Title<span class="text-danger">*</span></label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="mb-2">
                            <asp:TextBox ID="txtTitle" runat="server" CssClass="form-control"
                                placeholder="NEW YEAR 2026 OFFER"></asp:TextBox>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="mb-2">
                            <label class="form-label">Order Type <span class="text-danger">*</span></label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="mb-2">
                            <asp:CheckBox ID="chkDelivery" runat="server" Text=" Delivery" Checked="true" CssClass="chk-gap" />
                            &nbsp;&nbsp;
            <asp:CheckBox ID="chkPickup" runat="server" Text=" Pick Up" CssClass="chk-gap" />
                            &nbsp;&nbsp;
            <asp:CheckBox ID="chkDineIn" runat="server" Text=" Dine In" CssClass="chk-gap" />
                        </div>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Status</label>
                    </div>
                    <div class="col-md-4">
                        <asp:CheckBox ID="checkstatus" runat="server" Text=" Active" Checked="true" CssClass="chk-gap" />
                    </div>
                    <div class="section-title">Discount Configuration</div>
                    <div class="col-md-2">
                        <div class="mb-2">
                            <label class="form-label">Discount on <span class="text-danger">*</span></label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="mb-2">
                            <asp:DropDownList ID="ddlDiscountOn" runat="server" CssClass="form-select">
                                <asp:ListItem Text="Point Of Sale" Value="POS" />
                                <asp:ListItem Text="Online Order" Value="ONLINE" />
                            </asp:DropDownList>
                            <div class="note">One time configuration</div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="mb-2">
                            <label class="form-label">Discount Type <span class="text-danger">*</span></label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="mb-2">
                            <asp:RadioButton ID="rbPercent" runat="server" GroupName="discountType" Text=" Percentage" Checked="true" CssClass="chk-gap" />
                            &nbsp;&nbsp;
                            <asp:RadioButton ID="rbFixed" runat="server" GroupName="discountType" Text=" Fixed" CssClass="chk-gap" />
                            &nbsp;&nbsp;
                            <asp:RadioButton ID="rbBOGO" runat="server" GroupName="discountType" Text=" BOGO" CssClass="chk-gap" />
                            &nbsp;&nbsp;
                            <asp:RadioButton ID="rbFixedPrice" runat="server" GroupName="discountType" Text=" Fixed Price" CssClass="chk-gap" />
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="mb-2">
                            <label class="form-label">Add Discount On <span class="text-danger">*</span></label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="mb-2">
                            <asp:RadioButton ID="rbAmount" runat="server" GroupName="addDiscount" Text=" Bill Amount" Checked="true" CssClass="chk-gap" />
                            &nbsp;&nbsp;
              <asp:RadioButton ID="rbPayment" runat="server" GroupName="addDiscount" Text=" Payment Type" CssClass="chk-gap" />
                        </div>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Min Bill Amount</label>
                    </div>
                    <div class="col-md-4">
                        <asp:TextBox ID="txtItemLimit" runat="server" CssClass="form-control" />
                        <small class="text-muted">Leave blank for no limit</small>
                    </div>
                    <div class="section-title">BOGO Configuration</div>
                    <div class="col-md-2">
                        <div class="mb-2">
                            <label class="form-label">BOGO Offer Details </label>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="mb-2">
                            <label class="form-label">Buy</label>
                            <asp:TextBox ID="txtbuy" runat="server" CssClass="form-control"></asp:TextBox>
                            <small class="text-muted">For Ex: Buy 2 Get 2</small>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="mb-2">
                            <label class="form-label">Get</label>
                            <asp:TextBox ID="txtget" runat="server" CssClass="form-control"></asp:TextBox>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="mb-2">
                            <label class="form-label">Discount Type</label>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div>
                            <asp:RadioButton ID="RadioButton1" runat="server" Text="Percentage" Checked="true" CssClass="chk-gap" />
                            &nbsp;&nbsp; 
                            <asp:RadioButton ID="RadioButton2" runat="server" Text=" Fixed" CssClass="chk-gap" />
                        </div>
                        <small class="text-muted">Please Select BOGO Discount Type</small>
                    </div>
                    <div class="col-md-2">
                        <div class="mb-2">
                            <label class="form-label">Discount Amount<span class="text-danger">*</span></label>
                        </div>
                    </div>
                    <div class="col-md-4 mb-2">
                        <div>
                            <asp:TextBox ID="txtamount" runat="server" CssClass="form-control"></asp:TextBox>
                        </div>
                        <small class="text-muted mb-3">Should be between 1% to 100% for Percentage Discounts</small>
                    </div>
                    <div class="col-md-2">
                        <div class="mb-2">
                            <label class="form-label">Get Item Type</label>
                        </div>
                    </div>
                    <div class="col-md-4 mb-2">
                        <div>
                            <asp:RadioButton ID="rbGetLower" runat="server"
                                GroupName="getItemType" Text=" Lower Price" Checked="true" CssClass="chk-gap" />&nbsp;&nbsp;
                            <asp:RadioButton ID="rbGetHigher" runat="server"
                                GroupName="getItemType" Text=" Higher Price" CssClass="chk-gap" />&nbsp;&nbsp;
                            <asp:RadioButton ID="rbGetSame" runat="server"
                                GroupName="getItemType" Text=" Same Item Only" CssClass="chk-gap" />
                        </div>
                        <small class="text-muted">Please Select Bogo get item type.</small>
                    </div>
                    <div class="col-md-2">
                        <div class="mb-2">
                            <label class="form-label">Buy Item Type</label>
                        </div>
                    </div>
                    <div class="col-md-4 mb-2">
                        <div>
                            <asp:RadioButton ID="rbBuyLower" runat="server"
                                GroupName="buyItemType" Text=" Lower Price" Checked="true" CssClass="chk-gap" />&nbsp;&nbsp;
                            <asp:RadioButton ID="rbBuyHigher" runat="server"
                                GroupName="buyItemType" Text=" Higher Price" CssClass="chk-gap" />
                        </div>
                        <%--<small class="text-muted">Please select Bogo  buy item type. This will work only if "Bogo Buy Amount" is proper defined. </small>--%>
                    </div>
                    <div class="col-md-2">
                        <div class="mb-2">
                            <label class="form-label">Buy Amount</label>
                        </div>
                    </div>
                    <div class="col-md-4 mb-2">
                        <div>
                            <asp:TextBox ID="txtbogobuyamt" runat="server" CssClass="form-control"></asp:TextBox>
                        </div>
                        <small class="text-muted mb-3">Should be between 1% to 100% for Percentage Discounts</small>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="section-title">Applicable Items (Buy)</div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="mb-2">
                                    <label class="form-label">Applicable On (Buy)</label>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="mb-2">
                                    <asp:RadioButton ID="rbAll" runat="server" GroupName="applicable" Text=" All" CssClass="chk-gap" />
                                    &nbsp;&nbsp;
                            <asp:RadioButton ID="rbCategory" runat="server" GroupName="applicable" Text=" Categories" CssClass="chk-gap" />
                                    &nbsp;&nbsp;
                            <asp:RadioButton ID="rbItems" runat="server" GroupName="applicable" Text=" Items" Checked="true" CssClass="chk-gap" />
                                </div>
                            </div>
                            <div class="col-md-4"></div>
                            <div class="col-md-8">
                                <div style="border: 1px solid #ccc; height: calc(50vh - 87px); overflow-y: auto;">
                                    <ul id="itemTree" class="treeview-bootstrap">
                                        <li class="root-li">
                                            <span class="toggle root-toggle">+</span>
                                            <input type="checkbox" id="chkAll" />
                                            <strong>Select All</strong>
                                            <ul class="groups">
                                                <asp:Repeater ID="rptGroup" runat="server"
                                                    OnItemDataBound="rptGroup_ItemDataBound">
                                                    <ItemTemplate>
                                                        <li class="group-li">
                                                            <span class="toggle">+</span>
                                                            <input type="checkbox" class="group" />
                                                            <%# Eval("item_g_name") %>

                                                            <ul class="items">
                                                                <asp:Repeater ID="rptItem" runat="server">
                                                                    <ItemTemplate>
                                                                        <li>
                                                                            <input type="checkbox"
                                                                                class="item"
                                                                                value='<%# Eval("Sku") %>' />
                                                                            <%# Eval("item_name") %>
                                                                        </li>
                                                                    </ItemTemplate>
                                                                </asp:Repeater>
                                                            </ul>
                                                        </li>
                                                    </ItemTemplate>
                                                </asp:Repeater>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="section-title">Validity & Scheduling</div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="mb-2">
                                    <label class="form-label">Discount validity</label>
                                </div>
                            </div>
                            <div class="col-md-4 mb-2">
                                <div>
                                    <label class="form-label">From Date</label>
                                    <asp:TextBox ID="txtfrom" runat="server" CssClass="form-control" TextMode="Date"></asp:TextBox>
                                </div>
                                <small class="text-muted mb-3">Leave blank if you want it lifetime.</small>
                            </div>
                            <div class="col-md-4 mb-2">
                                <div>
                                    <label class="form-label">To Date</label>
                                    <asp:TextBox ID="txtro" runat="server" CssClass="form-control" TextMode="Date"></asp:TextBox>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-2">
                                    <label class="form-label">Applicable Time</label>
                                </div>
                            </div>
                            <div class="col-md-4 mb-2">
                                <div>
                                    <label class="form-label">From</label>
                                    <asp:TextBox ID="txtapptimefrom" runat="server" CssClass="form-control" TextMode="Time"></asp:TextBox>
                                </div>
                                <small class="text-muted">Leave blank if you want it for whole days.</small>
                            </div>
                            <div class="col-md-4 mb-2">
                                <div>
                                    <label class="form-label">To</label>
                                    <asp:TextBox ID="txtapptimeto" runat="server" CssClass="form-control" TextMode="Time"></asp:TextBox>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-2">
                                    <label class="form-label">Days<span class="text-danger">*</span></label>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="mb-2">
                                    <asp:CheckBox ID="checkalldate" runat="server" Text="All Days" Checked="true" CssClass="chk-gap" />
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-2">
                                    <label class="form-label">Description</label>
                                </div>
                            </div>
                            <div class="col-md-8 mb-2">
                                <div>
                                    <asp:TextBox ID="txtdesciption" runat="server" CssClass="form-control"></asp:TextBox>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-2">
                                    <label class="form-label">Terms & Conditions</label>
                                </div>
                            </div>
                            <div class="col-md-8 mb-2">
                                <div>
                                    <asp:TextBox ID="txtterm" runat="server" CssClass="form-control"></asp:TextBox>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="text-end">
                    <asp:Button ID="btnSave" runat="server" Text="Save Offer"
                        CssClass="btn btn-success" />
                </div>
            </div>
        </div>
    </main>
    <script>
        function toggleItems(el) {

            var itemsDiv = el.parentElement.nextElementSibling;

            if (itemsDiv.style.display === "none") {
                itemsDiv.style.display = "block";
                el.innerText = "-";
            } else {
                itemsDiv.style.display = "none";
                el.innerText = "+";
            }
        }
    </script>
    <script>
        document.getElementById("itemTree").addEventListener("change", function (e) {
            const cb = e.target;
            if (cb.type !== "checkbox") return;
            const li = cb.closest("li");
            if (cb.id === "chkAll") {
                document.querySelectorAll("#itemTree input[type=checkbox]")
                    .forEach(x => x.checked = cb.checked);
                return;
            }
            if (cb.classList.contains("group")) {
                li.querySelectorAll("input[type=checkbox]")
                    .forEach(x => x.checked = cb.checked);
            }
            updateParents(li);
        });

        function updateParents(li) {
            let parent = li.parentElement.closest("li");
            if (!parent) return;
            const checkboxes = parent.querySelectorAll(":scope > ul input[type=checkbox]");
            const parentCB = parent.querySelector("input[type=checkbox]");
            parentCB.checked = [...checkboxes].every(x => x.checked);
            updateParents(parent);
        }
    </script>
    <script>
        document.addEventListener("click", function (e) {
            if (!e.target.classList.contains("toggle")) return;
            const toggle = e.target;
            const li = toggle.closest("li");
            if (toggle.classList.contains("root-toggle")) {
                const groupUL = li.querySelector(".groups");
                if (!groupUL) return;

                if (groupUL.style.display === "none") {
                    groupUL.style.display = "block";
                    toggle.textContent = "−";
                    toggle.classList.add("open");
                } else {
                    groupUL.style.display = "none";
                    toggle.textContent = "+";
                    toggle.classList.remove("open");
                }
                return;
            }
            const itemsUL = li.querySelector(".items");
            if (!itemsUL) return;

            if (itemsUL.style.display === "none" || itemsUL.style.display === "") {
                itemsUL.style.display = "block";
                toggle.textContent = "−";
                toggle.classList.add("open");
            } else {
                itemsUL.style.display = "none";
                toggle.textContent = "+";
                toggle.classList.remove("open");
            }
        });
    </script>
</asp:Content>

