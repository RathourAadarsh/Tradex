﻿<%@ Page Title="" Language="C#" MasterPageFile="../Admin/AdminMaster.master" AutoEventWireup="true" CodeFile="ItemGroup.aspx.cs" Inherits="Admin_ItemGroup" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
    <link href="Style.css" rel="stylesheet" />
    <style>
        .swal-footer {
            text-align: center !important;
        }

        .swal-text {
            font-size: 22px !important;
            text-align: center;
        }

        .swal-button {
            background-color: #184f34 !important;
        }
    </style>
    <script type="text/javascript" src="sweetalertnew.js"></script>
    <script type="text/javascript">
        function savealert(message, type) {
            swal({
                text: message,
                icon: type === 'success' ? 'success' : type === 'info' ? 'info' : type === 'error' ? 'error' : 'warning',
            });
        }
    </script>
    <script type="text/javascript">
        window.history.forward();
        function noBack() {
            window.history.forward();
        }
    </script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="Server">
    <asp:ScriptManager ID="ScriptManager1" runat="server" />
    <div class="dashboard-bg">
        <div class="container">
            <div class="row" style="margin-top: 60px !important;">
                <div class="col-md-5" style="border: 1px solid; height: 390px;">
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-12">
                                <h5 style="text-align: center; font-weight: 600; padding-top: 10px;">Item Group Master</h5>
                            </div>
                        </div>
                    </div>
                    <hr />
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-1"></div>
                            <div class="col-md-4">
                                <asp:Label runat="server" ID="lblb" Text="Group ID" ForeColor="Black"></asp:Label>
                            </div>
                            <div class="col-md-6">
                                <asp:TextBox runat="server" ID="txtgid" CssClass="form-control"></asp:TextBox>
                            </div>
                            <div class="col-md-1"></div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-1"></div>
                            <div class="col-md-4">
                                <asp:Label runat="server" ID="Label2" Text="Parents Group Name" ForeColor="Black"></asp:Label>
                            </div>
                            <div class="col-md-6">
                                <asp:DropDownList runat="server" ID="ddlpname" CssClass="form-control" AutoPostBack="true" OnSelectedIndexChanged="ddlpname_SelectedIndexChanged">
                                    <asp:ListItem Text="--Select--" Selected="True" Value="--Select--"></asp:ListItem>
                                    <asp:ListItem Text="Food" Value="FOODING"></asp:ListItem>
                                    <asp:ListItem Text="Bar" Value="Bar"></asp:ListItem>
                                </asp:DropDownList>
                            </div>
                            <div class="col-md-1"></div>
                        </div>
                    </div>
                    <div class="form-group">

                        <div class="row">
                            <div class="col-md-1"></div>
                            <div class="col-md-4">
                                <asp:Label runat="server" ID="Label3" Text="Subparents Group Name" ForeColor="Black"></asp:Label>
                            </div>
                            <div class="col-md-6">
                                <asp:DropDownList runat="server" ID="ddlsubparents" CssClass="form-control" AutoPostBack="true" OnSelectedIndexChanged="ddlsubparents_SelectedIndexChanged">
                                </asp:DropDownList>
                            </div>
                            <div class="col-md-1"></div>
                        </div>

                    </div>
                    <asp:Panel runat="server" ID="panel1" Visible="false">
                        <div class="form-group">
                            <asp:UpdatePanel ID="upd1" runat="server" UpdateMode="Conditional">
                                <ContentTemplate>
                                    <div class="row">
                                        <div class="col-md-1"></div>
                                        <div class="col-md-4">
                                            <asp:Label runat="server" ID="Label4" Text="Child Group Name" ForeColor="Black"></asp:Label>
                                        </div>
                                        <div class="col-md-6">
                                            <asp:DropDownList runat="server" ID="ddlchildbargroup" CssClass="form-control"></asp:DropDownList>
                                        </div>
                                        <div class="col-md-1"></div>
                                    </div>
                                </ContentTemplate>
                                <Triggers>
                                    <asp:AsyncPostBackTrigger ControlID="ddlsubparents" EventName="SelectedIndexChanged" />
                                </Triggers>
                            </asp:UpdatePanel>
                        </div>
                    </asp:Panel>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-1"></div>
                            <div class="col-md-4">
                                <asp:Label runat="server" ID="Label1" Text="Group Name" ForeColor="Black"></asp:Label>
                            </div>
                            <div class="col-md-6">
                                <asp:TextBox runat="server" ID="txtgrpname" CssClass="form-control"></asp:TextBox>
                            </div>
                            <div class="col-md-1"></div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-5"></div>
                            <div class="col-md-4">
                                <asp:Button runat="server" ID="btnsave" Text="Save" CssClass="btn btn-success" OnClick="btnsave_Click"></asp:Button>
                                <asp:Button runat="server" ID="btnback" Text="Back" CssClass="btn btn-danger" OnClick="btnback_Click"></asp:Button>
                            </div>
                            <div class="col-md-3"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-7" style="overflow: scroll; height: 500px;">
                    <div class="row">
                        <div class="col-md-12">
                            <asp:ListView ID="listview2" runat="server" Style="color: black !important; width: 100%">
                                <LayoutTemplate>
                                    <table class="table table-bordered">
                                        <tr>
                                            <th style="width: 12%;">Group ID</th>
                                            <th style="width: 15%;">Parents Group</th>
                                            <th style="width: 17%;">SubParents Group</th>
                                            <th style="width: 16%;">Child Group</th>
                                            <th style="width: 20%;">Group Name</th>
                                            <th style="width: 20%;">Action</th>
                                        </tr>
                                        <tbody>
                                            <asp:PlaceHolder ID="itemPlaceHolder" runat="server" />
                                        </tbody>
                                    </table>
                                </LayoutTemplate>
                                <ItemTemplate>
                                    <tr>
                                        <td>
                                            <asp:Label ID="lblcode" runat="server" Text=' <%# Eval("item_g_id")%>'></asp:Label></td>
                                        <td>
                                            <asp:Label ID="Label5" runat="server" Text=' <%# Eval("pgroupname")%>'></asp:Label></td>
                                        <td>
                                            <asp:Label ID="Label6" runat="server" Text=' <%# Eval("subpgroupname")%>'></asp:Label></td>
                                        <td>
                                            <asp:Label ID="Label7" runat="server" Text=' <%# Eval("childgroupname")%>'></asp:Label></td>
                                        <td>
                                            <asp:Label ID="lblitemname" runat="server" Text=' <%# Eval("Item_G_Name")%>'></asp:Label></td>
                                        <td>
                                            <asp:Button runat="server" ID="btnedit" Text="Edit" CssClass="btn btn-warning" OnClick="btnedit_Click" Style="padding: 5px !important;" />
                                            <asp:Button runat="server" ID="btndelete" Text='<%# Eval("inactive")%>' CssClass="btn btn-danger" OnClick="btndelete_Click" OnClientClick="return showConfirm();" Style="padding: 5px !important;" />
                                        </td>
                                    </tr>
                                </ItemTemplate>
                            </asp:ListView>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</asp:Content>

