﻿<%@ Page Title="" Language="C#" MasterPageFile="../Admin/AdminMaster.master" AutoEventWireup="true" CodeFile="EditPurchase.aspx.cs" Inherits="Admin_EditPurchase" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="Server">
    <main>
        <div class="container" style="margin-top: 30px;">
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-10" style="border: 1px solid;">
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-12">
                                <h5 style="text-align: center; margin-top: 15px; font-weight: 600;">Purchase Detail</h5>
                            </div>
                        </div>
                    </div>
                    <div class="row" style="border-top: 1px solid; margin-top: 10px;">
                        <div class="col-md-12">
                            <div class="row mt-3 mb-2">
                                <div class="col-md-2 text-end">
                                    <asp:TextBox ID="txtFilterDate" runat="server"
                                        TextMode="Date" CssClass="form-control"></asp:TextBox>
                                </div>
                                <div class="col-md-1 text-end">
                                    <asp:Button ID="btnDateFilter" runat="server"
                                        Text="Filter" CssClass="btn btn-success"
                                        OnClick="btnDateFilter_Click" />
                                </div>
                                <div class="col-md-4 text-end">
                                    <asp:LinkButton ID="btnDirect" runat="server"
                                        CssClass="btn btn-success"
                                        OnClick="btnDirect_Click">Direct Purchase
                                    </asp:LinkButton>
                                    <asp:LinkButton ID="btnKitchen" runat="server"
                                        CssClass="btn btn-warning"
                                        OnClick="btnKitchen_Click">Issue To Kitchen
                                    </asp:LinkButton>

                                </div>
                                <div class="col-md-3">
                                    <asp:TextBox ID="txtSearchPno" runat="server" CssClass="form-control" placeholder="Enter PNo"></asp:TextBox>

                                </div>
                                <div class="col-md-2">
                                    <asp:Button ID="btnSearch" runat="server" Text="Search"
                                        CssClass="btn btn-primary"
                                        OnClick="btnSearch_Click" />
                                    <asp:Button ID="btnReset" runat="server" Text="Reset"
                                        CssClass="btn btn-secondary"
                                        OnClick="btnReset_Click" />

                                </div>
                            </div>
                            <div class="col-md-12 p-0" style="overflow-y: scroll; height: 450px;">
                                <asp:ListView ID="listview2" runat="server" Style="color: black !important;" OnPagePropertiesChanging="listview2_PagePropertiesChanging">
                                    <LayoutTemplate>
                                        <table class="table table-bordered">
                                            <tr>
                                                <th style="width: 5%;">ID</th>
                                                <th style="width: 8%;">Pur. No</th>
                                                <th style="width: 8%;">Pur. Date</th>
                                                <th style="width: 8%;">Inv. No</th>
                                                <th style="width: 8%;">Inv. Date</th>
                                                <th style="width: 8%;">Type</th>
                                                <th style="width: 20%;">Item Name</th>
                                                <th style="width: 10%;">Qty</th>
                                                <th style="width: 8%; text-align: right;">Rate</th>
                                                <th style="width: 8%; text-align: right;">Amount</th>
                                                <th style="width: 8%;">Date</th>
                                                <th style="width: 10%;">Action</th>
                                            </tr>
                                            <tbody>
                                                <asp:PlaceHolder ID="itemPlaceHolder" runat="server" />
                                            </tbody>
                                        </table>
                                    </LayoutTemplate>

                                    <ItemTemplate>
                                        <tr>
                                            <td>
                                                <asp:Label ID="lblcode" runat="server" Text=' <%# Eval("pid")%>'></asp:Label>
                                            </td>
                                            <td>
                                                <asp:Label ID="Label4" runat="server" Text=' <%# Eval("pno")%>'></asp:Label></td>
                                            <td>
                                                <asp:Label ID="Label5" runat="server" Text=' <%# Eval("pdate")%>'></asp:Label></td>
                                            <td>
                                                <asp:Label ID="lblinv" runat="server" Text=' <%# Eval("pinv")%>'></asp:Label></td>
                                            <td>
                                                <asp:Label ID="lbldate" runat="server" Text=' <%# Eval("pinvdt")%>'></asp:Label></td>
                                            <td>
                                                <asp:Label ID="lbltype" runat="server" Text=' <%# Eval("ptype")%>'></asp:Label></td>
                                            <td>
                                                <asp:Label ID="lblitemname" runat="server" Text=' <%# Eval("Item_name")%>'></asp:Label></td>
                                            <td>
                                                <asp:Label ID="lblqty" runat="server" Text=' <%# Eval("qty")%>'></asp:Label></td>
                                            <td style="text-align: right">
                                                <asp:Label ID="lblrate" runat="server" Text=' <%# Eval("rate")%>'></asp:Label></td>
                                            <td style="text-align: right">
                                                <asp:Label ID="lblamount" runat="server" Text=' <%# Eval("amount")%>'></asp:Label></td>
                                            <td>
                                                <asp:Label ID="lbldat" runat="server" Text=' <%# Eval("date")%>'></asp:Label></td>
                                            <td>
                                                <asp:LinkButton ID="btndelete" runat="server" CssClass="btn btn-info btn-sm" CommandArgument='<%# Eval("pid") + "|" + Eval("pno") + "|" + Eval("Source") + "|" + Eval("ptype") %>' OnClick="btndelete_Click" OnClientClick="return confirm('Are you sure?');" ToolTip="View Details"> <i class="bi bi-eye-fill"></i></asp:LinkButton>
                                            </td>
                                        </tr>
                                    </ItemTemplate>

                                </asp:ListView>
                            </div>
                            <div class="text-center">
                                <asp:DataPager ID="DataPager1" runat="server"
                                    PagedControlID="listview2"
                                    PageSize="10">

                                    <Fields>
                                        <asp:NumericPagerField ButtonType="Button"
                                            NumericButtonCssClass="btn btn-sm btn-light"
                                            CurrentPageLabelCssClass="btn btn-sm btn-primary"
                                            ButtonCount="5" />
                                    </Fields>
                                </asp:DataPager>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

</asp:Content>

