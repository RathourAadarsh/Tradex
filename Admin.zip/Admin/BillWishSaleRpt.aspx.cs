﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class BillWishSaleRpt : System.Web.UI.Page
{
    Class1 cl = new Class1();
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    protected void Page_Load(object sender, EventArgs e)
    {
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        if (!IsPostBack)
        {
            txtfrom.Text = dateTime.ToString("yyyy-MM-dd");
            txtto.Text = dateTime.ToString("yyyy-MM-dd");
        }
    }
    protected void btnExportExcel_Click(object sender, EventArgs e)
    {
        DateTime fromDate = DateTime.Parse(txtfrom.Text);
        DateTime toDate = DateTime.Parse(txtto.Text);

        DataTable dt = new DataTable();

        string query = "SELECT bill_no,bill_date, BillTime,order_type,status,subtotal,discount,tax,roundoff,DeliveryCharge,grandtotal,Insuser FROM bill_master WHERE bill_date >= @fromdate AND bill_date < DATEADD(DAY,1,@todate) ORDER BY bill_date, bill_no";

        SqlCommand cmd = new SqlCommand(query, cl.con);
        cmd.Parameters.AddWithValue("@fromdate", fromDate);
        cmd.Parameters.AddWithValue("@todate", toDate);

        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);

        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition",
            "attachment;filename=BillWishReport_" + DateTime.Now.ToString("ddMMyyyy") + ".xls");
        Response.ContentType = "application/vnd.ms-excel";

        System.IO.StringWriter sw = new System.IO.StringWriter();

        sw.Write("<table border='1' style='font-family:Calibri;font-size:14px;width:100%'>");

        sw.Write("<tr><td colspan='7' style='font-size:18px;font-weight:bold;text-align:center'>Charans Club & Resort Pvt Ltd</td></tr>");
        sw.Write("<tr><td colspan='7' style='font-size:18px;font-weight:bold;text-align:center'>Bill Wise Report</td></tr>");
        sw.Write("<tr><td colspan='7'><b>Period :</b> " +
                 fromDate.ToString("dd-MM-yyyy") + " to " +
                 toDate.ToString("dd-MM-yyyy") + "</td></tr>");

        sw.Write("<tr style='font-weight:bold;background:#f2f2f2'>");
        sw.Write("<td>Bill No</td>");
        sw.Write("<td>Date</td>");
        sw.Write("<td>Taxable Amt</td>");
        sw.Write("<td>Discount</td>");
        sw.Write("<td>GSTIN</td>");
        sw.Write("<td>Round Off</td>");
        sw.Write("<td>Grand Total</td>");
        sw.Write("</tr>");

        decimal total = 0;
        decimal gsttotal = 0;
        decimal txttotal = 0;
        decimal roundtotal = 0;
        decimal discountt = 0;

        foreach (DataRow row in dt.Rows)
        {
            DateTime billDate = Convert.ToDateTime(row["bill_date"]);
            string billTime = row["BillTime"] == DBNull.Value ? "" : row["BillTime"].ToString();
            sw.Write("<tr>");
            sw.Write("<td>" + row["bill_no"] + "</td>");                   
            sw.Write("<td>" + billDate.ToString("dd-MM-yyyy") + " " + billTime + "</td>");
            sw.Write("<td>" + row["subtotal"] + "</td>");
            sw.Write("<td>" + row["discount"] + "</td>");
            sw.Write("<td>" + row["tax"] + "</td>");
            sw.Write("<td>" + row["roundoff"] + "</td>");
            sw.Write("<td>" + row["grandtotal"] + "</td>");
            sw.Write("</tr>");

            total += Convert.ToDecimal(row["grandtotal"]);
            gsttotal += Convert.ToDecimal(row["tax"]);
            roundtotal += Convert.ToDecimal(row["roundoff"]);
            discountt += Convert.ToDecimal(row["discount"]);
            txttotal += Convert.ToDecimal(row["subtotal"]);
        }

        sw.Write("<tr style='font-weight:bold'>");
        sw.Write("<td colspan='2'>TOTAL</td>");
        sw.Write("<td>" + txttotal + "</td>");
        sw.Write("<td>" + discountt + "</td>");
        sw.Write("<td>" + gsttotal + "</td>");
        sw.Write("<td>" + roundtotal + "</td>");
        sw.Write("<td>" + total + "</td>");
        sw.Write("</tr>");

        sw.Write("</table>");

        Response.Write(sw.ToString());
        Response.End();

    }

    public override void VerifyRenderingInServerForm(Control control)
    {

    }
    protected void btnback_Click(object sender, EventArgs e)
    {
        Response.Redirect("BillWishSaleRpt.aspx");
    }
    protected void btnpreview_Click(object sender, EventArgs e)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(txtfrom.Text) || string.IsNullOrWhiteSpace(txtto.Text))
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Script",
                    "savealert('Please select both From and To date.!!','warning');", true);
                return;
            }

            DateTime fromDate = DateTime.Parse(txtfrom.Text);
            DateTime toDate = DateTime.Parse(txtto.Text);
            from.Text = fromDate.ToString("dd-MM-yyyy");
            lbto.Text = toDate.ToString("dd-MM-yyyy");
            string baseQuery = "SELECT bill_no,format(bill_date,'dd/MM/yyyy') as bill_date,BillTime,order_type,status,subtotal,discount,tax,roundoff,DeliveryCharge,grandtotal,Insuser FROM bill_master WHERE bill_date >= @fromdate AND bill_date < DATEADD(DAY,1,@todate) ORDER BY bill_date, bill_no";

            SqlCommand cmd = new SqlCommand(baseQuery, cl.con);
            cmd.Parameters.AddWithValue("@fromdate", Convert.ToDateTime(fromDate));
            cmd.Parameters.AddWithValue("@todate", Convert.ToDateTime(toDate));
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                rptStock.DataSource = dt;
                rptStock.DataBind();
                decimal subtotal = dt.AsEnumerable().Sum(row => row.Field<decimal?>("subtotal") ?? 0);
                decimal discount = dt.AsEnumerable().Sum(row => row.Field<decimal?>("discount") ?? 0);
                decimal tax = dt.AsEnumerable().Sum(row => row.Field<decimal?>("tax") ?? 0);
                decimal roundoff = dt.AsEnumerable().Sum(row => row.Field<decimal?>("roundoff") ?? 0);
                decimal grandtotal = dt.AsEnumerable().Sum(row => row.Field<decimal?>("grandtotal") ?? 0);

                Label lblSubtotalTotal = (Label)rptStock.Controls[rptStock.Controls.Count - 1].FindControl("lblSubtotalTotal");
                Label lblTaxTotal = (Label)rptStock.Controls[rptStock.Controls.Count - 1].FindControl("lblTaxTotal");
                Label lblDiscountTotal = (Label)rptStock.Controls[rptStock.Controls.Count - 1].FindControl("lblDiscountTotal");
                Label lblRoundOffTotal = (Label)rptStock.Controls[rptStock.Controls.Count - 1].FindControl("lblRoundOffTotal");
                Label lblGrandTotal = (Label)rptStock.Controls[rptStock.Controls.Count - 1].FindControl("lblGrandTotal");

                if (lblSubtotalTotal != null) lblSubtotalTotal.Text = subtotal.ToString("0.00");
                if (lblTaxTotal != null) lblTaxTotal.Text = tax.ToString("0.00");
                if (lblDiscountTotal != null) lblDiscountTotal.Text = discount.ToString("0.00");
                if (lblRoundOffTotal != null) lblRoundOffTotal.Text = roundoff.ToString("0.00");
                if (lblGrandTotal != null) lblGrandTotal.Text = grandtotal.ToString("0.00");

            }
            else
            {
                rptStock.DataSource = null;
                rptStock.DataBind();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "savealert('No data found !!','warning');", true);
            }
        }
        catch (Exception ex)
        {
            Response.Write("Error: " + ex.Message);
        }
    }
}