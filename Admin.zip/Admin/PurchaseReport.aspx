﻿<%@ Page Title="" Language="C#" MasterPageFile="../Admin/AdminMaster.master" AutoEventWireup="true" CodeFile="PurchaseReport.aspx.cs" Inherits="PurchaseReport" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
    <style>
        .rbl-gap input {
            margin-right: 5px;
        }

        .rbl-gap label {
            margin-right: 25px; 
            font-weight: 500;
        }
    </style>

</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="Server">
    <div class="container">
        <div class="form-group">
            <div class="row">
                <div class="col-md-12">
                    <div class="row" style="margin-top: 30px;">
                        <div class="col-md-3"></div>
                        <div class="col-md-7" style="border: 1px solid #ca9142; box-shadow: 0px 0px 8px -3px #ec9190;">
                            <div class="col-md-12" style="border-bottom: 1px solid #ccc; margin-bottom: 15px;">
                                <div class="form-group" style="margin-bottom: 0px;">
                                    <h3 style="text-align: center; color: #339eae; font-size: 20px; font-weight: 500; margin: 20px;">Purchase Report</h3>
                                </div>
                            </div>
                            <div class="form-group mt-3 mb-3">
                                <div class="row">
                                    <div class="col-md-1"></div>
                                    <div class="col-md-2">
                                        <asp:Label ID="lb" Text="From Date" runat="server" ForeColor="Black"></asp:Label>
                                    </div>
                                    <div class="col-md-3">
                                        <asp:TextBox runat="server" ID="txtfrom" class="form-control" TextMode="Date" ForeColor="Black"></asp:TextBox>
                                    </div>
                                    <div class="col-md-2">
                                        <asp:Label ID="vd" Text="To Date" runat="server" ForeColor="Black"></asp:Label>
                                    </div>
                                    <div class="col-md-3">
                                        <asp:TextBox runat="server" ID="txtto" class="form-control" TextMode="Date" ForeColor="Black"></asp:TextBox>
                                    </div>
                                    <div class="col-md-1"></div>
                                </div>
                            </div>
                            <div class="form-group mt-3 mb-3">
                                <div class="row">
                                    <div class="col-md-1"></div>
                                    <div class="col-md-2">
                                        <asp:Label Text="Type" runat="server" ForeColor="Black"></asp:Label>
                                    </div>
                                    <div class="col-md-5">
                                        <asp:RadioButtonList
                                            ID="rblType"
                                            runat="server"
                                            RepeatDirection="Horizontal" CssClass="rbl-gap">
                                            <asp:ListItem Text="Store" Value="Store"></asp:ListItem>
                                            <asp:ListItem Text="Kitchen" Value="Kitchen"></asp:ListItem>
                                            <asp:ListItem Text="Both" Value="Both" Selected="True"></asp:ListItem>
                                        </asp:RadioButtonList>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12" style="margin-bottom: 10px; border-top: 1px solid #ccc">
                                <div class="row">
                                    <div class="col-md-2"></div>
                                    <div class="col-md-8" style="margin-top: 15px; text-align: center">
                                        <asp:Button runat="server" ID="btnview" Text="View" OnClick="btnview_Click" CssClass="btn btn-primary" />
                                        <asp:Button ID="btnExportExcel"
                                            runat="server"
                                            Text="Export to Excel"
                                            CssClass="btn btn-success"
                                            OnClick="btnExportExcel_Click" Style="display: none;" />
                                        <asp:Button ID="btnExportPDF"
                                            runat="server"
                                            Text="Export to PDF"
                                            CssClass="btn btn-primary"
                                            OnClick="btnExportPDF_Click" />

                                        <asp:Button ID="btnback" runat="server" Text="Back" class="btn btn-danger" Font-Bold="true" OnClick="btnback_Click" />
                                    </div>
                                    <div class="col-md-2"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2"></div>
                    </div>
                </div>
            </div>
            <asp:Literal ID="ltTable" runat="server"></asp:Literal>
        </div>
    </div>
</asp:Content>

