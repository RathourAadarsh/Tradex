﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using iTextSharp.text;
using iTextSharp.text.pdf;

public partial class StockReport : System.Web.UI.Page
{
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    Class1 cl = new Class1();
    HttpCookie lgdcookie;
    protected void Page_Load(object sender, EventArgs e)
    {
        lgdcookie = Request.Cookies["loggeduser"];
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        if (!IsPostBack)
        {
            txtfdt.Text = dateTime.ToString("yyyy-MM-dd");
            txttodate.Text = dateTime.ToString("yyyy-MM-dd");
        }
    }
    protected void btnview_Click(object sender, EventArgs e)
    {
        try
        {
            DateTime fromDate = DateTime.Parse(txtfdt.Text);
            DateTime toDate = DateTime.Parse(txttodate.Text);

            DataTable dt = GetItemWiseSaleReport(fromDate, toDate);

            if (dt.Rows.Count == 0)
            {              
            }
            lvReport.DataSource = dt;
            lvReport.DataBind();
        }
        catch (Exception ex)
        {

        }
    }
    protected void btnexcel_Click(object sender, EventArgs e)
    {
    }

    protected void btnexporttopdf_Click(object sender, EventArgs e)
    {
        try
        {
            DateTime fromDate = DateTime.Parse(txtfdt.Text);
            DateTime toDate = DateTime.Parse(txttodate.Text);

            DataTable dt = GetItemWiseSaleReport(fromDate, toDate);

            if (dt.Rows.Count == 0)
                return;

            Document doc = new Document(PageSize.A4.Rotate());
            MemoryStream ms = new MemoryStream();
            PdfWriter.GetInstance(doc, ms);
            doc.Open();

            Font companyFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 16);
            Paragraph company = new Paragraph("Charans Club & Resort Pvt Ltd", companyFont);
            company.Alignment = Element.ALIGN_CENTER;
            doc.Add(company);
            Font titleFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 14);
            Paragraph title = new Paragraph("Stock Report", titleFont);
            title.Alignment = Element.ALIGN_CENTER;
            doc.Add(title);
            Font infoFont = FontFactory.GetFont(FontFactory.HELVETICA, 11);
            Paragraph info = new Paragraph(
                "Date : " + fromDate.ToString("dd-MM-yyyy") +
                " To " + toDate.ToString("dd-MM-yyyy"),
                infoFont);
            info.Alignment = Element.ALIGN_CENTER;
            info.SpacingAfter = 15;
            doc.Add(info);

            PdfPTable table = new PdfPTable(8);
            table.WidthPercentage = 100;

            float[] widths = { 18f, 22f, 10f, 10f, 10f, 10f, 10f, 10f };
            table.SetWidths(widths);

            string[] headers = {
            "Item Category",
            "Item Name",
            "Opening Qty",
            "Purchase Qty",
            "Issue Qty",
            "Closing Qty",
            "Rate",
            "Closing Amount"
        };

            Font headerFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 11);

            foreach (string header in headers)
            {
                PdfPCell cell = new PdfPCell(new Phrase(header, headerFont));
                cell.BackgroundColor = BaseColor.LIGHT_GRAY;
                cell.Padding = 5;

                if (header.Contains("Qty"))
                    cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                else
                    cell.HorizontalAlignment = Element.ALIGN_LEFT;

                table.AddCell(cell);
            }

            Font normalFont = FontFactory.GetFont(FontFactory.HELVETICA, 10);

            foreach (DataRow row in dt.Rows)
            {
                table.AddCell(new PdfPCell(new Phrase(row["itemcategory"].ToString(), normalFont)));
                table.AddCell(new PdfPCell(new Phrase(row["Item_name"].ToString(), normalFont)));

                table.AddCell(new PdfPCell(new Phrase(
                    Convert.ToDecimal(row["openingQty"]).ToString("N2"), normalFont))
                { HorizontalAlignment = Element.ALIGN_RIGHT });

                table.AddCell(new PdfPCell(new Phrase(
                    Convert.ToDecimal(row["PurchaseQty"]).ToString("N2"), normalFont))
                { HorizontalAlignment = Element.ALIGN_RIGHT });

                table.AddCell(new PdfPCell(new Phrase(
                    Convert.ToDecimal(row["IssueQty"]).ToString("N2"), normalFont))
                { HorizontalAlignment = Element.ALIGN_RIGHT });

                table.AddCell(new PdfPCell(new Phrase(
                    Convert.ToDecimal(row["ClosingQty"]).ToString("N2"), normalFont))
                { HorizontalAlignment = Element.ALIGN_RIGHT });

                table.AddCell(new PdfPCell(new Phrase(
                    Convert.ToDecimal(row["Rate"]).ToString("N2"), normalFont))
                { HorizontalAlignment = Element.ALIGN_RIGHT });

                table.AddCell(new PdfPCell(new Phrase(
                    Convert.ToDecimal(row["ClosingAmount"]).ToString("N2"), normalFont))
                { HorizontalAlignment = Element.ALIGN_RIGHT });
            }

            doc.Add(table);
            doc.Close();

            Response.ContentType = "application/pdf";
            Response.AddHeader("content-disposition", "attachment;filename=StockReport.pdf");
            Response.BinaryWrite(ms.ToArray());
            Response.End();
        }
        catch (Exception ex)
        {

        }
    }
    public DataTable GetItemWiseSaleReport(DateTime fromDate, DateTime toDate)
    {
        StringBuilder query = new StringBuilder(@";WITH PurchaseAgg AS
(
    SELECT 
        pe.itemname,
        pe.itemcate,

        SUM(CASE 
                WHEN pe.pdate < @fromdate 
                THEN TRY_CAST(pe.qty AS DECIMAL(18,2)) 
                ELSE 0 
            END) AS OpeningPurchase,

        SUM(CASE 
                WHEN pe.pdate BETWEEN @fromdate AND @todate 
                THEN TRY_CAST(pe.qty AS DECIMAL(18,2)) 
                ELSE 0 
            END) AS PurchaseQty

    FROM PurchaseEntry pe
    GROUP BY pe.itemname, pe.itemcate
),

IssueAgg AS
(
    SELECT 
        ik.itemname,

        SUM(CASE 
                WHEN ik.idate < @fromdate 
                THEN TRY_CAST(ik.qty AS DECIMAL(18,2)) 
                ELSE 0 
            END) AS OpeningIssue,

        SUM(CASE 
                WHEN ik.idate BETWEEN @fromdate AND @todate 
                THEN TRY_CAST(ik.qty AS DECIMAL(18,2)) 
                ELSE 0 
            END) AS IssueQty

    FROM IssuetoKitchen ik 
    WHERE isdeleted = 0
    GROUP BY ik.itemname
)

SELECT 
    sgm.Item_G_Name AS itemcategory,
    sd.Item_name,

    ISNULL(p.OpeningPurchase,0) 
        - ISNULL(i.OpeningIssue,0) AS OpeningQty,

    ISNULL(p.PurchaseQty,0) AS PurchaseQty,

    ISNULL(i.IssueQty,0) AS IssueQty,

    (
        ISNULL(p.OpeningPurchase,0) 
        - ISNULL(i.OpeningIssue,0)
        + ISNULL(p.PurchaseQty,0)
        - ISNULL(i.IssueQty,0)
    ) AS ClosingQty,

    ISNULL(sd.Item_sale_rate,0) AS Rate,
   CAST(
    (
        (
            ISNULL(p.OpeningPurchase,0) 
            - ISNULL(i.OpeningIssue,0)
            + ISNULL(p.PurchaseQty,0)
            - ISNULL(i.IssueQty,0)
        ) * ISNULL(sd.Item_sale_rate,0)
    ) AS DECIMAL(18,2)
) AS ClosingAmount
FROM StoreItem_detail sd
LEFT JOIN PurchaseAgg p 
    ON sd.SKU = p.itemname

LEFT JOIN IssueAgg i 
    ON sd.SKU = i.itemname

LEFT JOIN StoreItem_group_Master sgm 
    ON sd.Item_group_name = sgm.Item_G_Id

WHERE 
    (
        ISNULL(p.OpeningPurchase,0) 
        - ISNULL(i.OpeningIssue,0)
        + ISNULL(p.PurchaseQty,0)
        - ISNULL(i.IssueQty,0)
    ) <> 0
ORDER BY sgm.Item_G_Name, sd.Item_name");

        SqlCommand cmd = new SqlCommand(query.ToString(), cl.con);
        cmd.Parameters.AddWithValue("@FromDate", fromDate);
        cmd.Parameters.AddWithValue("@ToDate", toDate);

        SqlDataAdapter adp = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        adp.Fill(dt);
        return dt;

    }
    protected void btnback_Click(object sender, EventArgs e)
    {
        Response.Redirect("StoreDashboard.aspx");
    }
}