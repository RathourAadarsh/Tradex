﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Itemwisesale : System.Web.UI.Page
{

    Class1 cl = new Class1();
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    protected void Page_Load(object sender, EventArgs e)
    {
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        if (!IsPostBack)
        {
            txtfrom.Text = dateTime.ToString("yyyy-MM-dd");
            txtto.Text = dateTime.ToString("yyyy-MM-dd");
        }
    }
    protected void btnExportExcel_Click(object sender, EventArgs e)
    {
        DateTime fromDate = DateTime.Parse(txtfrom.Text);
        DateTime toDate = DateTime.Parse(txtto.Text);

        DataTable dt = new DataTable();

        string query = "SELECT bd.itemname, ig.pgroupname,SUM(bd.Qty) AS TotalQty,SUM(bd.Amount) AS BasicAmount,SUM(bd.Amount * ISNULL(id.gst_per,0) / 100.0) AS GSTAmount, SUM(bd.Amount + (bd.Amount * ISNULL(id.gst_per,0) / 100.0)) AS TotalAmount FROM Bill_Detail bd JOIN Bill_Master bm ON bd.Bill_ID = bm.Bill_ID JOIN item_detail id ON bd.sku = id.SKU JOIN item_group_master ig ON id.item_group_name = ig.item_g_id WHERE bm.ispaid = 1 AND bm.bill_date >= @fromdate AND bm.bill_date < DATEADD(DAY,1,@todate) GROUP BY bd.itemname, ig.pgroupname ORDER BY ig.pgroupname, bd.itemname";

        SqlCommand cmd = new SqlCommand(query, cl.con);
        cmd.Parameters.AddWithValue("@fromdate", fromDate);
        cmd.Parameters.AddWithValue("@todate", toDate);

        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);

        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition",
            "attachment;filename=ItemWiseSale_" + DateTime.Now.ToString("ddMMyyyy") + ".xls");
        Response.ContentType = "application/vnd.ms-excel";

        System.IO.StringWriter sw = new System.IO.StringWriter();

        sw.Write("<table border='1' style='font-family:Calibri;font-size:14px;width:100%'>");

        sw.Write("<tr><td colspan='5' style='font-size:18px;font-weight:bold;text-align:center'>Charans Club & Resort Pvt Ltd</td></tr>");
        sw.Write("<tr><td colspan='5' style='font-size:18px;font-weight:bold;text-align:center'>Item Wise Sale Report</td></tr>");
        sw.Write("<tr><td colspan='5'><b>Period :</b> " +
                 fromDate.ToString("dd-MM-yyyy") + " to " +
                 toDate.ToString("dd-MM-yyyy") + "</td></tr>");

        sw.Write("<tr style='font-weight:bold;background:#f2f2f2'>");
        sw.Write("<td>Item Name</td>");
        sw.Write("<td>Quantity</td>");
        sw.Write("<td>Taxable Amt</td>");
        sw.Write("<td>GST</td>");
        sw.Write("<td>Total Amount</td>");
        sw.Write("</tr>");

        decimal grandTotal = 0;
        decimal QtyTotal = 0;
        decimal gstTotal = 0;
        decimal textTotal = 0;

        string currentGroup = "";
        decimal groupQty = 0;
        decimal groupBasic = 0;
        decimal groupGST = 0;
        decimal groupTotal = 0;

        foreach (DataRow row in dt.Rows)
        {
            string groupName = row["pgroupname"].ToString();

            if (currentGroup != "" && currentGroup != groupName)
            {
                sw.Write("<tr style='font-weight:bold;background:#e6e6e6'>");
                sw.Write("<td colspan='1'>" + currentGroup + " TOTAL</td>");
                sw.Write("<td>" + groupQty + "</td>");
                sw.Write("<td>" + groupBasic.ToString("0.00") + "</td>");
                sw.Write("<td>" + groupGST.ToString("0.00") + "</td>");
                sw.Write("<td>" + groupTotal.ToString("0.00") + "</td>");
                sw.Write("</tr>");

                groupQty = groupBasic = groupGST = groupTotal = 0;
            }

            if (currentGroup != groupName)
            {
                sw.Write("<tr style='font-weight:bold;background:#d9edf7'>");
                sw.Write("<td colspan='5'>" + groupName + "</td>");
                sw.Write("</tr>");
                currentGroup = groupName;
            }

            sw.Write("<tr>");
            sw.Write("<td>" + row["itemname"] + "</td>");
            sw.Write("<td>" + row["TotalQty"] + "</td>");
            sw.Write("<td>" + Convert.ToDecimal(row["BasicAmount"]).ToString("0.00") + "</td>");
            sw.Write("<td>" + Convert.ToDecimal(row["GSTAmount"]).ToString("0.00") + "</td>");
            sw.Write("<td>" + Convert.ToDecimal(row["TotalAmount"]).ToString("0.00") + "</td>");
            sw.Write("</tr>");

            groupQty += Convert.ToDecimal(row["TotalQty"]);
            groupBasic += Convert.ToDecimal(row["BasicAmount"]);
            groupGST += Convert.ToDecimal(row["GSTAmount"]);
            groupTotal += Convert.ToDecimal(row["TotalAmount"]);

            QtyTotal += Convert.ToDecimal(row["TotalQty"]);
            textTotal += Convert.ToDecimal(row["BasicAmount"]);
            gstTotal += Convert.ToDecimal(row["GSTAmount"]);
            grandTotal += Convert.ToDecimal(row["TotalAmount"]);
        }
        if (currentGroup != "")
        {
            sw.Write("<tr style='font-weight:bold;background:#e6e6e6'>");
            sw.Write("<td colspan='1'>" + currentGroup + " TOTAL</td>");
            sw.Write("<td>" + groupQty + "</td>");
            sw.Write("<td>" + groupBasic.ToString("0.00") + "</td>");
            sw.Write("<td>" + groupGST.ToString("0.00") + "</td>");
            sw.Write("<td>" + groupTotal.ToString("0.00") + "</td>");
            sw.Write("</tr>");
        }

        sw.Write("</table>");

        Response.Write(sw.ToString());
        Response.End();
    }
    string previousGroup = "";

    decimal groupQty = 0;
    decimal groupBasic = 0;
    decimal groupGST = 0;
    decimal groupTotal = 0;

    decimal grandQty = 0;
    decimal grandBasic = 0;
    decimal grandGST = 0;
    decimal grandTotal = 0;

    protected void btnpreview_Click(object sender, EventArgs e)
    {
        previousGroup = "";
        groupQty = groupBasic = groupGST = groupTotal = 0;
        grandQty = grandBasic = grandGST = grandTotal = 0;

        DateTime fromDate = DateTime.Parse(txtfrom.Text);
        DateTime toDate = DateTime.Parse(txtto.Text);

        DataTable dt = GetItemWiseSale(fromDate, toDate);

        rptStock.DataSource = dt;
        rptStock.DataBind();
    }

   

    private DataTable GetItemWiseSale(DateTime fromDate, DateTime toDate)
    {
        DataTable dt = new DataTable();

        string query = "SELECT bd.itemname, ig.pgroupname, SUM(bd.Qty) AS TotalQty,SUM(bd.Amount) AS BasicAmount,SUM(bd.Amount * ISNULL(id.gst_per,0) / 100.0) AS GSTAmount, SUM(bd.Amount + (bd.Amount * ISNULL(id.gst_per,0) / 100.0)) AS TotalAmount FROM Bill_Detail bd  JOIN Bill_Master bm ON bd.Bill_ID = bm.Bill_ID JOIN item_detail id ON bd.sku = id.SKU  JOIN item_group_master ig ON id.item_group_name = ig.item_g_id WHERE bm.ispaid = 1 AND bm.bill_date >= @fromdate AND bm.bill_date < DATEADD(DAY,1,@todate) GROUP BY bd.itemname, ig.pgroupname ORDER BY ig.pgroupname, bd.itemname";

        SqlCommand cmd = new SqlCommand(query, cl.con);
        cmd.Parameters.AddWithValue("@fromdate", fromDate);
        cmd.Parameters.AddWithValue("@todate", toDate);

        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);

        return dt;
    }

    protected void btnback_Click(object sender, EventArgs e)
    {
        Response.Redirect("Itemwwisesale.aspx");
    }
    protected void rptStock_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item ||
            e.Item.ItemType == ListItemType.AlternatingItem)
        {
            DataRowView drv = (DataRowView)e.Item.DataItem;
            string currentGroup = drv["pgroupname"].ToString();

            Literal litGroupHeader = (Literal)e.Item.FindControl("litGroupHeader");
            Literal litGroupFooter = (Literal)e.Item.FindControl("litGroupFooter");

            decimal qty = Convert.ToDecimal(drv["TotalQty"]);
            decimal basic = Convert.ToDecimal(drv["BasicAmount"]);
            decimal gst = Convert.ToDecimal(drv["GSTAmount"]);
            decimal total = Convert.ToDecimal(drv["TotalAmount"]);

            // 🔹 New Group
            if (currentGroup != previousGroup)
            {
                // Previous Group Footer Print
                if (previousGroup != "")
                {
                    litGroupHeader.Text += "<tr style='font-weight:bold;background:#e6e6e6'>" +
                        "<td>" + previousGroup + " TOTAL</td>" +
                        "<td>" + groupQty + "</td>" +
                        "<td style='text-align:right'>" + groupBasic.ToString("0.00") + "</td>" +
                        "<td style='text-align:right'>" + groupGST.ToString("0.00") + "</td>" +
                        "<td style='text-align:right'>" + groupTotal.ToString("0.00") + "</td>" +
                        "</tr>";

                    groupQty = groupBasic = groupGST = groupTotal = 0;
                }

                litGroupHeader.Text += "<tr style='font-weight:bold;background:#d9edf7'>" +
                                       "<td colspan='5'>" + currentGroup + "</td></tr>";

                previousGroup = currentGroup;
            }

            // Add to Group
            groupQty += qty;
            groupBasic += basic;
            groupGST += gst;
            groupTotal += total;

            // Add to Grand
            grandQty += qty;
            grandBasic += basic;
            grandGST += gst;
            grandTotal += total;
        }

        // 🔹 Final Grand Total Binding
        if (e.Item.ItemType == ListItemType.Footer)
        {
            Label lblQty = (Label)e.Item.FindControl("lblGrandQty");
            Label lblBasic = (Label)e.Item.FindControl("lblSubtotalTotal");
            Label lblGST = (Label)e.Item.FindControl("lblTaxTotal");
            Label lblTotal = (Label)e.Item.FindControl("lblGrandTotal");

            lblQty.Text = grandQty.ToString();
            lblBasic.Text = grandBasic.ToString("0.00");
            lblGST.Text = grandGST.ToString("0.00");
            lblTotal.Text = grandTotal.ToString("0.00");
        }
    }


}