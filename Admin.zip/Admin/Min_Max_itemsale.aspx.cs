﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Min_Max_itemsale : System.Web.UI.Page
{
    Class1 cl = new Class1();
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    protected void Page_Load(object sender, EventArgs e)
    {
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        if (!IsPostBack)
        {
            txtfrom.Text = dateTime.ToString("yyyy-MM-dd");
            txtto.Text = dateTime.ToString("yyyy-MM-dd");
        }
    }
    protected void btnExportExcel_Click(object sender, EventArgs e)
    {
        DateTime fromDate = DateTime.Parse(txtfrom.Text);
        DateTime toDate = DateTime.Parse(txtto.Text);

        DataTable dt = new DataTable();

        string query = @"WITH ItemSale AS (
    SELECT 
        bd.itemname,
        ig.pgroupname,
        SUM(bd.Qty) AS TotalQty,
        SUM(bd.Amount) AS BasicAmount,
        SUM(bd.Amount * ISNULL(id.gst_per,0) / 100.0) AS GSTAmount,
        SUM(bd.Amount + (bd.Amount * ISNULL(id.gst_per,0) / 100.0)) AS TotalAmount
    FROM Bill_Detail bd
    JOIN Bill_Master bm ON bd.Bill_ID = bm.Bill_ID
    LEFT JOIN item_detail id ON bd.sku = id.SKU
    LEFT JOIN item_group_master ig ON id.item_group_name = ig.item_g_id
    WHERE bm.ispaid = 1
    AND bm.bill_date >= @fromdate
    AND bm.bill_date < DATEADD(DAY,1,@todate)
    GROUP BY bd.itemname, ig.pgroupname
),
Ranked AS
(
    SELECT *,
        ROW_NUMBER() OVER (ORDER BY TotalAmount DESC) AS RankDesc,
        ROW_NUMBER() OVER (ORDER BY TotalAmount ASC) AS RankAsc
    FROM ItemSale
)

SELECT 'MAX' AS SaleType, *
FROM Ranked
WHERE RankDesc <= 10
UNION ALL
SELECT 'MIN' AS SaleType, *
FROM Ranked
WHERE RankAsc <= 10";

        SqlCommand cmd = new SqlCommand(query, cl.con);
        cmd.Parameters.AddWithValue("@fromdate", fromDate);
        cmd.Parameters.AddWithValue("@todate", toDate);

        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);

        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition",
            "attachment;filename=ItemWiseSale_" + DateTime.Now.ToString("ddMMyyyy") + ".xls");
        Response.ContentType = "application/vnd.ms-excel";

        System.IO.StringWriter sw = new System.IO.StringWriter();

        sw.Write("<table border='1' style='font-family:Calibri;font-size:14px;width:100%'>");

        sw.Write("<tr><td colspan='5' style='font-size:18px;font-weight:bold;text-align:center'>Charans Club & Resort Pvt Ltd</td></tr>");
        sw.Write("<tr><td colspan='5' style='font-size:18px;font-weight:bold;text-align:center'>Max/Min Itemwise Report</td></tr>");
        sw.Write("<tr><td colspan='5'><b>Period :</b> " +
                 fromDate.ToString("dd-MM-yyyy") + " to " +
                 toDate.ToString("dd-MM-yyyy") + "</td></tr>");

        sw.Write("<tr style='font-weight:bold;background:#f2f2f2'>");
        sw.Write("<td>Type</td>");
        sw.Write("<td>Item Name</td>");
        sw.Write("<td>Group</td>");
        sw.Write("<td>Total Qty</td>");
        sw.Write("<td>Total Amount</td>");
        sw.Write("</tr>");

        decimal grandTotal = 0;
        foreach (DataRow row in dt.Rows)
        {
            sw.Write("<tr>");

            if (row["SaleType"].ToString() == "MAX")
                sw.Write("<td style='color:green;font-weight:bold'>MAX</td>");
            else
                sw.Write("<td style='color:red;font-weight:bold'>MIN</td>");

            sw.Write("<td>" + row["itemname"] + "</td>");
            sw.Write("<td>" + row["pgroupname"] + "</td>");
            sw.Write("<td>" + row["TotalQty"] + "</td>");
            sw.Write("<td>" + row["TotalAmount"] + "</td>");

            sw.Write("</tr>");

            grandTotal += Convert.ToDecimal(row["TotalAmount"]);
        }
        sw.Write("<tr style='font-weight:bold'>");
        sw.Write("<td colspan='4'>GRAND TOTAL</td>");
        sw.Write("<td>" + grandTotal + "</td>");
        sw.Write("</tr>");

        sw.Write("</table>");

        Response.Write(sw.ToString());
        Response.End();
    }

    protected void btnback_Click(object sender, EventArgs e)
    {

    }
    private DataTable GetMinMaxItemSale(DateTime fromDate, DateTime toDate)
    {
        DataTable dt = new DataTable();

        string query = @"WITH ItemSale AS (
    SELECT 
        bd.itemname,
        ig.pgroupname,
        SUM(bd.Qty) AS TotalQty,
        SUM(bd.Amount) AS BasicAmount,
        SUM(bd.Amount * ISNULL(id.gst_per,0) / 100.0) AS GSTAmount,
        SUM(bd.Amount + (bd.Amount * ISNULL(id.gst_per,0) / 100.0)) AS TotalAmount
    FROM Bill_Detail bd
    JOIN Bill_Master bm ON bd.Bill_ID = bm.Bill_ID
    LEFT JOIN item_detail id ON bd.sku = id.SKU
    LEFT JOIN item_group_master ig ON id.item_group_name = ig.item_g_id
    WHERE bm.ispaid = 1
    AND bm.bill_date >= @fromdate
    AND bm.bill_date < DATEADD(DAY,1,@todate)
    GROUP BY bd.itemname, ig.pgroupname
),
Ranked AS
(
    SELECT *,
        ROW_NUMBER() OVER (ORDER BY TotalAmount DESC) AS RankDesc,
        ROW_NUMBER() OVER (ORDER BY TotalAmount ASC) AS RankAsc
    FROM ItemSale
)

SELECT 'MAX' AS SaleType, *
FROM Ranked
WHERE RankDesc <= 10
UNION ALL
SELECT 'MIN' AS SaleType, *
FROM Ranked
WHERE RankAsc <= 10";

        SqlCommand cmd = new SqlCommand(query, cl.con);
        cmd.Parameters.AddWithValue("@fromdate", fromDate);
        cmd.Parameters.AddWithValue("@todate", toDate);

        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);

        return dt;
    }

    protected void btnpreview_Click(object sender, EventArgs e)
    {
        DateTime fromDate = DateTime.Parse(txtfrom.Text);
        DateTime toDate = DateTime.Parse(txtto.Text);

        DataTable dt = GetMinMaxItemSale(fromDate, toDate);

        rptMinMax.DataSource = dt;
        rptMinMax.DataBind();

        decimal grandTotal = 0;

        foreach (DataRow row in dt.Rows)
        {
            grandTotal += Convert.ToDecimal(row["TotalAmount"]);
        }

        Label lblGrand = (Label)rptMinMax.Controls[rptMinMax.Controls.Count - 1]
                            .FindControl("lblGrandTotal");

        if (lblGrand != null)
            lblGrand.Text = grandTotal.ToString("0.00");
    }
    protected void rptMinMax_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item ||
            e.Item.ItemType == ListItemType.AlternatingItem)
        {
            Label lblType = (Label)e.Item.FindControl("lblType");

            if (lblType.Text == "MAX")
            {
                lblType.ForeColor = System.Drawing.Color.Green;
                lblType.Font.Bold = true;
            }
            else
            {
                lblType.ForeColor = System.Drawing.Color.Red;
                lblType.Font.Bold = true;
            }
        }
    }

}