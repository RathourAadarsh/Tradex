﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Web.UI.WebControls;

public partial class PurchaseReport : System.Web.UI.Page
{
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    Class1 cl = new Class1();
    HttpCookie lgdcookie;

    protected void Page_Load(object sender, EventArgs e)
    {
        lgdcookie = Request.Cookies["loggeduser"];
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        if (lgdcookie != null && !string.IsNullOrEmpty(lgdcookie["UserName"]))
        {
            if (!IsPostBack)
            {
                txtfrom.Text = dateTime.ToString("yyyy-MM-dd");
                txtto.Text = dateTime.ToString("yyyy-MM-dd");
            }
        }
        else
        {
            Response.Redirect("Login.aspx");
        }
    }

    protected void btnExportPDF_Click(object sender, EventArgs e)
    {
        DateTime fromDate = DateTime.Parse(txtfrom.Text);
        DateTime toDate = DateTime.Parse(txtto.Text);
        string type = rblType.SelectedValue;

        DataTable dt = GetPurchaseReport(fromDate, toDate, type);

        if (dt.Rows.Count == 0)
            return;

        Document doc = new Document(PageSize.A4.Rotate());
        MemoryStream ms = new MemoryStream();
        PdfWriter.GetInstance(doc, ms);
        doc.Open();

       // 🔥 Company Name
            Font companyFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 16);
        Paragraph company = new Paragraph("Charans Club & Resort Pvt Ltd", companyFont);
        company.Alignment = Element.ALIGN_CENTER; doc.Add(company);
        // 🔥 Report Title
        Font titleFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 14);
        Paragraph title = new Paragraph("Purchase Report", titleFont);
        title.Alignment = Element.ALIGN_CENTER;
        title.SpacingAfter = 5; doc.Add(title); 
        // 🔥 Date & Type Info
        Font infoFont = FontFactory.GetFont(FontFactory.HELVETICA, 11);
        Paragraph info = new Paragraph( "Date : " + fromDate.ToString("dd-MM-yyyy") + " To " + toDate.ToString("dd-MM-yyyy") + " | Type : " + type, infoFont); info.Alignment = Element.ALIGN_CENTER; info.SpacingAfter = 15; doc.Add(info);

        Font normalFont = FontFactory.GetFont(FontFactory.HELVETICA, 10);
        Font headerFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 11);
        Font totalFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 11);

        PdfPTable table = new PdfPTable(9);
        table.WidthPercentage = 100;
        float[] widths = { 5f, 10f, 12f, 10f, 15f, 15f, 8f, 10f, 12f };
        table.SetWidths(widths);

        string[] headers = {
        "Sr.No", "Date", "Purchase No", "Type",
        "Category", "Item", "Qty", "Rate", "Amount"
    };

        foreach (string header in headers)
        {
            PdfPCell cell = new PdfPCell(new Phrase(header, headerFont));
            cell.BackgroundColor = BaseColor.LIGHT_GRAY;
            cell.Padding = 5;
            cell.HorizontalAlignment =
                (header == "Qty" || header == "Rate" || header == "Amount")
                ? Element.ALIGN_RIGHT
                : Element.ALIGN_LEFT;

            table.AddCell(cell);
        }

        string currentType = "";
        decimal sectionQty = 0;
        decimal sectionAmt = 0;

        decimal grandQty = 0;
        decimal grandAmt = 0;

        int sr = 1;

        foreach (DataRow row in dt.Rows)
        {
            string ptype = row["ptype"].ToString();

            decimal qty = row["qty"] != DBNull.Value
               ? Convert.ToDecimal(row["qty"])
               : 0;
            decimal rate = row["rate"] != DBNull.Value ? Convert.ToDecimal(row["rate"]) : 0;
            decimal amt = row["amount"] != DBNull.Value ? Convert.ToDecimal(row["amount"]) : 0;

            if (currentType != "" && currentType != ptype)
            {
                // Section Total
                PdfPCell totalCell = new PdfPCell(new Phrase(currentType + " TOTAL", totalFont));
                totalCell.Colspan = 6;
                totalCell.HorizontalAlignment = Element.ALIGN_RIGHT;
                totalCell.BackgroundColor = BaseColor.LIGHT_GRAY;
                table.AddCell(totalCell);

                table.AddCell(new PdfPCell(new Phrase(sectionQty.ToString(), totalFont))
                { HorizontalAlignment = Element.ALIGN_RIGHT });

                table.AddCell(new PdfPCell(new Phrase("", totalFont)));

                table.AddCell(new PdfPCell(new Phrase(sectionAmt.ToString("N2"), totalFont))
                { HorizontalAlignment = Element.ALIGN_RIGHT });

                sectionQty = 0;
                sectionAmt = 0;
            }

            currentType = ptype;

            sectionQty += qty;
            sectionAmt += amt;

            grandQty += qty;
            grandAmt += amt;

            table.AddCell(new PdfPCell(new Phrase(sr++.ToString(), normalFont)));
            table.AddCell(new PdfPCell(new Phrase(row["pdate"].ToString(), normalFont)));
            table.AddCell(new PdfPCell(new Phrase(row["pno"].ToString(), normalFont)));
            table.AddCell(new PdfPCell(new Phrase(ptype, normalFont)));
            table.AddCell(new PdfPCell(new Phrase(row["Item_G_Name"].ToString(), normalFont)));
            table.AddCell(new PdfPCell(new Phrase(row["itemname"].ToString(), normalFont)));

            table.AddCell(new PdfPCell(new Phrase(qty.ToString("0.##"), normalFont))
            { HorizontalAlignment = Element.ALIGN_RIGHT });

            table.AddCell(new PdfPCell(new Phrase(rate.ToString("N2"), normalFont))
            { HorizontalAlignment = Element.ALIGN_RIGHT });

            table.AddCell(new PdfPCell(new Phrase(amt.ToString("N2"), normalFont))
            { HorizontalAlignment = Element.ALIGN_RIGHT });
        }
        if (currentType != "")
        {
            PdfPCell totalCell = new PdfPCell(new Phrase(currentType + " TOTAL", totalFont));
            totalCell.Colspan = 6;
            totalCell.HorizontalAlignment = Element.ALIGN_RIGHT;
            totalCell.BackgroundColor = BaseColor.LIGHT_GRAY;
            table.AddCell(totalCell);

            table.AddCell(new PdfPCell(new Phrase(sectionQty.ToString(), totalFont))
            { HorizontalAlignment = Element.ALIGN_RIGHT });

            table.AddCell(new PdfPCell(new Phrase("", totalFont)));

            table.AddCell(new PdfPCell(new Phrase(sectionAmt.ToString("N2"), totalFont))
            { HorizontalAlignment = Element.ALIGN_RIGHT });
        }

        PdfPCell grandCell = new PdfPCell(new Phrase("GRAND TOTAL", totalFont));
        grandCell.Colspan = 6;
        grandCell.HorizontalAlignment = Element.ALIGN_RIGHT;
        grandCell.BackgroundColor = BaseColor.GRAY;
        table.AddCell(grandCell);

        table.AddCell(new PdfPCell(new Phrase(grandQty.ToString(), totalFont))
        { HorizontalAlignment = Element.ALIGN_RIGHT });

        table.AddCell(new PdfPCell(new Phrase("", totalFont)));

        table.AddCell(new PdfPCell(new Phrase(grandAmt.ToString("N2"), totalFont))
        { HorizontalAlignment = Element.ALIGN_RIGHT });

        doc.Add(table);
        doc.Close();

        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "attachment;filename=PurchaseReport.pdf");
        Response.BinaryWrite(ms.ToArray());
        Response.End();
    }

    public DataTable GetPurchaseReport(DateTime fromDate, DateTime toDate, string type)
    {
        StringBuilder query = new StringBuilder(@"
        SELECT 
            pi.pid,
            CONVERT(NVARCHAR, pi.pdate, 103) AS pdate,
            pi.pno,
            pi.pinv,
            CONVERT(NVARCHAR, pi.pinvdt, 103) AS Billdate,
            sd.Item_name as itemname,
            pi.qty as qty,
            pi.rate,
            pi.amount,
            sm.Item_G_Name,
            pi.ptype
        FROM PurchaseEntry pi
        LEFT JOIN StoreItem_detail sd ON pi.itemname = sd.SKU
        INNER JOIN StoreItem_group_Master sm ON pi.itemcate = sm.Item_G_Id
        WHERE pi.pdate BETWEEN @FromDate AND @ToDate
    ");

        if (type != "Both")
        {
            query.Append(" AND pi.ptype = @ptype ");
        }

        query.Append(@"
        ORDER BY 
        CASE WHEN pi.ptype = 'Store' THEN 1 
             WHEN pi.ptype = 'Kitchen' THEN 2 
        END,
        pi.pdate,
        pi.pno
    ");

        SqlCommand cmd = new SqlCommand(query.ToString(), cl.con);
        cmd.Parameters.AddWithValue("@FromDate", fromDate);
        cmd.Parameters.AddWithValue("@ToDate", toDate);

        if (type != "Both")
            cmd.Parameters.AddWithValue("@ptype", type);

        SqlDataAdapter adp = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        adp.Fill(dt);

        return dt;
    }

    protected void btnback_Click(object sender, EventArgs e)
    {
        Response.Redirect("StoreDashboard.aspx");
    }

    protected void btnview_Click(object sender, EventArgs e)
    {
        DateTime fromDate = DateTime.Parse(txtfrom.Text);
        DateTime toDate = DateTime.Parse(txtto.Text);
        string type = rblType.SelectedValue;

        DataTable dt = GetPurchaseReport(fromDate, toDate, type);

        if (dt.Rows.Count == 0)
        {
            ltTable.Text = "<div class='alert alert-danger'>No Data Found</div>";
            return;
        }

        StringBuilder sb = new StringBuilder();
        sb.Append("<div class='container mt-4'>");
        sb.Append("<table class='table table-bordered'>");

        sb.Append("<tr style='background:#f2f2f2;font-weight:bold'>");
        sb.Append("<th>Sr.No</th>");
        sb.Append("<th>Date</th>");
        sb.Append("<th>Purchase No</th>");
        sb.Append("<th>Type</th>");
        sb.Append("<th>Category</th>");
        sb.Append("<th>Item</th>");
        sb.Append("<th style='text-align:right'>Qty</th>");
        sb.Append("<th style='text-align:right'>Rate</th>");
        sb.Append("<th style='text-align:right'>Amount</th>");
        sb.Append("</tr>");

        string currentType = "";
        decimal sectionQty = 0;
        decimal sectionAmt = 0;

        decimal grandQty = 0;
        decimal grandAmt = 0;

        int sr = 1;

        foreach (DataRow row in dt.Rows)
        {
            string ptype = row["ptype"].ToString();
            decimal qty = 0;

            if (row["qty"] != DBNull.Value)
            {
                decimal.TryParse(row["qty"].ToString().Trim(), out qty);
            }
            decimal rate = row["rate"] != DBNull.Value ? Convert.ToDecimal(row["rate"]) : 0;
            decimal amt = row["amount"] != DBNull.Value ? Convert.ToDecimal(row["amount"]) : 0;
            if (currentType != "" && currentType != ptype)
            {
                sb.Append("<tr style='font-weight:bold;background:#f5f5f5'>");
                sb.Append("<td colspan='6' style='text-align:right'>" + currentType + " TOTAL</td>");
                sb.Append("<td style='text-align:right'>" + sectionQty + "</td>");
                sb.Append("<td></td>");
                sb.Append("<td style='text-align:right'>" + sectionAmt.ToString("N2") + "</td>");
                sb.Append("</tr>");

                sectionQty = 0;
                sectionAmt = 0;
            }

            currentType = ptype;
            sectionQty += qty;
            sectionAmt += amt;
            grandQty += qty;
            grandAmt += amt;

            sb.Append("<tr>");
            sb.Append("<td>" + sr++ + "</td>");
            sb.Append("<td>" + row["pdate"] + "</td>");
            sb.Append("<td>" + row["pno"] + "</td>");
            sb.Append("<td>" + ptype + "</td>");
            sb.Append("<td>" + row["Item_G_Name"] + "</td>");
            sb.Append("<td>" + row["itemname"] + "</td>");
            sb.Append("<td style='text-align:right'>" + qty.ToString("0.##") + "</td>");
            sb.Append("<td style='text-align:right'>" + rate.ToString("N2") + "</td>");
            sb.Append("<td style='text-align:right'>" + amt.ToString("N2") + "</td>");
            sb.Append("</tr>");
        }

        if (currentType != "")
        {
            sb.Append("<tr style='font-weight:bold;background:#f5f5f5'>");
            sb.Append("<td colspan='6' style='text-align:right'>" + currentType + " TOTAL</td>");
            sb.Append("<td style='text-align:right'>" + sectionQty + "</td>");
            sb.Append("<td></td>");
            sb.Append("<td style='text-align:right'>" + sectionAmt.ToString("N2") + "</td>");
            sb.Append("</tr>");
        }

        sb.Append("<tr style='font-weight:bold;background:#d9edf7'>");
        sb.Append("<td colspan='6' style='text-align:right'>GRAND TOTAL</td>");
        sb.Append("<td style='text-align:right'>" + grandQty + "</td>");
        sb.Append("<td></td>");
        sb.Append("<td style='text-align:right'>" + grandAmt.ToString("N2") + "</td>");
        sb.Append("</tr>");

        sb.Append("</table></div>");

        ltTable.Text = sb.ToString();
    }

    protected void btnExportExcel_Click(object sender, EventArgs e)
    {
       
    }
    public override void VerifyRenderingInServerForm(Control control)
    {

    }


}