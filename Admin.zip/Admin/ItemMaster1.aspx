﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Admin1/AdminMaster1.master" AutoEventWireup="true" CodeFile="ItemMaster1.aspx.cs" Inherits="Admin_ItemMaster1" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
    <link href="Style.css" rel="stylesheet" />
    <style>
        .swal-footer {
            text-align: center !important;
        }

        .swal-text {
            font-size: 22px !important;
            text-align: center;
        }

        .swal-button {
            background-color: #184f34 !important;
        }
    </style>
    <script type="text/javascript" src="sweetalertnew.js"></script>
    <script type="text/javascript">
        function savealert(message, type) {
            swal({
                text: message,
                icon: type === 'success' ? 'success' : type === 'info' ? 'info' : type === 'error' ? 'error' : 'warning',
            });
        }
    </script>
    <script type="text/javascript">
        window.history.forward();
        function noBack() {
            window.history.forward();
        }
    </script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="Server">
    <div class="container" style="margin-top: 100px;">
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-8" style="border: 1px solid;">
                <div class="form-group">
                    <div class="row">
                        <div class="col-md-12">
                            <h5 style="text-align: center; margin-top: 10px; font-weight: 600;">Item Master</h5>
                        </div>
                    </div>
                </div>
                <hr />
                <div class="form-group">
                    <div class="row">
                        <div class="col-md-1"></div>
                        <div class="col-md-2">
                            <asp:Label runat="server" ID="lblasdf" Text="Item Code" ForeColor="Black"></asp:Label>
                        </div>
                        <div class="col-md-3">
                            <asp:TextBox runat="server" ID="txtitemcode" CssClass="form-control" ForeColor="Black"></asp:TextBox>
                        </div>
                        <div class="col-md-2">
                            <asp:Label runat="server" ID="Label1" Text="Group" ForeColor="Black"></asp:Label>
                        </div>
                        <div class="col-md-3">
                            <asp:DropDownList runat="server" ID="ddlgroup" CssClass="form-control" ForeColor="Black" onchange="toggleRateByGroup(this)"></asp:DropDownList>
                        </div>
                        <div class="col-md-1"></div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="row">
                        <div class="col-md-1"></div>
                        <div class="col-md-2">
                            <asp:Label runat="server" ID="Label2" Text="Item Name" ForeColor="Black"></asp:Label>
                        </div>
                        <div class="col-md-3">
                            <asp:TextBox runat="server" ID="txtitemname" CssClass="form-control" ForeColor="Black"></asp:TextBox>
                        </div>
                        <div class="col-md-2">
                            <asp:Label runat="server" Text="GST %" ForeColor="Black"></asp:Label>
                        </div>
                        <div class="col-md-3">
                            <asp:TextBox runat="server" ID="txtgst" CssClass="form-control" ForeColor="Black"></asp:TextBox>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="row">
                        <div class="col-md-1"></div>
                        <div class="col-md-2">
                            <asp:Label runat="server" Text="Quantity" ForeColor="Black"></asp:Label>
                        </div>
                        <div class="col-md-3">
                            <asp:TextBox runat="server" ID="txtqty" CssClass="form-control" ForeColor="Black"></asp:TextBox>
                        </div>

                        <div class="col-md-2">
                            <asp:Label runat="server" ID="Label3" Text="Unit" ForeColor="Black"></asp:Label>
                        </div>
                        <div class="col-md-3">
                            <asp:DropDownList runat="server" ID="ddlunit" CssClass="form-control" ForeColor="Black">
                                <asp:ListItem Text="--Select--" Value="0"></asp:ListItem>
                                <asp:ListItem Text="ML" Value="ML"></asp:ListItem>
                                <asp:ListItem Text="Kg" Value="Kg"></asp:ListItem>
                                <asp:ListItem Text="ltr" Value="ltr"></asp:ListItem>
                                <asp:ListItem Text="pcs" Value="pcs"></asp:ListItem>
                                <asp:ListItem Text="tin" Value="tin"></asp:ListItem>
                            </asp:DropDownList>
                        </div>
                        <div class="col-md-1"></div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="row">
                        <div class="col-md-1"></div>
                        <div class="col-md-2">
                            <asp:Label runat="server" Text="Rate" ForeColor="Black"></asp:Label>
                        </div>
                        <div class="col-md-3">
                            <asp:TextBox runat="server" ID="txtitemrate" CssClass="form-control" ForeColor="Black"></asp:TextBox>
                        </div>

                        <div class="col-md-2">
                            <asp:Label runat="server" Text="MRP" ForeColor="Black"></asp:Label>
                        </div>
                        <div class="col-md-3">
                            <asp:TextBox runat="server" ID="txtmrp" CssClass="form-control" ForeColor="Black"></asp:TextBox>
                        </div>
                        <div class="col-md-1"></div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="row">
                        <div class="col-md-1"></div>
                        <div class="col-md-2">
                            <asp:Label runat="server" ID="Label4" Text="Item Image" ForeColor="Black"></asp:Label>
                        </div>
                        <div class="col-md-3">
                            <asp:FileUpload runat="server" ID="filename" ForeColor="Black"></asp:FileUpload>
                        </div>
                        <div class="col-md-1"></div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="row">
                        <div class="col-md-5"></div>
                        <div class="col-md-3">
                            <asp:Button runat="server" ID="btnsave" Text="Save" CssClass="btn btn-success" OnClick="btnsave_Click"></asp:Button>
                            <asp:Button runat="server" ID="btnback" Text="Back" CssClass="btn btn-danger" OnClick="btnback_Click"></asp:Button>
                        </div>
                        <div class="col-md-4"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</asp:Content>
