﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Admin_ItemMaster : System.Web.UI.Page
{
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    HttpCookie lgdcookie;
    Class1 cl = new Class1();

    protected void Page_Load(object sender, EventArgs e)
    {
        lgdcookie = Request.Cookies["loggeduser"];
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        if (lgdcookie != null && !string.IsNullOrEmpty(lgdcookie["UserName"]))
        {
            if (!IsPostBack)
            {
                txtitemcode.Text = cl.Scalar("SELECT isnull(Max(sku+1),1)sku from Item_detail where deactive='0'");
                txtitemcode.ReadOnly = true;
                bindgroup();
                bindetail();
            }
        }
        else
        {
            Response.Redirect("Login.aspx");
        }
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        try
        {
            if (btnsave.Text == "Save")
            {
                try
                {
                    if (txtitemcode.Text.Trim() == "")
                    {
                        saveMsg("Please enter Item Code", "warning");
                        return;
                    }

                    if (txtitemname.Text.Trim() == "")
                    {
                        saveMsg("Please enter Item Name", "warning");
                        return;
                    }

                    if (ddlgroup.SelectedIndex == 0)
                    {
                        saveMsg("Please select Item Group", "warning");
                        return;
                    }

                    string imagePath = "";
                    if (filename.HasFile)
                    {
                        string ext = System.IO.Path.GetExtension(filename.FileName).ToLower();

                        if (ext != ".jpg" && ext != ".jpeg" && ext != ".png")
                        {
                            saveMsg("Only JPG / PNG images allowed", "warning");
                            return;
                        }

                        string imgName = DateTime.Now.Ticks + ext;
                        imagePath = "~/ItemImages/" + imgName;

                        string folderPath = Server.MapPath("~/ItemImages/");
                        if (!System.IO.Directory.Exists(folderPath))
                            System.IO.Directory.CreateDirectory(folderPath);

                        filename.SaveAs(Server.MapPath(imagePath));
                    }

                    cl.con.Open();
                    SqlCommand chk = new SqlCommand("select count(*) from item_detail where sku=@code",
                        cl.con);
                    chk.Parameters.AddWithValue("@code", txtitemcode.Text.Trim());

                    int exists = Convert.ToInt32(chk.ExecuteScalar());
                    if (exists > 0)
                    {
                        cl.con.Close();
                        saveMsg("Item Code already exists", "warning");
                        return;
                    }
                    int flag = 1;

                    string groupName = ddlgroup.SelectedItem.Text;

                    string[] zeroFlagGroups = { "Malts", "Scotch And Whisky", "Other Spirits", "Blended Whisky", "Vodka", "Rum", "Strong Beer", "Lager Beer", "COMPL" };

                    if (zeroFlagGroups.Contains(groupName))
                    {
                        flag = 0;
                    }

                    SqlCommand cmd = new SqlCommand("insert into item_detail (SKU, item_name, item_group_name, item_unit,item_sale_rate,gst_per, indate, insuser,deactive, instime,flag,Rate_X1,Rate_X12,Rate_X25,Rate_X4,productimage) values (@code,@name,@group,@unit,@rate , @gst_per,@date,@user,0,@time,@flag,@Rate_X1,@Rate_X12,@Rate_X25,@Rate_X4,@image)", cl.con);

                    cmd.Parameters.AddWithValue("@code", txtitemcode.Text.Trim());
                    cmd.Parameters.AddWithValue("@name", txtitemname.Text.Trim());
                    cmd.Parameters.AddWithValue("@group", ddlgroup.SelectedValue);
                    cmd.Parameters.AddWithValue("@unit", ddlunit.SelectedValue);
                    cmd.Parameters.AddWithValue("@Gst_per", txtgst.Text);
                    cmd.Parameters.AddWithValue("@rate", txtitemrate.Text);
                    cmd.Parameters.AddWithValue("@Rate_X1", txtX1.Text);
                    cmd.Parameters.AddWithValue("@Rate_X12", txtX12.Text);
                    cmd.Parameters.AddWithValue("@Rate_X25", txtX25.Text);
                    cmd.Parameters.AddWithValue("@Rate_X4", txtX4.Text);
                    cmd.Parameters.AddWithValue("@date", dateTime.ToString("yyyy-MM-dd"));
                    cmd.Parameters.AddWithValue("@user", lgdcookie["UserName"].ToString());
                    cmd.Parameters.AddWithValue("@time", dateTime.ToString("hh:mm:ss tt"));
                    cmd.Parameters.AddWithValue("@flag", flag);
                    cmd.Parameters.AddWithValue("@image", imagePath);
                    cmd.ExecuteNonQuery();
                    cl.con.Close();
                    txtitemcode.Text = cl.Scalar("SELECT isnull(Max(sku+1),1)sku from Item_detail where deactive='0'");
                    saveMsg("Item saved successfully", "success");
                    clearForm();
                }
                catch (Exception ex)
                {
                    saveMsg("Something went wrong", "error");
                }
            }
            else if (btnsave.Text == "Update")
            {
                string imagePath = imgPreview.ImageUrl; // default old image

                if (filename.HasFile)
                {
                    string ext = System.IO.Path.GetExtension(filename.FileName).ToLower();

                    if (ext != ".jpg" && ext != ".jpeg" && ext != ".png")
                    {
                        saveMsg("Only JPG / PNG images allowed", "warning");
                        return;
                    }

                    string imgName = DateTime.Now.Ticks + ext;
                    imagePath = "~/ItemImages/" + imgName;

                    string folderPath = Server.MapPath("~/ItemImages/");
                    if (!System.IO.Directory.Exists(folderPath))
                        System.IO.Directory.CreateDirectory(folderPath);

                    filename.SaveAs(Server.MapPath(imagePath));
                }
                cl.con.Open();

                SqlCommand cmd = new SqlCommand(@"update Item_detail set
                    item_name=@name,
                    item_group_name=@group,
                    item_unit=@unit,
                    item_sale_rate=@rate,
                    gst_per=@gst,
                    Rate_X1=@Rate_X1,
                    Rate_X12=@Rate_X12,
                    Rate_X25=@Rate_X25,
                    Rate_X4=@Rate_X4 ,
                    productimage =@imagePath
                    where SKU=@code", cl.con);

                cmd.Parameters.AddWithValue("@code", txtitemcode.Text.Trim());
                cmd.Parameters.AddWithValue("@name", txtitemname.Text.Trim());
                cmd.Parameters.AddWithValue("@group", ddlgroup.SelectedValue);
                cmd.Parameters.AddWithValue("@unit", ddlunit.SelectedValue);
                cmd.Parameters.AddWithValue("@rate", txtitemrate.Text);
                cmd.Parameters.AddWithValue("@gst", txtgst.Text);
                cmd.Parameters.AddWithValue("@Rate_X1", txtX1.Text);
                cmd.Parameters.AddWithValue("@Rate_X12", txtX12.Text);
                cmd.Parameters.AddWithValue("@Rate_X25", txtX25.Text);
                cmd.Parameters.AddWithValue("@Rate_X4", txtX4.Text);
                cmd.Parameters.AddWithValue("@imagePath", imagePath);

                cmd.ExecuteNonQuery();
                cl.con.Close();

                saveMsg("Item Updated Successfully", "success");

                btnsave.Text = "Save";
                txtitemcode.Text = cl.Scalar("SELECT isnull(Max(sku+1),1)sku from Item_detail where deactive='0'");
                clearForm();
                bindetail();
            }

        }
        catch (Exception ex)
        {

        }
    }
    void saveMsg(string msg, string type)
    {
        ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "savealert('" + msg + "','" + type + "');",
            true);
    }
    void clearForm()
    {
        txtitemname.Text = "";
        ddlgroup.SelectedIndex = 0;
        ddlunit.SelectedIndex = 0;
        txtitemrate.Text = "";
        txtgst.Text = "";
        txtX25.Text = "";
        txtX12.Text = "";
        txtX1.Text = "";
        txtX4.Text = "";
        imgPreview.ImageUrl = "";
        imgPreview.Visible = false;

    }

    protected void btnback_Click(object sender, EventArgs e)
    {
        Response.Redirect("Dashboard.aspx");
    }
    public void bindgroup()
    {
        try
        {
            string str = "select item_g_id,item_g_name from item_group_master where deactive='0' order by item_g_name";
            SqlCommand cmd = new SqlCommand(str, cl.con);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt1 = new DataTable();
            adp.Fill(dt1);
            if (dt1.Rows.Count > 0)
            {
                ddlgroup.DataSource = dt1;
                ddlgroup.DataTextField = "item_g_name";
                ddlgroup.DataValueField = "item_g_id";
                ddlgroup.DataBind();
                ddlgroup.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception)
        {

        }
    }
    public void bindetail()
    {
        try
        {
            string query = "select SKU, item_name, im.Item_G_Name,item_sale_rate,gst_per,Rate_X1,Rate_X12,Rate_X25,Rate_X4,case when(id.Deactive='0') then 'De-Active' else 'Active' end as inactive,productImage from Item_detail id left join Item_group_Master im on id.Item_group_name = im.Item_G_Id ";
            SqlDataAdapter sda = new SqlDataAdapter(query, cl.con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                listview2.DataSource = dt;
                listview2.DataBind();
            }
        }
        catch (Exception ex)
        {

        }
    }
    protected void btnedit_Click(object sender, EventArgs e)
    {
        try
        {
            Button btn = (Button)sender;
            ListViewItem item = (ListViewItem)btn.NamingContainer;
            Label lblcode = (Label)item.FindControl("lblcode");

            string query = "select SKU, item_name, item_group_name,item_sale_rate, gst_per, flag, Rate_X1, Rate_X12, Rate_X25, Rate_X4,productImage from Item_detail where SKU=@sku";

            SqlCommand cmd = new SqlCommand(query, cl.con);
            cmd.Parameters.AddWithValue("@sku", lblcode.Text);

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                txtitemcode.Text = dt.Rows[0]["SKU"].ToString();
                txtitemname.Text = dt.Rows[0]["item_name"].ToString();
                txtitemrate.Text = dt.Rows[0]["item_sale_rate"].ToString();
                txtgst.Text = dt.Rows[0]["gst_per"].ToString();

                ddlgroup.SelectedValue = dt.Rows[0]["item_group_name"].ToString();

                txtX1.Text = dt.Rows[0]["Rate_X1"].ToString();
                txtX12.Text = dt.Rows[0]["Rate_X12"].ToString();
                txtX25.Text = dt.Rows[0]["Rate_X25"].ToString();
                txtX4.Text = dt.Rows[0]["Rate_X4"].ToString();

                int flag = 1;
                if (dt.Rows[0]["flag"] != DBNull.Value)
                {
                    flag = Convert.ToInt32(dt.Rows[0]["flag"]);
                }

                if (flag == 0)
                {
                    divSingleRate.Style["display"] = "none";
                    divMultiRate.Style["display"] = "block";
                }
                else
                {
                    divSingleRate.Style["display"] = "block";
                    divMultiRate.Style["display"] = "none";
                }
                string img = dt.Rows[0]["productImage"] == DBNull.Value
     ? ""
     : dt.Rows[0]["productImage"].ToString();

                if (!string.IsNullOrEmpty(img))
                {
                    imgPreview.ImageUrl = img;
                    imgPreview.Visible = true;
                }
                else
                {
                    imgPreview.Visible = false;
                }
                btnsave.Text = "Update";
            }
            else
            {
                saveMsg("Record not found", "error");
            }
        }
        catch (Exception)
        {
            saveMsg("Error while loading record", "error");
        }
    }
    protected void btndelete_Click(object sender, EventArgs e)
    {
        try
        {
            Button btn = (Button)sender;
            ListViewItem item = (ListViewItem)btn.NamingContainer;
            Label lblid1 = (Label)item.FindControl("lblcode");

            cl.con.Open();

            SqlCommand cmdCheck = new SqlCommand("select deactive from Item_detail where sku=@sku", cl.con);
            cmdCheck.Parameters.AddWithValue("@sku", lblid1.Text);

            int current = Convert.ToInt32(cmdCheck.ExecuteScalar());
            int newStatus = current == 0 ? 1 : 0;

            SqlCommand cmdUpdate = new SqlCommand(
                "update Item_detail set deactive=@status where sku=@sku", cl.con);
            cmdUpdate.Parameters.AddWithValue("@status", newStatus);
            cmdUpdate.Parameters.AddWithValue("@sku", lblid1.Text);

            cmdUpdate.ExecuteNonQuery();
            cl.con.Close();

            bindetail();

            if (newStatus == 1)
                saveMsg("Record Deactivated Successfully !!", "info");
            else
                saveMsg("Record Activated Successfully !!", "success");
        }
        catch
        {
            saveMsg("Something went wrong", "error");
        }
    }

}