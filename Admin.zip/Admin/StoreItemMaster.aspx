﻿<%@ Page Title="" Language="C#" MasterPageFile="../Admin/AdminMaster.master" AutoEventWireup="true" CodeFile="StoreItemMaster.aspx.cs" Inherits="Admin_StoreItemMaster" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
    <link href="Style.css" rel="stylesheet" />
    <style>
        .swal-footer {
            text-align: center !important;
        }

        .swal-text {
            font-size: 22px !important;
            text-align: center;
        }

        .swal-button {
            background-color: #184f34 !important;
        }
    </style>
    <script type="text/javascript" src="sweetalertnew.js"></script>
    <script type="text/javascript">
        function savealert(message, type) {
            swal({
                text: message,
                icon: type === 'success' ? 'success' : type === 'info' ? 'info' : type === 'error' ? 'error' : 'warning',
            });
        }
    </script>
    <script type="text/javascript">
        window.history.forward();
        function noBack() {
            window.history.forward();
        }
    </script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="Server">
    <div class="container" style="margin-top: 50px;">
        <div class="row">
            <div class="col-md-1"></div>
            <div class="col-md-10">
                <div class="row">
                    <div class="col-md-12" style="border: 1px solid;">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-12">
                                    <h5 style="text-align: center; margin-top: 10px; font-weight: 600;">Store Item Master</h5>
                                </div>
                            </div>
                        </div>
                        <hr />
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-1"></div>
                                <div class="col-md-2">
                                    <asp:Label runat="server" ID="lblasdf" Text="Item Code" ForeColor="Black"></asp:Label>
                                </div>
                                <div class="col-md-3">
                                    <asp:TextBox runat="server" ID="txtitemcode" CssClass="form-control" ForeColor="Black"></asp:TextBox>
                                </div>
                                <div class="col-md-2">
                                    <asp:Label runat="server" ID="Label1" Text="Item Group" ForeColor="Black"></asp:Label>
                                </div>
                                <div class="col-md-3">
                                    <asp:DropDownList runat="server" ID="ddlgroup" CssClass="form-control" ForeColor="Black"></asp:DropDownList>
                                </div>
                                <div class="col-md-1"></div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-1"></div>
                                <div class="col-md-2">
                                    <asp:Label runat="server" ID="Label2" Text="Item Name" ForeColor="Black"></asp:Label>
                                </div>
                                <div class="col-md-3">
                                    <asp:TextBox runat="server" ID="txtitemname" CssClass="form-control" ForeColor="Black"></asp:TextBox>
                                </div>
                                <div class="col-md-2">
                                    <asp:Label runat="server" ID="Label3" Text="Unit" ForeColor="Black"></asp:Label>
                                </div>
                                <div class="col-md-3">
                                    <asp:DropDownList runat="server" ID="ddlunit" CssClass="form-control" ForeColor="Black">
                                        <asp:ListItem Text="Kg" Value="Kg"></asp:ListItem>
                                        <asp:ListItem Text="ltr" Value="ltr"></asp:ListItem>
                                        <asp:ListItem Text="pcs" Value="pcs"></asp:ListItem>
                                        <asp:ListItem Text="tin" Value="tin"></asp:ListItem>
                                        <asp:ListItem Text="grm" Value="grm"></asp:ListItem>
                                    </asp:DropDownList>
                                </div>
                                <div class="col-md-1"></div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-1"></div>
                                <div class="col-md-2">
                                    <asp:Label runat="server" ID="Label6" Text="Rate" ForeColor="Black"></asp:Label>
                                </div>
                                <div class="col-md-3">
                                    <asp:TextBox runat="server" ID="txtrate" CssClass="form-control" ForeColor="Black"></asp:TextBox>
                                </div>
                                <div class="col-md-2" style="display: none;">
                                    <asp:Label runat="server" ID="Label7" Text="Product Image" ForeColor="Black"></asp:Label>
                                </div>
                                <div class="col-md-3" style="display: none;">
                                    <asp:FileUpload runat="server" ID="imgefile" CssClass="form-control" ForeColor="Black"></asp:FileUpload>
                                </div>
                                <div class="col-md-1"></div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-5"></div>
                                <div class="col-md-3">
                                    <asp:Button runat="server" ID="btnsave" Text="Save" CssClass="btn btn-success" OnClick="btnsave_Click"></asp:Button>
                                    <asp:Button runat="server" ID="btnback" Text="Back" CssClass="btn btn-danger" OnClick="btnback_Click"></asp:Button>
                                </div>
                                <div class="col-md-4">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row" style="border: 1px solid; margin-top: 20px; margin-bottom: 20px;">
            <div class="col-md-12" style="overflow-y: scroll; height: 500px;">
                <asp:ListView ID="listview2" runat="server" Style="color: black !important;">
                    <LayoutTemplate>
                        <table class="table table-bordered">
                            <tr>
                                <th style="width: 15%;">Item Code</th>
                                <th style="width: 15%;">Group Name</th>
                                <th style="width: 30%;">Item Name</th>
                                <th style="width: 10%;">Item Rate</th>
                                <th style="width: 10%;">Unit</th>
                                <th style="width: 20%;">Action</th>
                            </tr>
                            <tbody>
                                <asp:PlaceHolder ID="itemPlaceHolder" runat="server" />
                            </tbody>
                        </table>
                    </LayoutTemplate>
                    <ItemTemplate>
                        <tr>
                            <td>
                                <asp:Label ID="lblcode" runat="server" Text=' <%# Eval("sku")%>'></asp:Label></td>
                            <td>
                                <asp:Label ID="Label4" runat="server" Text=' <%# Eval("item_group_name")%>'></asp:Label></td>
                            <td>
                                <asp:Label ID="Label5" runat="server" Text=' <%# Eval("item_name")%>'></asp:Label></td>
                            <td>
                                <asp:Label ID="lblrate" runat="server" Text=' <%# Eval("item_sale_rate")%>'></asp:Label></td>
                            <td>
                                <asp:Label ID="lblitemname" runat="server" Text=' <%# Eval("item_unit")%>'></asp:Label></td>
                            <td>
                                <asp:Button runat="server" ID="btnedit" Text="Edit" CssClass="btn btn-warning" OnClick="btnedit_Click" />
                                <asp:Button runat="server" ID="btndelete" Text='<%# Eval("inactive")%>' CssClass="btn btn-danger" OnClick="btndelete_Click" OnClientClick="return showConfirm();" />
                            </td>
                        </tr>
                    </ItemTemplate>
                </asp:ListView>
            </div>
        </div>
    </div>
</asp:Content>

