﻿<%@ Page Title="" Language="C#" MasterPageFile="../Admin/AdminMaster.master" AutoEventWireup="true" CodeFile="StockReport.aspx.cs" Inherits="StockReport" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="Server">
    <div class="container">
        <div class="form-group">
            <div class="row" style="margin-top: 30px;">
                <div class="col-md-3"></div>
                <div class="col-md-6" style="border: 1px solid #ca9142; box-shadow: 0px 0px 8px -3px #ec9190;">
                    <div class="row" style="border-bottom: 1px solid #ccc; margin-bottom: 15px;">
                        <div class="col-md-12">
                            <div class="form-group" style="margin-bottom: 0px;">
                                <h3 style="text-align: center; color: #339eae; font-size: 20px; font-weight: 500; margin: 20px;">Stock Report</h3>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-1"></div>
                            <div class="col-md-4">
                                <asp:Label runat="server" ID="lblkdas" Text="From Date" ForeColor="Black"></asp:Label>
                            </div>
                            <div class="col-md-6">
                                <asp:TextBox runat="server" CssClass="form-control" ID="txtfdt" TextMode="Date"></asp:TextBox>
                            </div>
                            <div class="col-md-1"></div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-1"></div>
                            <div class="col-md-4">
                                <asp:Label runat="server" ID="Label1" Text="To Date" ForeColor="Black"></asp:Label>
                            </div>
                            <div class="col-md-6">
                                <asp:TextBox runat="server" ID="txttodate" CssClass="form-control" TextMode="Date"></asp:TextBox>
                            </div>
                            <div class="col-md-1"></div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row mt-3" style="margin-bottom: 10px; border-top: 1px solid #ccc">
                            <div class="col-md-2"></div>
                            <div class="col-md-8 mt-3">
                                <div class="text-center">
                                    <asp:Button runat="server" ID="btnview" Text="View" OnClick="btnview_Click" CssClass="btn btn-primary" />
                                    <asp:Button runat="server" ID="btnexcel" Text="Export To Excel" OnClick="btnexcel_Click" CssClass="btn btn-info" Style="display: none;" />
                                    <asp:Button runat="server" ID="btnexporttopdf" Text="Export To Pdf" OnClick="btnexporttopdf_Click" CssClass="btn btn-primary" />
                                    <asp:Button ID="btnback" runat="server" Text="Back" class="btn btn-danger" Font-Bold="true" OnClick="btnback_Click" />
                                </div>
                            </div>
                            <div class="col-md-2"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3"></div>
            </div>
        </div>
        <asp:ListView ID="lvReport" runat="server">
            <LayoutTemplate>
                <table border="1" style="width: 100%; border-collapse: collapse">
                    <tr style="background: #eee; font-weight: bold">
                        <th>Category</th>
                        <th>Item Name</th>
                        <th style='text-align: right'>Opening Qty</th>
                        <th style='text-align: right'>Purchase Qty</th>
                        <th style='text-align: right'>Issue Qty</th>
                        <th style='text-align: right'>Closing Qty</th>
                        <th style='text-align: right'>Rate</th>
                        <th style='text-align: right'>Closing Amount</th>
                    </tr>
                    <asp:PlaceHolder ID="itemPlaceholder" runat="server" />
                </table>
            </LayoutTemplate>
            <ItemTemplate>
                <tr>
                    <td><%# Eval("itemcategory") %></td>
                    <td><%# Eval("Item_name") %></td>
                    <td style='text-align: right'><%# Eval("openingQty") %></td>
                    <td style='text-align: right'><%# Eval("PurchaseQty") %></td>
                    <td style='text-align: right'><%# Eval("IssueQty") %></td>
                    <td style='text-align: right'><%# Eval("ClosingQty") %></td>
                    <td style='text-align: right'><%# Eval("Rate") %></td>
                    <td style='text-align: right'><%# Eval("ClosingAmount") %></td>
                </tr>
            </ItemTemplate>
            <EmptyDataTemplate>
                <p>No records found.</p>
            </EmptyDataTemplate>
        </asp:ListView>
    </div>
</asp:Content>

