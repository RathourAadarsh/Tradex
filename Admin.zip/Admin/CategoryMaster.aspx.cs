﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_CategoryMaster : System.Web.UI.Page
{
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    Class1 cl3 = new Class1();
    HttpCookie lgdcookie;
    protected void Page_Load(object sender, EventArgs e)
    {
        lgdcookie = Request.Cookies["loggeduser"];
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        if (!IsPostBack)
        {
            txtgid.Text = cl3.Scalar("SELECT isnull(Max(Autoid+1),1)Autoid from Category");
            txtgid.ReadOnly = true;
            bindetail();
        }
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        try
        {
            lgdcookie = Request.Cookies["loggeduser"];
            if (txtgrpname.Text == "")
            {
                string message = "Please Enter Item Category Name !!";
                string type = "warning";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "savealert('" + message + "','" + type + "')", true);
                return;
            }
            else
            {
                if (btnsave.Text == "Save")
                {
                    string imagePath = "";

                    if (fuImage.HasFile)
                    {
                        string folderPath = Server.MapPath("~/CategoryImages/");
                        if (!System.IO.Directory.Exists(folderPath))
                        {
                            System.IO.Directory.CreateDirectory(folderPath);
                        }

                        string fileName = Guid.NewGuid().ToString() + System.IO.Path.GetExtension(fuImage.FileName);
                        string fullPath = folderPath + fileName;

                        fuImage.SaveAs(fullPath);
                        imagePath = "~/CategoryImages/" + fileName;
                    }

                    string query = "INSERT INTO Category(Autoid,categoryname,imageurl,insdate,instime,isactive,insuser) " +
                                   "VALUES(@id,@name,@img,@date,@time,'1',@user)";

                    cl3.con.Open();
                    SqlCommand cmd = new SqlCommand(query, cl3.con);

                    cmd.Parameters.AddWithValue("@id", txtgid.Text);
                    cmd.Parameters.AddWithValue("@name", txtgrpname.Text);
                    cmd.Parameters.AddWithValue("@img", imagePath);
                    cmd.Parameters.AddWithValue("@date", dateTime.ToString("yyyy-MM-dd"));
                    cmd.Parameters.AddWithValue("@time", dateTime.ToString("hh:mm:ss tt"));
                    cmd.Parameters.AddWithValue("@user", lgdcookie["username"].ToString());

                    cmd.ExecuteNonQuery();
                    cl3.con.Close();

                    bindetail();
                }

                else
                {
                    cl3.con.Open();
                    string query = "UPDATE Category SET categoryname = @categoryname WHERE Autoid = @item_g_id";
                    using (SqlCommand cmd = new SqlCommand(query, cl3.con))
                    {
                        cmd.Parameters.AddWithValue("@categoryname", txtgrpname.Text);
                        cmd.Parameters.AddWithValue("@item_g_id", txtgid.Text);

                        int result = cmd.ExecuteNonQuery();
                        cl3.con.Close();

                        if (result > 0)
                        {
                            string redirectUrl = "CategoryMaster.aspx";
                            string message = "Record Updated Successfully !!";
                            string type = "success";
                            string script = "savealert('" + message + "','" + type + "'); setTimeout(function() { window.location.href = '" + redirectUrl + "'; },1000);";
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", script, true);
                            return;
                        }
                        else
                        {
                            string message = "Something Went Wrong !!";
                            string type = "error";
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "savealert('" + message + "','" + type + "')", true);
                            return;
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {

        }
    }
    public void bindetail()
    {
        try
        {
            string query = "select Autoid, categoryname,isactive,imageurl from Category";
            SqlDataAdapter sda = new SqlDataAdapter(query, cl3.con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                listview2.DataSource = dt;
                listview2.DataBind();
            }
        }
        catch (Exception ex)
        {

        }
    }
    protected void btnback_Click(object sender, EventArgs e)
    {
        Response.Redirect("Dashboard.aspx");
    }
    protected void btnedit_Click(object sender, EventArgs e)
    {
        try
        {
            Button button1 = (Button)sender;
            ListViewItem item = (ListViewItem)button1.NamingContainer;
            Label lblid1 = (Label)item.FindControl("lblcode");
            string query = "select Autoid, categoryname,isactive from Category where isactive='1' and Autoid ='" + lblid1.Text + "'";
            SqlDataAdapter sda = new SqlDataAdapter(query, cl3.con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                txtgid.Text = dt.Rows[0]["Autoid"].ToString();
                txtgrpname.Text = dt.Rows[0]["categoryname"].ToString();
                btnsave.Text = "Update";
            }
            else
            {
                string message = "Something Went Wrong !!";
                string type = "error";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "savealert('" + message + "','" + type + "')", true);
                return;
            }
        }
        catch (Exception ex)
        {

        }
    }
    protected void btndelete_Click(object sender, EventArgs e)
    {
        Button button1 = (Button)sender;
        ListViewItem item = (ListViewItem)button1.NamingContainer;
        Label lblid1 = (Label)item.FindControl("lblcode");

        cl3.con.Open();

        string checkQuery = "SELECT isactive FROM Category WHERE Autoid=@id";
        SqlCommand checkCmd = new SqlCommand(checkQuery, cl3.con);
        checkCmd.Parameters.AddWithValue("@id", lblid1.Text);

        bool status = Convert.ToBoolean(checkCmd.ExecuteScalar());

        string updateQuery;

        if (status)
            updateQuery = "UPDATE Category SET isactive=0 WHERE Autoid=@id";
        else
            updateQuery = "UPDATE Category SET isactive=1 WHERE Autoid=@id";

        SqlCommand cmd = new SqlCommand(updateQuery, cl3.con);
        cmd.Parameters.AddWithValue("@id", lblid1.Text);
        cmd.ExecuteNonQuery();

        cl3.con.Close();

        bindetail();
    }



}