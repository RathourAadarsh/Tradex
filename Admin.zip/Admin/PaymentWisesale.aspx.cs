﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_PaymentWisesale : System.Web.UI.Page
{
    Class1 cl = new Class1();
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    protected void Page_Load(object sender, EventArgs e)
    {
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        if (!IsPostBack)
        {
            txtfrom.Text = dateTime.ToString("yyyy-MM-dd");
            txtto.Text = dateTime.ToString("yyyy-MM-dd");
        }
    }
    protected void btnExportPaymentMode_Click(object sender, EventArgs e)
    {
        DateTime fromDate = DateTime.Parse(txtfrom.Text);
        DateTime toDate = DateTime.Parse(txtto.Text);

        DataTable dt = new DataTable();

        string query = @"SELECT 
    PaymentType,
    COUNT(*) AS TotalBills,
    SUM(SubTotal) AS BasicAmount,
    SUM(Tax) AS GSTAmount,
    SUM(GrandTotal) AS TotalAmount
FROM
(
    SELECT Bill_ID, SubTotal, Tax, GrandTotal, 'CASH' AS PaymentType
    FROM Bill_Master
    WHERE ISNULL(CashAmount,0) > 0
      AND IsPaid = 1
      AND Bill_Date >= @fromdate
      AND Bill_Date < DATEADD(DAY,1,@todate)

    UNION ALL

    SELECT Bill_ID, SubTotal, Tax, GrandTotal, 'CARD'
    FROM Bill_Master
    WHERE ISNULL(CardAmount,0) > 0
      AND IsPaid = 1
      AND Bill_Date >= @fromdate
      AND Bill_Date < DATEADD(DAY,1,@todate)

    UNION ALL

    SELECT Bill_ID, SubTotal, Tax, GrandTotal, 'UPI'
    FROM Bill_Master
    WHERE ISNULL(UpiAmount,0) > 0
      AND IsPaid = 1
      AND Bill_Date >= @fromdate
      AND Bill_Date < DATEADD(DAY,1,@todate)

    UNION ALL

    SELECT Bill_ID, SubTotal, Tax, GrandTotal, 'CREDIT'
    FROM Bill_Master
    WHERE ISNULL(CreditAmount,0) > 0
      AND IsPaid = 1
      AND Bill_Date >= @fromdate
      AND Bill_Date < DATEADD(DAY,1,@todate)

) A
GROUP BY PaymentType
ORDER BY PaymentType";
        SqlCommand cmd = new SqlCommand(query, cl.con);
        cmd.Parameters.AddWithValue("@fromdate", fromDate);
        cmd.Parameters.AddWithValue("@todate", toDate);

        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);

        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition",
            "attachment;filename=PaymentModeWiseSale_" + DateTime.Now.ToString("ddMMyyyy") + ".xls");
        Response.ContentType = "application/vnd.ms-excel";

        System.IO.StringWriter sw = new System.IO.StringWriter();

        sw.Write("<table border='1' style='font-family:Calibri;font-size:14px;width:100%'>");

        sw.Write("<tr><td colspan='5' style='font-size:18px;font-weight:bold;text-align:center'>Charans Club & Resort Pvt Ltd Report</td></tr>");
        sw.Write("<tr><td colspan='5' style='font-size:18px;font-weight:bold;text-align:center'>Payment Mode Wise Sale Report</td></tr>");
        sw.Write("<tr><td colspan='5'><b>Period :</b> " +
                 fromDate.ToString("dd-MM-yyyy") + " to " +
                 toDate.ToString("dd-MM-yyyy") + "</td></tr>");

        sw.Write("<tr style='font-weight:bold;background:#f2f2f2'>");
        sw.Write("<td>Payment Mode</td>");
        sw.Write("<td>Total Bills</td>");
        sw.Write("<td>Taxable Amt</td>");
        sw.Write("<td>GST</td>");
        sw.Write("<td>Total Amount</td>");
        sw.Write("</tr>");

        decimal grandTotal = 0;

        foreach (DataRow row in dt.Rows)
        {
            sw.Write("<tr>");
            sw.Write("<td>" + row["PaymentType"] + "</td>");
            sw.Write("<td>" + row["TotalBills"] + "</td>");
            sw.Write("<td>" + row["BasicAmount"] + "</td>");
            sw.Write("<td>" + row["GSTAmount"] + "</td>");
            sw.Write("<td>" + row["TotalAmount"] + "</td>");
            sw.Write("</tr>");

            grandTotal += Convert.ToDecimal(row["TotalAmount"]);
        }

        sw.Write("<tr style='font-weight:bold'>");
        sw.Write("<td colspan='4'>GRAND TOTAL</td>");
        sw.Write("<td>" + grandTotal + "</td>");
        sw.Write("</tr>");

        sw.Write("</table>");

        Response.Write(sw.ToString());
        Response.End();
    }


    protected void btnback_Click(object sender, EventArgs e)
    {

    }

    private DataTable GetPaymentModeWiseSale(DateTime fromDate, DateTime toDate)
    {
        DataTable dt = new DataTable();

        string query = @"SELECT 
    PaymentType,
    COUNT(*) AS TotalBills,
    SUM(SubTotal) AS BasicAmount,
    SUM(Tax) AS GSTAmount,
    SUM(GrandTotal) AS TotalAmount
FROM
(
    SELECT Bill_ID, SubTotal, Tax, GrandTotal, 'CASH' AS PaymentType
    FROM Bill_Master
    WHERE ISNULL(CashAmount,0) > 0
      AND IsPaid = 1
      AND Bill_Date >= @fromdate
      AND Bill_Date < DATEADD(DAY,1,@todate)

    UNION ALL

    SELECT Bill_ID, SubTotal, Tax, GrandTotal, 'CARD'
    FROM Bill_Master
    WHERE ISNULL(CardAmount,0) > 0
      AND IsPaid = 1
      AND Bill_Date >= @fromdate
      AND Bill_Date < DATEADD(DAY,1,@todate)

    UNION ALL

    SELECT Bill_ID, SubTotal, Tax, GrandTotal, 'UPI'
    FROM Bill_Master
    WHERE ISNULL(UpiAmount,0) > 0
      AND IsPaid = 1
      AND Bill_Date >= @fromdate
      AND Bill_Date < DATEADD(DAY,1,@todate)

    UNION ALL

    SELECT Bill_ID, SubTotal, Tax, GrandTotal, 'CREDIT'
    FROM Bill_Master
    WHERE ISNULL(CreditAmount,0) > 0
      AND IsPaid = 1
      AND Bill_Date >= @fromdate
      AND Bill_Date < DATEADD(DAY,1,@todate)

) A
GROUP BY PaymentType
ORDER BY PaymentType";

        SqlCommand cmd = new SqlCommand(query, cl.con);
        cmd.Parameters.AddWithValue("@fromdate", fromDate);
        cmd.Parameters.AddWithValue("@todate", toDate);

        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);

        return dt;
    }
    protected void btnpreview_Click(object sender, EventArgs e)
    {
        DateTime fromDate = DateTime.Parse(txtfrom.Text);
        DateTime toDate = DateTime.Parse(txtto.Text);

        DataTable dt = GetPaymentModeWiseSale(fromDate, toDate);

        rptPayment.DataSource = dt;
        rptPayment.DataBind();
        decimal grandTotal = 0;
        decimal gstTotal = 0;
        decimal txtTotal = 0;

        foreach (DataRow row in dt.Rows)
        {
            txtTotal += Convert.ToDecimal(row["BasicAmount"]);
            gstTotal += Convert.ToDecimal(row["GSTAmount"]);
            grandTotal += Convert.ToDecimal(row["TotalAmount"]);
        }

        Label lbltGrand = (Label)rptPayment.Controls[rptPayment.Controls.Count - 1]
                            .FindControl("lbltxtTotal");
        Label lblgGrand = (Label)rptPayment.Controls[rptPayment.Controls.Count - 1]
                            .FindControl("lblgstTotal");
        Label lblGrand = (Label)rptPayment.Controls[rptPayment.Controls.Count - 1]
                            .FindControl("lblGrandTotal");

        if (lbltGrand != null)
            lbltGrand.Text = txtTotal.ToString("0.00");
        if (lblgGrand != null)
            lblgGrand.Text = gstTotal.ToString("0.00");
        if (lblGrand != null)
            lblGrand.Text = grandTotal.ToString("0.00");
    }


}