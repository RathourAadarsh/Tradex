﻿<%@ Page Title="" Language="C#" MasterPageFile="../Admin/AdminMaster.master" AutoEventWireup="true" CodeFile="GroupReport.aspx.cs" Inherits="Admin_GroupReport" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="Server">
    <main>
        <div class="container" style="margin-top: 60px; margin-bottom: 30px;">
            <div class="row">
                <div class="col-md-12">
                    <div class="row" style="margin-top: 30px;">
                        <div class="col-md-4"></div>
                        <div class="col-md-4" style="border: 1px solid #ca9142; box-shadow: 0px 0px 8px -3px #ec9190;">
                            <div class="col-md-12" style="border-bottom: 1px solid #ccc; margin-bottom: 15px;">
                                <div class="form-group" style="margin-bottom: 0px;">
                                    <h3 style="text-align: center; color: #339eae; font-size: 20px; font-weight: 500; margin: 20px;">Group Report</h3>
                                </div>
                            </div>
                            <div class="form-group mt-3 mb-3">
                                <div class="row">
                                    <div class="col-md-2"></div>
                                    <div class="col-md-2">
                                        <asp:Label ID="lb" Text="Date" runat="server" ForeColor="Black"></asp:Label>
                                    </div>
                                    <div class="col-md-6">
                                        <asp:TextBox runat="server" ID="txtfrom" class="form-control" TextMode="Date" ForeColor="Black"></asp:TextBox>
                                    </div>
                                    <div class="col-md-1"></div>
                                </div>
                            </div>
                            <div class="col-md-12" style="margin-bottom: 10px; border-top: 1px solid #ccc">
                                <div class="row">
                                    <div class="col-md-1"></div>
                                    <div class="col-md-10" style="margin-top: 15px; text-align: center">
                                        <asp:Button ID="btnpreview" runat="server" Text="Preview" CssClass="btn btn-primary" OnClick="btnpreview_Click" />
                                        <asp:Button ID="btnExportExcel"
                                            runat="server"
                                            Text="Export to Excel"
                                            CssClass="btn btn-success"
                                            OnClick="btnExportExcel_Click" />
                                        <asp:Button ID="btnback" runat="server" Text="Back" class="btn btn-danger" Font-Bold="true" OnClick="btnback_Click" />
                                    </div>
                                    <div class="col-md-1"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2"></div>
                    </div>
                    <div class="row" id="print">
                        <div class="col-md-12 mt-4" style="color: black">
                            <div>
                                <div style="display:none;">
                                    <div style="text-align: center;">
                                        <i style="font-size: 25px; display: inline-block;">Charans Club & Resort Pvt. Ltd.</i>
                                    </div>
                                    <div style="text-align: center;">
                                        <span style="font-size: 16px; display: inline-block;">Sale Report : Category wise</span>
                                    </div>
                                    <div style="font-size: 14px;">
                                        <asp:Label runat="server" Text="Period : "></asp:Label>
                                        <asp:Label runat="server" ID="from"></asp:Label>-
                                        <asp:Label runat="server" ID="lbto"></asp:Label>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <asp:Repeater ID="rptStock" runat="server">
                                            <HeaderTemplate>
                                                <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
                                                    <thead style="border-bottom: 1px solid #999; border-top: 1px solid #999;">
                                                        <tr>
                                                            <th>Group</th>
                                                            <th>Item</th>
                                                            <th style="text-align: right;">Qty</th>
                                                            <th style="text-align: right;">My Amount</th>
                                                            <th style="text-align: right;">Total Discount</th>
                                                            <th style="text-align: right;">Net Amount</th>
                                                            <th style="text-align: right;">Total Tax</th>
                                                            <th style="text-align: right;">Total Sales</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                            </HeaderTemplate>

                                            <ItemTemplate>
                                                <tr>
                                                    <td><%# Eval("Group") %></td>
                                                    <td><%# Eval("Item") %></td>
                                                    <td style="text-align: right;"><%# Eval("Qty") %></td>
                                                    <td style="text-align: right;"><%# Eval("My Amount","{0:0.00}") %></td>
                                                    <td style="text-align: right;"><%# Eval("Total Discount","{0:0.00}") %></td>
                                                    <td style="text-align: right;"><%# Eval("Net Amount","{0:0.00}") %></td>
                                                    <td style="text-align: right;"><%# Eval("Total Tax","{0:0.00}") %></td>
                                                    <td style="text-align: right;"><%# Eval("Total Sales","{0:0.00}") %></td>
                                                </tr>
                                            </ItemTemplate>

                                            <FooterTemplate>
                                                </tbody>
        </table>
                                            </FooterTemplate>
                                        </asp:Repeater>

                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </main>
</asp:Content>

