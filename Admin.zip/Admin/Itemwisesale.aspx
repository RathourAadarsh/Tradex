﻿<%@ Page Title="" Language="C#" MasterPageFile="../Admin/AdminMaster.master" AutoEventWireup="true" CodeFile="Itemwisesale.aspx.cs" Inherits="Admin_Itemwisesale" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
    <style>
        .swal-footer {
            text-align: center !important;
        }

        .swal-text {
            font-size: 22px !important;
            text-align: center;
        }

        .swal-button {
            background-color: #184f34 !important;
        }

        .radio-gap {
            margin-top: 7px;
        }

            .radio-gap input[type="radio"] {
                margin-right: 8px;
            }

            .radio-gap label {
                margin-right: 20px;
                font-size: 16px;
                color: black;
            }

        td {
            font-size: 14px;
        }
    </style>
    <script type="text/javascript" src="sweetalertnew.js"></script>
    <script type="text/javascript">
        function savealert(message, type) {
    swal({
        text: message,
        icon: type === 'success' ? 'success' : type === 'info' ? 'info' : type === 'error' ? 'error' : 'warning',
    });
}
    </script>
    <script>
        function printDiv(divId) {
        var divContents = document.getElementById(divId).innerHTML;
        var originalContents = document.body.innerHTML;
        document.body.innerHTML = divContents;
        window.print();
        document.body.innerHTML = originalContents;
        location.reload();
    }
    </script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="Server">
    <main>
        <div class="container" style="margin-top: 60px; margin-bottom: 30px;">
            <div class="row">
                <div class="col-md-12">
                    <div class="row" style="margin-top: 30px;">
                        <div class="col-md-3"></div>
                        <div class="col-md-6" style="border: 1px solid #ca9142; box-shadow: 0px 0px 8px -3px #ec9190;">
                            <div class="col-md-12" style="border-bottom: 1px solid #ccc; margin-bottom: 15px;">
                                <div class="form-group" style="margin-bottom: 0px;">
                                    <h3 style="text-align: center; color: #339eae; font-size: 20px; font-weight: 500; margin: 20px;">Item Wise Sale Report</h3>
                                </div>
                            </div>
                            <div class="form-group mt-3 mb-3">
                                <div class="row">
                                    <div class="col-md-1"></div>
                                    <div class="col-md-2" style="padding-right: 0px">
                                        <asp:Label ID="lb" Text="From Date" runat="server" ForeColor="Black"></asp:Label>
                                    </div>
                                    <div class="col-md-3" style="padding-right: 0px">
                                        <asp:TextBox runat="server" ID="txtfrom" class="form-control" TextMode="Date" ForeColor="Black"></asp:TextBox>
                                    </div>
                                    <div class="col-md-2">
                                        <asp:Label ID="Label3" Text="To Date" runat="server" ForeColor="Black"></asp:Label>
                                    </div>
                                    <div class="col-md-3" style="padding-right: 0px">
                                        <asp:TextBox runat="server" ID="txtto" class="form-control" TextMode="Date" ForeColor="Black"></asp:TextBox>
                                    </div>
                                    <div class="col-md-1"></div>
                                </div>
                            </div>
                            <div class="col-md-12" style="margin-bottom: 10px; border-top: 1px solid #ccc">
                                <div class="row">
                                    <div class="col-md-2"></div>
                                    <div class="col-md-8" style="margin-top: 15px; text-align: center">
                                        <asp:Button ID="btnpreview" runat="server" Text="Preview" CssClass="btn btn-primary" OnClick="btnpreview_Click" />
                                        <asp:Button ID="btnExportExcel" runat="server" Text="Export to Excel" CssClass="btn btn-success" OnClick="btnExportExcel_Click" />
                                        <asp:Button ID="btnback" runat="server" Text="Back" class="btn btn-danger" Font-Bold="true" OnClick="btnback_Click" />
                                    </div>
                                    <div class="col-md-2"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2"></div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 mt-3">
                            <asp:Repeater ID="rptStock" runat="server" OnItemDataBound="rptStock_ItemDataBound">
                                <HeaderTemplate>
                                    <table style="width: 100%; border-collapse: collapse; font-family: Calibri; font-size: 14px; border-bottom: 1px solid #000; border-top: 1px solid #000;">
                                        <tr style="font-weight: bold; background: #f2f2f2;">
                                            <td style="padding: 5px; border-bottom: 1px solid #000;">Item Name</td>
                                            <td style="padding: 5px; border-bottom: 1px solid #000;">Quantity</td>
                                            <td style="padding: 5px; border-bottom: 1px solid #000; text-align: right">Taxable Amt</td>
                                            <td style="padding: 5px; border-bottom: 1px solid #000; text-align: right">GST</td>
                                            <td style="padding: 5px; border-bottom: 1px solid #000; text-align: right">Total Amount</td>
                                        </tr>
                                </HeaderTemplate>
                                <ItemTemplate>
                                    <asp:Literal ID="litGroupHeader" runat="server"></asp:Literal>
                                    <tr>
                                        <td><%# Eval("itemname") %></td>
                                        <td><%# Eval("TotalQty") %></td>
                                        <td style="text-align: right"><%# Eval("BasicAmount","{0:0.00}") %></td>
                                        <td style="text-align: right"><%# Eval("GSTAmount","{0:0.00}") %></td>
                                        <td style="text-align: right"><%# Eval("TotalAmount","{0:0.00}") %></td>
                                    </tr>
                                </ItemTemplate>
                                <FooterTemplate>
                                    <tr style="font-weight: bold; border-top: 1px solid #000;">
                                        <td colspan="1" style="padding: 4px;">TOTAL :</td>

                                        <td style=" padding: 4px;">
                                            <asp:Label ID="lblGrandQty" runat="server" />
                                        </td>
                                        <td style="text-align: right; padding: 4px;">
                                            <asp:Label ID="lblSubtotalTotal" runat="server" />
                                        </td>
                                        <td style="text-align: right; padding: 4px;">
                                            <asp:Label ID="lblTaxTotal" runat="server" />
                                        </td>                                             
                                        <td style="text-align: right; padding: 4px;">
                                            <asp:Label ID="lblGrandTotal" runat="server" />
                                        </td>
                                    </tr>
                                    </table>
                                </FooterTemplate>
                            </asp:Repeater>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</asp:Content>
