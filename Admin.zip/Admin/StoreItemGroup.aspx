﻿<%@ Page Title="" Language="C#" MasterPageFile="../Admin/AdminMaster.master" AutoEventWireup="true" CodeFile="StoreItemGroup.aspx.cs" Inherits="Admin_StoreItemGroup" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
     <link href="Style.css" rel="stylesheet" />
    <style>
        .swal-footer {
            text-align: center !important;
        }

        .swal-text {
            font-size: 22px !important;
            text-align: center;
        }

        .swal-button {
            background-color: #184f34 !important;
        }
    </style>
    <script type="text/javascript" src="sweetalertnew.js"></script>
    <script type="text/javascript">
        function savealert(message, type) {
            swal({
                text: message,
                icon: type === 'success' ? 'success' : type === 'info' ? 'info' : type === 'error' ? 'error' : 'warning',
            });
        }
    </script>
    <script type="text/javascript">
        window.history.forward();
        function noBack() {
            window.history.forward();
        }
    </script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="Server">
    <div class="dashboard-bg">
        <div class="container">
            <div class="row" style="margin-top: 100px !important;">
                <div class="col-md-5" style="border: 1px solid; height: 250px;">
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-12">
                                <h5 style="text-align: center; font-weight: 600; padding-top: 10px;">Store Item Group Master</h5>
                            </div>
                        </div>
                    </div>
                    <hr />
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-1"></div>
                            <div class="col-md-4">
                                <asp:Label runat="server" ID="lblb" Text="Group ID" ForeColor="Black"></asp:Label>
                            </div>
                            <div class="col-md-6">
                                <asp:TextBox runat="server" ID="txtgid" CssClass="form-control"></asp:TextBox>
                            </div>
                            <div class="col-md-1"></div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-1"></div>
                            <div class="col-md-4">
                                <asp:Label runat="server" ID="Label1" Text="Group Name" ForeColor="Black"></asp:Label>
                            </div>
                            <div class="col-md-6">
                                <asp:TextBox runat="server" ID="txtgrpname" CssClass="form-control"></asp:TextBox>
                            </div>
                            <div class="col-md-1"></div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-5"></div>
                            <div class="col-md-4">
                                <asp:Button runat="server" ID="btnsave" Text="Save" CssClass="btn btn-success" OnClick="btnsave_Click"></asp:Button>
                                <asp:Button runat="server" ID="btnback" Text="Back" CssClass="btn btn-danger" OnClick="btnback_Click"></asp:Button>
                            </div>
                            <div class="col-md-3"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-7" style="overflow: scroll; height: 500px;">
                    <div class="row">
                        <div class="col-md-12">
                            <asp:ListView ID="listview2" runat="server" Style="color: black !important;">
                                <LayoutTemplate>
                                    <table class="table table-bordered">
                                        <tr>
                                            <th style="width: 20%;">Group ID</th>
                                            <th style="width: 50%;">Group Name</th>
                                            <th style="width: 30%;">Action</th>
                                        </tr>
                                        <tbody>
                                            <asp:PlaceHolder ID="itemPlaceHolder" runat="server" />
                                        </tbody>
                                    </table>
                                </LayoutTemplate>
                                <ItemTemplate>
                                    <tr>
                                        <td>
                                            <asp:Label ID="lblcode" runat="server" Text=' <%# Eval("item_g_id")%>'></asp:Label></td>
                                        <td>
                                            <asp:Label ID="lblitemname" runat="server" Text=' <%# Eval("Item_G_Name")%>'></asp:Label></td>
                                        <td>
                                            <asp:Button runat="server" ID="btnedit" Text="Edit" CssClass="btn btn-info" OnClick="btnedit_Click" Style="width:55px;" />
                                            <asp:Button runat="server" ID="btndelete" Text='<%# Eval("inactive")%>' CssClass="btn btn-danger" OnClick="btndelete_Click" OnClientClick="return showConfirm();" Style="width:90px;" />
                                        </td>
                                    </tr>
                                </ItemTemplate>
                            </asp:ListView>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</asp:Content>

