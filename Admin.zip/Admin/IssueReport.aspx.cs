﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class IssueReport : System.Web.UI.Page
{
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    Class1 cl = new Class1();
    HttpCookie lgdcookie;

    protected void Page_Load(object sender, EventArgs e)
    {
        lgdcookie = Request.Cookies["loggeduser"];
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        if (!IsPostBack)
        {
            txtfrom.Text = dateTime.ToString("yyyy-MM-dd");
            txtto.Text = dateTime.ToString("yyyy-MM-dd");
        }
    }
    protected void btnExportExcel_Click(object sender, EventArgs e)
    {
    }
    public DataTable GetItemWiseSaleReport(DateTime fromDate, DateTime toDate, string type)
    {
        StringBuilder query = new StringBuilder(@"SELECT 
    pi.isid,
    pi.ptype,
    sm.Item_G_Name,
    CONVERT(NVARCHAR,pi.idate,103) AS idate,
    pi.pno,
    pi.inv,
    CONVERT(NVARCHAR, pi.invdt,103) AS Billdate,
    sgm.Item_name,
    CAST(pi.qty AS DECIMAL(18,2)) AS qty,
    pi.rate,
    pi.amount
FROM IssuetoKitchen pi
LEFT JOIN StoreItem_group_Master sm ON pi.itemcate = sm.Item_G_Id
LEFT JOIN StoreItem_detail sgm ON pi.itemname = sgm.sku
WHERE pi.idate BETWEEN @fromDate AND @toDate
AND pi.isdeleted = 0");

        if (type == "Direct")
        {
            query.Append(" AND pi.pno IS NOT NULL ");
        }
        else if (type == "Store")
        {
            query.Append(" AND pi.pno IS NULL ");
        }

        query.Append(@"ORDER BY CASE WHEN pi.pno IS NOT NULL THEN 1 ELSE 2 END, pi.isid");

        SqlCommand cmd = new SqlCommand(query.ToString(), cl.con);
        cmd.Parameters.AddWithValue("@FromDate", fromDate);
        cmd.Parameters.AddWithValue("@ToDate", toDate);
        if (type != "Both")
        {
            cmd.Parameters.AddWithValue("@type", type);
        }
        SqlDataAdapter adp = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        adp.Fill(dt);
        return dt;

    }
    protected void btnback_Click(object sender, EventArgs e)
    {
        Response.Redirect("StoreDashboard.aspx");
    }
    protected void btnExportPDF_Click(object sender, EventArgs e)
    {
        DateTime fromDate = DateTime.Parse(txtfrom.Text);
        DateTime toDate = DateTime.Parse(txtto.Text);
        string type = rblType.SelectedValue;
        DataTable dt = GetItemWiseSaleReport(fromDate, toDate, type);

        if (dt.Rows.Count == 0)
            return;

        Document doc = new Document(PageSize.A4.Rotate());
        MemoryStream ms = new MemoryStream();
        PdfWriter.GetInstance(doc, ms);
        doc.Open();

        Font companyFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 16);
        Paragraph company = new Paragraph("Charans Club & Resort Pvt Ltd", companyFont);
        company.Alignment = Element.ALIGN_CENTER;
        doc.Add(company);

        Font titleFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 14);
        Paragraph title = new Paragraph("Issue Report", titleFont);
        title.Alignment = Element.ALIGN_CENTER;
        doc.Add(title);
        Font infoFont = FontFactory.GetFont(FontFactory.HELVETICA, 11);
        Paragraph info = new Paragraph(
            "Date : " + fromDate.ToString("dd-MM-yyyy") +
            " To " + toDate.ToString("dd-MM-yyyy"),
            infoFont);
        info.Alignment = Element.ALIGN_CENTER;
        info.SpacingAfter = 15;
        doc.Add(info);
        PdfPTable table = new PdfPTable(10);
        table.WidthPercentage = 100;

        float[] widths = { 5f, 10f, 12f, 12f, 12f, 15f, 15f, 8f, 10f, 11f };
        table.SetWidths(widths);

        string[] headers = {"Sr.No", "Purchase Date", "Purchase No", "Invoice No", "Invoice Date", "Category", "Item Name", "Qty", "Rate", "Amount"};

        Font headerFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 11);

        foreach (string header in headers)
        {
            PdfPCell cell = new PdfPCell(new Phrase(header, headerFont));
            cell.BackgroundColor = BaseColor.LIGHT_GRAY;
            cell.Padding = 5;

            if (header == "Qty" || header == "Rate" || header == "Amount")
                cell.HorizontalAlignment = Element.ALIGN_RIGHT;
            else
                cell.HorizontalAlignment = Element.ALIGN_LEFT;

            table.AddCell(cell);
        }

        string currentPurchaseNo = "";
        int srNo = 1;

        int itemCount = 0;
        decimal purchaseQtyTotal = 0;
        decimal purchaseAmtTotal = 0;

        decimal grandQty = 0;
        decimal grandAmt = 0;

        Font normalFont = FontFactory.GetFont(FontFactory.HELVETICA, 10);
        Font totalFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 11);

        foreach (DataRow row in dt.Rows)
        {
            string purchaseNo = row["isid"].ToString();
            decimal qty = row["qty"] != DBNull.Value
                ? Convert.ToDecimal(row["qty"])
                : 0;
            decimal rate = Convert.ToDecimal(row["rate"]);
            decimal amt = Convert.ToDecimal(row["amount"]);

            if (currentPurchaseNo != "" && purchaseNo != currentPurchaseNo)
            {
                if (itemCount > 1)
                {
                    PdfPCell subTotalCell = new PdfPCell(new Phrase("Sub Total :", totalFont));
                    subTotalCell.Colspan = 9;
                    subTotalCell.HorizontalAlignment = Element.ALIGN_RIGHT;
                    subTotalCell.BackgroundColor = BaseColor.LIGHT_GRAY;
                    table.AddCell(subTotalCell);

                    table.AddCell(new PdfPCell(new Phrase("₹ " + purchaseAmtTotal.ToString("N2"), totalFont))
                    { HorizontalAlignment = Element.ALIGN_RIGHT });
                }

                purchaseQtyTotal = 0;
                purchaseAmtTotal = 0;
                itemCount = 0;
            }

            if (purchaseNo != currentPurchaseNo)
            {
                table.AddCell(new PdfPCell(new Phrase(srNo.ToString(), normalFont)));
                table.AddCell(new PdfPCell(new Phrase(row["idate"].ToString(), normalFont)));
                table.AddCell(new PdfPCell(new Phrase(row["pno"].ToString(), normalFont)));
                table.AddCell(new PdfPCell(new Phrase(row["inv"].ToString(), normalFont)));
                table.AddCell(new PdfPCell(new Phrase(row["Billdate"].ToString(), normalFont)));
                srNo++;
            }
            else
            {
                for (int i = 0; i < 5; i++)
                    table.AddCell(new PdfPCell(new Phrase("", normalFont)));
            }

            table.AddCell(new PdfPCell(new Phrase(row["Item_G_Name"].ToString(), normalFont)));
            table.AddCell(new PdfPCell(new Phrase(row["Item_name"].ToString(), normalFont)));

            table.AddCell(new PdfPCell(new Phrase(qty.ToString("N2"), normalFont))
            { HorizontalAlignment = Element.ALIGN_RIGHT });

            table.AddCell(new PdfPCell(new Phrase(rate.ToString("N2"), normalFont))
            { HorizontalAlignment = Element.ALIGN_RIGHT });

            table.AddCell(new PdfPCell(new Phrase("₹ " + amt.ToString("N2"), normalFont))
            { HorizontalAlignment = Element.ALIGN_RIGHT });

            purchaseQtyTotal += qty;
            purchaseAmtTotal += amt;
            itemCount++;

            grandQty += qty;
            grandAmt += amt;

            currentPurchaseNo = purchaseNo;
        }
        if (itemCount > 1)
        {
            PdfPCell lastSub = new PdfPCell(new Phrase("Sub Total :", totalFont));
            lastSub.Colspan = 9;
            lastSub.HorizontalAlignment = Element.ALIGN_RIGHT;
            lastSub.BackgroundColor = BaseColor.LIGHT_GRAY;
            table.AddCell(lastSub);

            table.AddCell(new PdfPCell(new Phrase("₹ " + purchaseAmtTotal.ToString("N2"), totalFont))
            { HorizontalAlignment = Element.ALIGN_RIGHT });
        }
        PdfPCell grandCell = new PdfPCell(new Phrase("GRAND TOTAL :", totalFont));
        grandCell.Colspan = 9;
        grandCell.HorizontalAlignment = Element.ALIGN_RIGHT;
        grandCell.BackgroundColor = new BaseColor(217, 237, 247);
        table.AddCell(grandCell);

        table.AddCell(new PdfPCell(new Phrase("₹ " + grandAmt.ToString("N2"), totalFont))
        { HorizontalAlignment = Element.ALIGN_RIGHT });

        doc.Add(table);
        doc.Close();

        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "attachment;filename=IssueReport.pdf");
        Response.BinaryWrite(ms.ToArray());
        Response.End();
    }
    protected void btnview_Click(object sender, EventArgs e)
    {
        DateTime fromDate = DateTime.Parse(txtfrom.Text);
        DateTime toDate = DateTime.Parse(txtto.Text);
        string type = rblType.SelectedValue;
        DataTable dt = GetItemWiseSaleReport(fromDate, toDate, type);

        if (dt.Rows.Count > 0)
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("<div class='container mt-4'>");
            sb.Append("<table class='table table-bordered table-striped'>");

            sb.Append("<tr style='background:#f2f2f2;font-weight:bold'>");
            sb.Append("<th>Sr.No.</th>");
            sb.Append("<th>Purchase Date</th>");
            sb.Append("<th>Purchase No</th>");
            sb.Append("<th>Invoice No</th>");
            sb.Append("<th>Invoice Date</th>");
            sb.Append("<th>Category</th>");
            sb.Append("<th>Item Name</th>");
            sb.Append("<th>Qty</th>");
            sb.Append("<th>Rate</th>");
            sb.Append("<th style='text-align:right'>Amount</th>");
            sb.Append("</tr>");

            int srNo = 1;

            decimal purchaseAmtTotal = 0;
            int itemCount = 0;

            decimal grandQty = 0;
            decimal grandAmt = 0;

            string currentType = "";
            decimal typeQtyTotal = 0;
            decimal typeAmtTotal = 0;

            foreach (DataRow row in dt.Rows)
            {
                string rowType = row["pno"] == DBNull.Value ? "Store Issue" : "Direct Issue";
                decimal qty = Convert.ToDecimal(row["qty"]);
                decimal amt = Convert.ToDecimal(row["amount"]);

                if (currentType != "" && currentType != rowType)
                {
                    sb.Append("<tr style='font-weight:bold;background:#eee'>");
                    sb.Append("<td colspan='9' style='text-align:right'>" + currentType + " Sub Total :</td>");
                    sb.Append("<td style='text-align:right'>" + typeAmtTotal.ToString("0.00") + "</td>");
                    sb.Append("</tr>");

                    typeQtyTotal = 0;
                    typeAmtTotal = 0;
                }

                sb.Append("<tr>");
                sb.Append("<td>" + srNo + "</td>");
                sb.Append("<td>" + row["idate"] + "</td>");
                sb.Append("<td>" + (row["pno"] == DBNull.Value ? "-" : row["pno"]) + "</td>");
                sb.Append("<td>" + row["inv"] + "</td>");
                sb.Append("<td>" + row["Billdate"] + "</td>");
                sb.Append("<td>" + row["Item_G_Name"] + "</td>");
                sb.Append("<td>" + row["Item_name"] + "</td>");
                sb.Append("<td>" + qty.ToString("0.##") + "</td>");
                sb.Append("<td style='text-align:right'>" + Convert.ToDecimal(row["rate"]).ToString("0.00") + "</td>");
                sb.Append("<td style='text-align:right'>" + amt.ToString("0.00") + "</td>");
                sb.Append("</tr>");
                srNo++;
                typeQtyTotal += qty;
                typeAmtTotal += amt;

                grandQty += qty;
                grandAmt += amt;

                currentType = rowType;
            }

            if (itemCount > 1)
            {
                sb.Append("<tr style='font-weight:bold;background:#eee'>");
                sb.Append("<td colspan='9' style='text-align:right'>Sub Total :</td>");
                sb.Append("<td style='text-align:right'>" + purchaseAmtTotal.ToString("0.00") + "</td>");
                sb.Append("</tr>");
            }
            if (currentType != "")
            {
                sb.Append("<tr style='font-weight:bold;background:#eee'>");
                sb.Append("<td colspan='9' style='text-align:right'>" + currentType + " Sub Total :</td>");
                sb.Append("<td style='text-align:right'>" + typeAmtTotal.ToString("0.00") + "</td>");
                sb.Append("</tr>");
            }

            sb.Append("<tr style='font-weight:bold;background:#d9edf7'>");
            sb.Append("<td colspan='9' style='text-align:right'>GRAND TOTAL :</td>");
            sb.Append("<td style='text-align:right'>" + grandAmt.ToString("0.00") + "</td>");
            sb.Append("</tr>");

            sb.Append("</table>");
            sb.Append("</div>");

            ltTable.Text = sb.ToString();
        }
        else
        {
            ltTable.Text = "";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('No data found');", true);
        }
    }

}